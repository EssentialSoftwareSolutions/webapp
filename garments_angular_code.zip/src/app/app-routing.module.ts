import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UpdateRackOrderComponent } from './update-rack-order/update-rack-order.component';
import { InwardSkuComponent } from './inward-sku/inward-sku.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
{path: '', component: HomeComponent},
{path: 'updaterackorder', component: UpdateRackOrderComponent},           
{path: 'InwardSku', component: InwardSkuComponent},           
{ path: '**', redirectTo: '' } 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
