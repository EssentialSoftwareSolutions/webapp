import { Injectable } from '@angular/core';
import { environment } from '@environments/environment';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class DboperationService {

  constructor(private httpClient: HttpClient) { }


updaterackorder(rackdata) {
let headers : any = new HttpHeaders({ 'Content-Type': 'application/json',
'token': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7IkxvZ2luSWQiOjEsIkxvZ2luX1VzZXJFbWFpbElkIjoidmlwdWxAZ21haWwuY29tIiwiTG9naW5fVXNlclB3ZCI6IiQyYiQxMCRLV1g5MkYzTS91c2NDRHlwem1CY00uTmYuYzZkTlU2cWU1LlJNYThHcGpPZHVDeC5QUGxUTyJ9LCJpYXQiOjE2MjU0MDI5MTMsImV4cCI6MTYyNzk5NDkxM30.3k3KRHipPW5mQZ4yI8bvw8NtKLgkgrcIhquEB5uVgZc'}),
options : any=rackdata["racks"];

return new Promise(resolve => {
this.httpClient.post(`${environment.apiUrl}/rack/update`,JSON.stringify(options),{headers:headers}).subscribe(data => {
resolve(data);}, 
err => {
alert(JSON.stringify(err));
});
});
}

getrackdata() {
let headers : any = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded','token': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7IkxvZ2luSWQiOjEsIkxvZ2luX1VzZXJFbWFpbElkIjoidmlwdWxAZ21haWwuY29tIiwiTG9naW5fVXNlclB3ZCI6IiQyYiQxMCRLV1g5MkYzTS91c2NDRHlwem1CY00uTmYuYzZkTlU2cWU1LlJNYThHcGpPZHVDeC5QUGxUTyJ9LCJpYXQiOjE2MjU0MDI5MTMsImV4cCI6MTYyNzk5NDkxM30.3k3KRHipPW5mQZ4yI8bvw8NtKLgkgrcIhquEB5uVgZc' })

return new Promise(resolve => {
this.httpClient.get<any>(`${environment.apiUrl}/rack`,{headers:headers}).subscribe(data => {
resolve(data);}, 
err => {
alert(JSON.stringify(err));
});
});
}

getleastcoeffecient() {
let headers : any = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded','token': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7IkxvZ2luSWQiOjEsIkxvZ2luX1VzZXJFbWFpbElkIjoidmlwdWxAZ21haWwuY29tIiwiTG9naW5fVXNlclB3ZCI6IiQyYiQxMCRLV1g5MkYzTS91c2NDRHlwem1CY00uTmYuYzZkTlU2cWU1LlJNYThHcGpPZHVDeC5QUGxUTyJ9LCJpYXQiOjE2MjU0MDI5MTMsImV4cCI6MTYyNzk5NDkxM30.3k3KRHipPW5mQZ4yI8bvw8NtKLgkgrcIhquEB5uVgZc' })

return new Promise(resolve => {
this.httpClient.get<any>(`${environment.apiUrl}/rack/leastcoefficient`,{headers:headers}).subscribe(data => {
resolve(data);
//alert(JSON.stringify(data));
}, 
err => {
alert(JSON.stringify(err));
});
});
}

getskudata() {
let headers : any = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded','token': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7IkxvZ2luSWQiOjEsIkxvZ2luX1VzZXJFbWFpbElkIjoidmlwdWxAZ21haWwuY29tIiwiTG9naW5fVXNlclB3ZCI6IiQyYiQxMCRLV1g5MkYzTS91c2NDRHlwem1CY00uTmYuYzZkTlU2cWU1LlJNYThHcGpPZHVDeC5QUGxUTyJ9LCJpYXQiOjE2MjU0MDI5MTMsImV4cCI6MTYyNzk5NDkxM30.3k3KRHipPW5mQZ4yI8bvw8NtKLgkgrcIhquEB5uVgZc' })

return new Promise(resolve => {
this.httpClient.get<any>(`${environment.apiUrl}/sku`,{headers:headers}).subscribe(data => {
resolve(data);}, 
err => {
alert(JSON.stringify(err));
});
});
}

validatesku(skucode: any) {
let headers : any = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded','token': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7IkxvZ2luSWQiOjEsIkxvZ2luX1VzZXJFbWFpbElkIjoidmlwdWxAZ21haWwuY29tIiwiTG9naW5fVXNlclB3ZCI6IiQyYiQxMCRLV1g5MkYzTS91c2NDRHlwem1CY00uTmYuYzZkTlU2cWU1LlJNYThHcGpPZHVDeC5QUGxUTyJ9LCJpYXQiOjE2MjU0MDI5MTMsImV4cCI6MTYyNzk5NDkxM30.3k3KRHipPW5mQZ4yI8bvw8NtKLgkgrcIhquEB5uVgZc' })

return new Promise(resolve => {
this.httpClient.get<any>(`${environment.apiUrl}/sku/`+skucode,{headers:headers}).subscribe(data => {
resolve(data);}, 
err => {
alert(JSON.stringify(err));
});
});
}

createinward(inwarddata: any,challandate: string,challanno: string) {
let headers : any = new HttpHeaders({ 'Content-Type': 'application/json',
'token': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7IkxvZ2luSWQiOjEsIkxvZ2luX1VzZXJFbWFpbElkIjoidmlwdWxAZ21haWwuY29tIiwiTG9naW5fVXNlclB3ZCI6IiQyYiQxMCRLV1g5MkYzTS91c2NDRHlwem1CY00uTmYuYzZkTlU2cWU1LlJNYThHcGpPZHVDeC5QUGxUTyJ9LCJpYXQiOjE2MjU0MDI5MTMsImV4cCI6MTYyNzk5NDkxM30.3k3KRHipPW5mQZ4yI8bvw8NtKLgkgrcIhquEB5uVgZc'}),
options : any={"InwardChallanNo":challanno,"InwardDate":challandate,"SKUCode":inwarddata.SKUCode,"SKUQty":inwarddata.SKUQty,"SKURackCode":inwarddata.SKURackCode};
//alert(JSON.stringify(options));
return new Promise(resolve => {
this.httpClient.post(`${environment.apiUrl}/inward`,JSON.stringify(options),{headers:headers}).subscribe(data => {
resolve(data);}, 
err => {
alert(JSON.stringify(err));
});
});
}

}
