import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InwardSkuComponent } from './inward-sku.component';

describe('InwardSkuComponent', () => {
  let component: InwardSkuComponent;
  let fixture: ComponentFixture<InwardSkuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InwardSkuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InwardSkuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
