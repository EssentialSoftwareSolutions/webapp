import { Component, OnInit } from '@angular/core';
import { DatePipe, formatDate } from '@angular/common';
import { FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import {DboperationService} from '../dboperation.service';

@Component({
  selector: 'app-inward-sku',
  templateUrl: './inward-sku.component.html',
  styleUrls: ['./inward-sku.component.css'],
  providers: [DatePipe]
})
export class InwardSkuComponent implements OnInit {
chdate: string;
challanno: string;
skuscan: string;
inwardForm: FormGroup;
skuentries: FormArray;
skuallocated: boolean=false;
rackdata:any;
skudata:any;
maxvolspace : number;
  constructor(private dboperationService: DboperationService,private datePipe: DatePipe,private fb:FormBuilder) { 
   this.inwardForm=this.fb.group({
      skuentries: new FormArray([])
    })

  }

  ngOnInit(): void {
  var date = new Date();
  this.chdate=this.datePipe.transform(date,"yyyy-MM-dd");
  this.challanno="";
  this.skuscan="";
  this.dboperationService.getleastcoeffecient().then(data => {
     this.rackdata = data[0];
     this.maxvolspace = this.rackdata["RackCubicCapacity"] * 0.90;
  //   alert(this.maxvolspace);
   //  alert(JSON.stringify(this.rackdata));
     },
     (error : any) => {
      alert('Error While fetching rack data...'); 
     }); 

  this.dboperationService.getskudata().then(data => {
     this.skudata = data;
       },
     (error : any) => {
      alert('Error While fetching sku data...'); 
     }); 


  }

 newsku(): FormGroup {
    return this.fb.group({
      SKUCode: '',
      SKUQty: 0,
      SKURackCode: ''
    })
  }
 
 
addrow() {
	if (this.challanno == '') {
       alert('Please enter Challan no...');
       return;
	}

   // this.skuentries().push(this.newsku());

  this.skuentries = this.inwardForm.get('skuentries') as FormArray;
  this.skuentries.push(this.newsku());    
}

onSubmit() {

}

addskuqty() {
 let index=0;
 let skuspace=0;

this.inwardForm.controls.skuentries.value.forEach((value) => {
	if (value.SKURackCode != '') {
       alert('Please allocate '+ value.SKUCode + ' by clicking on Done...');
       return;
	}
});

this.inwardForm.controls.skuentries.value.forEach((value) => {
 if (value.SKUCode == this.skuscan) {
   this.inwardForm.controls.skuentries['controls'][index].controls.SKUQty.setValue(this.inwardForm.controls.skuentries['controls'][index].controls.SKUQty.value+1);
   this.skudata.forEach((skuval) => {
     if (skuval.SkuCode == this.skuscan) {
        skuspace = skuval.SkuCubicSpaceReq;
     }
   });

     if ((skuspace * this.inwardForm.controls.skuentries['controls'][index].controls.SKUQty.value) > this.maxvolspace) {
        this.inwardForm.controls.skuentries['controls'][index].controls.SKURackCode.setValue(this.rackdata["RackCode"]);
     }


 }
 index+=1;
    });
 this.skuscan="";
}


skuallocate(skuIndex:number){
if (this.inwardForm.controls.skuentries['controls'][skuIndex].controls.SKURackCode.value == ''){
	alert('Still Rack is not full So can not allocate Sku...');
    return;
}
    this.dboperationService.createinward(this.inwardForm.controls.skuentries['controls'][skuIndex].value,this.chdate,this.challanno).then(data => {
     alert('Sku Successfully Allocated...');
     this.inwardForm.controls.skuentries['controls'][skuIndex].controls.SKURackCode.setValue('');
     this.inwardForm.controls.skuentries['controls'][skuIndex].controls.SKUQty.setValue(0);

     this.dboperationService.getleastcoeffecient().then(data => {
     this.rackdata = data[0];
     this.maxvolspace = this.rackdata["RackCubicCapacity"] * 0.90;
     },
     (error : any) => {
      alert('Error While fetching rack data...'); 
     }); 


     },
     (error : any) => {
      alert('Error While adding sku inward...'); 
     }); 
}
}