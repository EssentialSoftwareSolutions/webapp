import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateRackOrderComponent } from './update-rack-order.component';

describe('UpdateRackOrderComponent', () => {
  let component: UpdateRackOrderComponent;
  let fixture: ComponentFixture<UpdateRackOrderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateRackOrderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateRackOrderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
