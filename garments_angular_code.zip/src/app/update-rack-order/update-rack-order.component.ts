import { Component, OnInit } from '@angular/core';
import {DboperationService} from '../dboperation.service';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';

@Component({
  selector: 'app-update-rack-order',
  templateUrl: './update-rack-order.component.html',
  styleUrls: ['./update-rack-order.component.css']
})
export class UpdateRackOrderComponent implements OnInit {
  rackFormGroup: FormGroup;
  rackdata: any;
      submitted = false;
  constructor(private dboperationService: DboperationService,private formBuilder: FormBuilder) { }

  ngOnInit(): void {
     this.rackFormGroup = this.formBuilder.group({
            racks: new FormArray([])
     });

     this.dboperationService.getrackdata().then(data => {
     this.rackdata = data;

     for (var rack in this.rackdata) {
         this.t.push(this.formBuilder.group({
             rackcode: [this.rackdata[rack]["RackCode"], Validators.required],
             rackdistancerank: [this.rackdata[rack]["RackDistanceRank"],[Validators.required,Validators.min(1)] ]
      }));         
     }

     },
     (error : any) => {
      alert('Error While fetching rack data...'); 
     });


  }
  
    get f() { return this.rackFormGroup.controls; }
    get t() { return this.f.racks as FormArray; }

onSubmit() {
   this.submitted = true;

   if (this.rackFormGroup.invalid) {
      return;
   }
 //    alert(JSON.stringify(this.rackFormGroup.value));
  //   return;
     this.dboperationService.updaterackorder(this.rackFormGroup.value).then(data => {
        alert('Rack Order Updated successfully...');
     },
     (error : any) => {
      alert('Error While updating rack order...'); 
     });

}
}
