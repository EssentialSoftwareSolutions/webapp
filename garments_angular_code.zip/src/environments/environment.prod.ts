export const environment = {
  production: true,
  apiUrl: 'http://65.0.132.73:5000/garments/api/v1'
};
