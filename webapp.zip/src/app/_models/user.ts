export class User {
    Login_Id: number;
    Login_UserEmailId: string;
    Login_UserPwd: string;
    Login_Name: string;
    login_Group: string;
    login_Designation: string;    
}