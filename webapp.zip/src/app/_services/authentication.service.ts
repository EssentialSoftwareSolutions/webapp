﻿import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import AES from 'crypto-js/aes';
import Utf8 from 'crypto-js/enc-utf8';
import { environment } from '@environments/environment';
import { User } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
    private currentUserSubject: BehaviorSubject<User>;
    public currentUser: Observable<User>;

    constructor(private http: HttpClient) {
        this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(sessionStorage.getItem('currentUser')));
        this.currentUser = this.currentUserSubject.asObservable();
    }

    public get currentUserValue(): User {
        return this.currentUserSubject.value;
    }

    login(username: string, password: string,localstoragereq: boolean=true) {
    const body = new HttpParams()
    .set(`email`, username)
    .set(`password`, password);
    const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
    return this.http.post<any>(`${environment.apiUrl}/authenticate`,body.toString(),{headers: headers})
           .pipe(map(user => {
                // store user details and basic auth credentials in local storage to keep user logged in between page refreshes
           //     alert(user.status);
          //      alert(user.data);
          //      alert(user.token); 
       //         user.token = AES.encrypt(user.token, environment.encryptionkey).toString(); 
                              
                if (user.status){
                   if (localstoragereq) {
            //          alert(localstoragereq);
                      sessionStorage.setItem('currentUser', JSON.stringify(user));
                //      alert(environment.encryptionkey);
                      sessionStorage.setItem('key',user.token );
                   }
                this.currentUserSubject.next(user);
                return user;
                }
                else {
                 return null;
                } 
            }));
    }

    logout() {
        // remove user from local storage to log user out
        sessionStorage.removeItem('currentUser');
        sessionStorage.removeItem('key');
        this.currentUserSubject.next(null);
    }
}