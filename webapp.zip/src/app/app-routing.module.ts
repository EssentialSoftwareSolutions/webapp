import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home';
import { LoginComponent } from './login';
import { AuthGuard } from './_helpers';
import { SyncSalesOrderComponent } from './sync-sales-order/sync-sales-order.component';
import { ViewSalesOrderComponent } from './view-sales-order/view-sales-order.component';
import { ViewOrderMasterComponent } from './view-order-master/view-order-master.component';
import { ViewPurchaseInvoiceComponent } from './view-purchase-invoice/view-purchase-invoice.component';
import { ViewStockComponent } from './view-stock/view-stock.component';
import { ViewSalesReceiptComponent } from './view-salesreceipt/view-salesreceipt.component';
import { ViewProductInfoComponent } from './view-productinfo/view-productinfo.component';
import { ImportPurchaseOrderComponent } from './import-purchase-order/import-purchase-order.component';
import { ImportOrderMasterComponent } from './import-order-master/import-order-master.component';
import { PurchaseInvoiceComponent } from './purchase-invoice/purchase-invoice.component';
import { LeadComponent } from './lead/lead.component';
import { MessageTemplateComponent } from './message-template/message-template.component';

import { SalesOrderComponent } from './sales-order/sales-order.component';
import { CustomFormatsComponent } from './custom-formats/custom-formats.component';  
import { ViewPurchaseDetailComponent } from './view-purchase-detail/view-purchase-detail.component';


const routes: Routes = [
  {path: '', component: HomeComponent,
    children: [
     {path: 'syncsalesorder', component: SyncSalesOrderComponent, canActivate: [AuthGuard]},
     {path: 'viewsalesorder', component: ViewSalesOrderComponent, canActivate: [AuthGuard]},  
     {path: 'viewpurchaseinvoice', component: ViewPurchaseInvoiceComponent, canActivate: [AuthGuard]},
     {path: 'viewpurchasedetail', component: ViewPurchaseDetailComponent, canActivate: [AuthGuard]},

     {path: 'viewordermaster', component: ViewOrderMasterComponent, canActivate: [AuthGuard]},      
{path: 'viewstock', component: ViewStockComponent, canActivate: [AuthGuard]},
{path: 'viewsalesreceipt', component: ViewSalesReceiptComponent, canActivate: [AuthGuard]},
{path: 'viewproductinfo', component: ViewProductInfoComponent, canActivate: [AuthGuard]},            
     {path: 'importpurchaseorder', component: ImportPurchaseOrderComponent, canActivate: [AuthGuard]},
     {path: 'importordermaster', component: ImportOrderMasterComponent, canActivate: [AuthGuard]},
     {path: 'purchaseinvoice', component: PurchaseInvoiceComponent, canActivate: [AuthGuard]},     
     {path: 'lead', component: LeadComponent, canActivate: [AuthGuard]},     
     {path: 'template', component: MessageTemplateComponent, canActivate: [AuthGuard]},     
     {path: 'salesorder', component: SalesOrderComponent, canActivate: [AuthGuard]},      
     {path: 'customformats', component: CustomFormatsComponent, canActivate: [AuthGuard]},           
      ]},
    { path: 'login', component: LoginComponent },
    { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }