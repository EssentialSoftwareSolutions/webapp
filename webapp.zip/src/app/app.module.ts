import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HomeComponent } from './home';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './login';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { MatNativeDateModule,DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE, MatDateFormats } from '@angular/material/core';
import {MatMomentDateModule, MomentDateAdapter} from '@angular/material-moment-adapter';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
//import { MatSelectFilterModule } from 'mat-select-filter';
import { MatSelectModule } from '@angular/material/select';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatToolbarModule } from '@angular/material/toolbar';
import { NavigationComponent } from './navigation/navigation.component';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { AgGridModule } from 'ag-grid-angular';
import { SyncSalesOrderComponent } from './sync-sales-order/sync-sales-order.component';
import { ImportPurchaseOrderComponent } from './import-purchase-order/import-purchase-order.component';
import { ImportOrderMasterComponent } from './import-order-master/import-order-master.component';
import { PurchaseInvoiceComponent } from './purchase-invoice/purchase-invoice.component';
import {EditPurchaseInvoiceComponent} from './purchase-invoice/dialogs/edit/edit.purchaseinvoice.component';
import {DeletePurchaseInvoiceComponent} from './purchase-invoice/dialogs/delete/delete.purchaseinvoice.component';

import {MessageTemplateComponent} from './message-template/message-template.component';
import {AddMessageTemplateComponent} from './message-template/dialogs/add/add.message-template.component';
import {EditMessageTemplateComponent} from './message-template/dialogs/edit/edit.message-template.component';
import {DeleteMessageTemplateComponent} from './message-template/dialogs/delete/delete.message-template.component';

import {LeadComponent} from './lead/lead.component';
import {AddLeadComponent} from './lead/dialogs/add/add.lead.component';
import {EditLeadComponent} from './lead/dialogs/edit/edit.lead.component';
import {DeleteLeadComponent} from './lead/dialogs/delete/delete.lead.component';

import { SalesOrderComponent } from './sales-order/sales-order.component';
import {EditSalesOrderComponent} from './sales-order/dialogs/edit/edit.salesorder.component';

import { ViewSalesOrderComponent } from './view-sales-order/view-sales-order.component';
import { ViewPurchaseInvoiceComponent } from './view-purchase-invoice/view-purchase-invoice.component';
import { ViewOrderMasterComponent } from './view-order-master/view-order-master.component';
import { ViewStockComponent } from './view-stock/view-stock.component';
import { ViewProductInfoComponent } from './view-productinfo/view-productinfo.component';
import { ViewSalesReceiptComponent } from './view-salesreceipt/view-salesreceipt.component';
import { MessageTemplateService } from './services/messagetemplate.service';
import { LeadService } from './services/lead.service';
import { ExcelService } from './services/excel.service';
import {LoginInfoService} from './services/logininfo.service';
import { PurchaseInvoiceService } from './services/purchaseinvoice.service';
import { SalesOrderService } from './services/salesorder.service';
import { StockService } from './services/stock.service';
import { CustomFontService } from './services/custom-font.service';
import { NotificationService } from './services/notification.service';

import { NgxSpinnerModule } from "ngx-spinner";
import { Numberwith2decimalDirective } from './numberwith2decimal.directive';
import { UpdateOrderMasterComponent } from './update-order-master/update-order-master.component';
import { CustomFormatsComponent } from './custom-formats/custom-formats.component';  
import {DatePipe} from '@angular/common';
import { ViewPurchaseDetailComponent } from './view-purchase-detail/view-purchase-detail.component';


export const MY_FORMATS: MatDateFormats  = {
    parse: {
        dateInput: 'DD.MM.YYYY',
    },
    display: {
        dateInput: 'DD.MM.YYYY',
        monthYearLabel: 'MM YYYY',
        dateA11yLabel: 'DD.MM.YYYY',
        monthYearA11yLabel: 'MM YYYY',
    },
};

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    NavigationComponent,
    SyncSalesOrderComponent,
    ImportPurchaseOrderComponent,
    ImportOrderMasterComponent,    
    ViewSalesOrderComponent,
    ViewPurchaseInvoiceComponent,
    ViewOrderMasterComponent,
    ViewStockComponent,
    ViewProductInfoComponent,
    ViewSalesReceiptComponent,    
    PurchaseInvoiceComponent,
    EditPurchaseInvoiceComponent,
    DeletePurchaseInvoiceComponent,    
    LeadComponent,
    AddLeadComponent,
    EditLeadComponent,
    DeleteLeadComponent,    
    MessageTemplateComponent,
    AddMessageTemplateComponent,
    EditMessageTemplateComponent,
    DeleteMessageTemplateComponent,    
    SalesOrderComponent,
    EditSalesOrderComponent,
    Numberwith2decimalDirective,
    UpdateOrderMasterComponent,
    CustomFormatsComponent,
    ViewPurchaseDetailComponent
  ],
  imports: [
    AppRoutingModule,
    BrowserAnimationsModule,
    NgxSpinnerModule,
    NgxMatSelectSearchModule,
    BrowserModule,
    FormsModule,
    HttpClientModule,
    MatButtonModule,
    MatCardModule,
    MatCheckboxModule,       
    MatDialogModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatSelectModule,
    MatSidenavModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatToolbarModule,
    ReactiveFormsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatMomentDateModule,
    //MatSelectFilterModule,
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production }),
    AgGridModule.withComponents([])  
  ],
  entryComponents: [EditPurchaseInvoiceComponent,DeletePurchaseInvoiceComponent,AddLeadComponent,EditLeadComponent,DeleteLeadComponent,AddMessageTemplateComponent,EditMessageTemplateComponent,DeleteMessageTemplateComponent,EditSalesOrderComponent],  
  providers: [ExcelService,DatePipe,PurchaseInvoiceService,SalesOrderService,NotificationService,StockService,LoginInfoService,CustomFontService,LeadService,MessageTemplateService,{ provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }],
  bootstrap: [AppComponent]
})
export class AppModule { }