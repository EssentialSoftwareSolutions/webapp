import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomFormatsComponent } from './custom-formats.component';

describe('CustomFormatsComponent', () => {
  let component: CustomFormatsComponent;
  let fixture: ComponentFixture<CustomFormatsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomFormatsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomFormatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
