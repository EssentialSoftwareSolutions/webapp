import { Component, OnInit,AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE, MatDateFormats}  from '@angular/material/core';
//import * as jsPDF from 'jspdf';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse,HttpErrorResponse,HttpUrlEncodingCodec } from '@angular/common/http';
import { environment } from '@environments/environment';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {FormControl, Validators} from '@angular/forms';
import { DatePipe, formatDate } from '@angular/common';
import { CustomFontService } from '../services/custom-font.service';
import AES from 'crypto-js/aes';
import Utf8 from 'crypto-js/enc-utf8';
import { ReplaySubject, Subject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';

const ANOTHER_FORMATS: MatDateFormats  = {
    parse: {
        dateInput: 'DD/MM/YYYY',
    },
    display: {
        dateInput: 'DD/MM/YYYY',
        monthYearLabel: 'MM YYYY',
        dateA11yLabel: 'DD.MM.YYYY',
        monthYearA11yLabel: 'MM YYYY',
    },
};

@Component({
  selector: 'app-custom-formats',
  templateUrl: './custom-formats.component.html',
  styleUrls: ['./custom-formats.component.css'],
  providers: [{provide: MAT_DATE_FORMATS, useValue: ANOTHER_FORMATS},DatePipe]
})
export class CustomFormatsComponent implements OnInit,AfterViewInit {
 name: string = 'Angular';
//codec = new HttpUrlEncodingCodec;
customername: string="";
formatname: string;
Courier: string="";
RefCourier: string="";
TrackNo: string="";
getcustomerdata: any;
docprintdate = new FormControl();
SendMail = new FormControl();  
CustomerFilterCtrl = new FormControl();
public filteredCustomers: ReplaySubject<[]> = new ReplaySubject<[]>(0);

InvoiceFilterCtrl = new FormControl();
public filteredInvoices: ReplaySubject<[]> = new ReplaySubject<[]>(0);

ProductMultiFilterCtrl = new FormControl();
public filteredProductsMulti: ReplaySubject<[]> = new ReplaySubject<[]>(0);

printdate: string="";
invoiceno: string="";
invoicedate: string="";
datetext: string="";
totext: string="";
subjecttext: string="";
bodytext: string="";
bodytext2: string="";
footertext: string="";
startX: number;
startY: number;
endX:number;
fontSize:number;
lineSpacing:number;
doc: any;

getinvoicedata: any;
getproductdata: any;
apitoken: string;
selectedInvoice: any;
selectedCustomer: any;
selectedProduct: any;
getinvoicedetail: any;
getselectedproduct: any;
pdfbase64: any;
RecipientEmailId: string;
RecipientName: string;
currentuser: any;
protected _onDestroy = new Subject<void>();
protected _onDestroyinv = new Subject<void>();
protected _onDestroyprod = new Subject<void>();

  @ViewChild('content', {static: false}) content: ElementRef;

  constructor(private httpClient: HttpClient,private datePipe: DatePipe,private customfontService: CustomFontService) { 

  }


ngOnInit(): void {  

this.apitoken=AES.decrypt(sessionStorage.getItem('key'), environment.encryptionkey).toString(Utf8); 
this.currentuser=JSON.parse(sessionStorage.getItem('currentUser'));

var date = new Date();
//this.PrintDate.setValue(this.datePipe.transform(date,"yyyy-MM-dd"));
this.printdate=this.datePipe.transform(date,"yyyy-MM-dd");
//alert(this.printdate);

   this.InvoiceFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroyinv))
      .subscribe(() => {
        this.filterInvoices();
      });


   this.CustomerFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterCustomers();
      });

   this.ProductMultiFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroyprod))
      .subscribe(() => {
        this.filterProductsMulti();
      });

  }

 ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();

    this._onDestroyinv.next();
    this._onDestroyinv.complete();    

    this._onDestroyprod.next();
    this._onDestroyprod.complete();     
  }

ngAfterViewInit(): void {
 
    this.getinvoicedata = [];

 let headers : any = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded','token': this.apitoken })

    this.httpClient.get<any>(`${environment.apiUrl}/getpurchaseinvoicelist`,{headers: headers}).subscribe(data => {     
    this.getinvoicedata=data;
    this.filteredInvoices.next(this.getinvoicedata.slice()); 
    //    alert(JSON.stringify(data));
      },
      (error: HttpErrorResponse) => {
      alert(JSON.stringify(error));
      });
    this.getcustomerdata=[];
    this.getproductdata=[]; 
    this.httpClient.get<any>(`${environment.apiUrl}/salesorder/unship`,{headers: headers}).subscribe(data => {     
    this.getcustomerdata=data;

    this.filteredCustomers.next(this.getcustomerdata.slice());    
    //    alert(JSON.stringify(data));
      },
      (error: HttpErrorResponse) => {
      alert(JSON.stringify(error));
      });


}


public downloadPDF() {


this.generate();

 this.startX = 60;
if (this.formatname== "TranShipment Letter" || this.formatname== "Transfer Of Courier To Cargo" ) {
  this.startY = 200;	
}
else if (this.formatname=="End User Letter"){
  this.startY = 165; 
}
else if (this.formatname=="Sales Order Declaration" || this.formatname=="End User Declaration"){
 this.startY = 165;  
}
else {
  this.startY = 280;	
}

this.endX = 500;
if (this.formatname=="Sales Order Declaration") {
  this.fontSize = 12;
}
else {
  this.fontSize = 14;
}
this.lineSpacing = 1;

//this.doc = new jsPDF({orientation: "p",unit: "pt",format: "letter",lineHeight: this.lineSpacing}); 

this.doc = new jsPDF({orientation: "p",unit: "pt",format: "letter",compress: true}); 

this.customfontService.AddFontCalibri(this.doc);

var img = new Image();


this.doc.setFont("calibri","normal");
//this.doc.setFontType("normal");

this.doc.setFontSize(this.fontSize);
if (this.formatname=="Sales Order Declaration") {
this.doc.text(this.doc.internal.pageSize.width  - (this.doc.getStringUnitWidth(this.datetext) * this.doc.internal.getFontSize() )-50  
, this.startY, this.datetext);

this.doc.setFont("calibri","bold");
this.doc.setFontSize(14);
this.startY = this.startY + 30;
this.doc.text((this.doc.internal.pageSize.width / 2) - (this.doc.getStringUnitWidth(this.totext) * this.doc.internal.getFontSize() / 2)  
, this.startY, this.totext);
const textWidth = this.doc.getTextWidth(this.totext);
this.doc.line((this.doc.internal.pageSize.width / 2) - (this.doc.getStringUnitWidth(this.totext) * this.doc.internal.getFontSize() / 2)  , this.startY+3, (this.doc.internal.pageSize.width / 2) - (this.doc.getStringUnitWidth(this.totext) * this.doc.internal.getFontSize() / 2)   + textWidth, this.startY+3)

this.doc.setFont("calibri","normal");
this.doc.setFontSize(this.fontSize);
}
else {
this.doc.text(this.startX, this.startY, this.datetext);
this.startY = this.startY + 40;
this.doc.text(this.startX, this.startY, this.totext);
  
}

if (this.subjecttext != '') {
   if (this.formatname=="Sales Order Declaration") {
    this.startY = this.startY + 30;
    this.doc.setFont("calibri","bold");
    this.doc.setFontSize(14);
   this.subjecttext=this.doc.splitTextToSize(this.subjecttext,this.endX);
   this.doc.text(this.subjecttext,(this.doc.internal.pageSize.width / 2) - (this.doc.getStringUnitWidth(this.subjecttext) * this.doc.internal.getFontSize() / 2)  ,this.startY);
   this.doc.setFont("calibri","normal");
   this.doc.setFontSize(this.fontSize);
   }
   else {
   if (this.formatname=="TranShipment Letter") {
      this.startY = this.startY + 95;
   }
   else {
      this.startY = this.startY + 80;
   }
   this.subjecttext=this.doc.splitTextToSize(this.subjecttext,this.endX);
   this.doc.text(this.subjecttext,this.startX,this.startY);

   }
   
 
  if (this.formatname== "TranShipment Letter") {
    this.startY = this.startY + 60;    	
  }
  else if (this.formatname=="Sales Order Declaration") {
    this.startY = this.startY + 30;     
  }
  else {
    this.startY = this.startY + 40;    	
  }
}
else {
this.startY = this.startY + 100;	
}

this.printboldnormal(this.bodytext);

this.startY += 10;

this.printboldnormal(this.bodytext2);

if (this.formatname== "TranShipment Letter" || this.formatname== "Transfer Of Courier To Cargo" || this.formatname== "End User Letter" || this.formatname=="Sales Order Declaration") {
this.startY += 25;	
}
else {
this.startY += 100;	
}

if (this.formatname== "End User Letter") {
this.startY -= 25;  
var columns = [
    {title: "Sr No.", dataKey: "SrNo"},
    {title: "Product Id", dataKey: "ProductId"},
    {title: "Product Desc", dataKey: "ProductDescription"}, 
    {title: "CAS No", dataKey: "CASNo"}, 
    {title: "Qty", dataKey: "Qty"}
];
this.doc.setFont("calibri","normal");
//this.doc.setFontType("normal");

this.doc.autoTable(columns, this.getinvoicedetail,
{margin: {right: 50, left: 45},styles: {overflow: 'linebreak', font: "calibri",cellPadding: 1},theme: 'grid', startY: this.startY, 
 columnStyles: {
     SrNo: {columnWidth: 35},ProductId:{columnWidth: 75},
     CASNo:{columnWidth: 90},ProductDescription:{columnWidth: 300},Qty:{columnWidth: 35,halign:'right'}
    }});
this.startY=this.doc.autoTable.previous.finalY+40;

this.doc.setFont("calibri","normal");
//this.doc.setFontType("normal");
//alert(this.doc.internal.pageSize.getHeight()-100);
//alert(this.startY);
if (this.startY > (this.doc.internal.pageSize.getHeight()-100)) {
    this.doc.addPage();
    this.startY = 50;
}
this.doc.text(this.footertext,this.startX,this.startY);
if ((this.startY+65) > (this.doc.internal.pageSize.getHeight()-100)) {
    this.doc.addPage();
    this.startY = 50;
}
img.src = '../../assets/jinay_round_stamp.png';
this.doc.addImage(img, 'PNG',290,this.startY+65);

if ((this.startY+100) > (this.doc.internal.pageSize.getHeight()-100)) {
    this.doc.addPage();
    this.startY = 50;
}

img.src = '../../assets/'+ this.currentuser["data"].Login_Name +'.png';
this.doc.addImage(img, 'PNG',30,this.startY+100);


//this.doc.restoreGraphicsState();

var i;
var totalPages = this.doc.internal.getNumberOfPages();

this.doc.setPage(1);
this.doc.saveGraphicsState();
this.doc.setGState(new this.doc.GState({opacity: 1}));

img.src = '../../assets/jinay_letter_head.png';
this.doc.addImage(img, 'PNG',10,5);

this.doc.restoreGraphicsState();

img.src = '../../assets/jinay_logo.png';
for (i = 1; i <= totalPages; i++) {
    this.doc.setPage(i);
    this.doc.saveGraphicsState();
    this.doc.setGState(new this.doc.GState({opacity: 0.45}));

    this.doc.addImage(img, 'PNG',360,415);

    this.doc.restoreGraphicsState();
}

this.doc.saveGraphicsState();
this.doc.setGState(new this.doc.GState({opacity: 1}));
this.doc.restoreGraphicsState();


}
else if (this.formatname == "Sales Order Declaration") {
this.startY -= 25;  
var columns = [
    {title: "Company Name", dataKey: "CustomerName"},
    {title: "CAS No", dataKey: "CAS"},
    {title: "Chemical Name", dataKey: "ChemicalName"} 
];
this.doc.setFont("calibri","normal");

this.doc.autoTable(columns, this.getselectedproduct,
{margin: {right: 50, left: 45},styles: {overflow: 'linebreak', font: "calibri",cellPadding: 1},theme: 'grid', startY: this.startY});
this.startY=this.doc.autoTable.previous.finalY+35;

var i;
var totalPages = this.doc.internal.getNumberOfPages();

this.doc.setPage(1);
this.doc.saveGraphicsState();
this.doc.setGState(new this.doc.GState({opacity: 1}));

img.src = '../../assets/jinay_letter_head.png';
this.doc.addImage(img, 'PNG',10,5);

this.doc.restoreGraphicsState();

img.src = '../../assets/jinay_logo.png';
for (i = 1; i <= totalPages; i++) {
    this.doc.setPage(i);
    this.doc.saveGraphicsState();
    this.doc.setGState(new this.doc.GState({opacity: 0.45}));

    this.doc.addImage(img, 'PNG',360,415);

    this.doc.restoreGraphicsState();
}


this.doc.saveGraphicsState();
this.doc.setGState(new this.doc.GState({opacity: 1}));

img.src = '../../assets/jinay_sign_logo.png';
this.doc.addImage(img, 'PNG',32,this.startY+50);

img.src = '../../assets/jinay_round_stamp.png';
this.doc.addImage(img, 'PNG',260,this.startY+105);

this.doc.restoreGraphicsState();

this.doc.setFont("calibri","normal");

this.doc.text(this.footertext,this.startX,this.startY);
}
else if (this.formatname == "End User Declaration") {
this.doc.setFont("calibri","normal");
this.doc.saveGraphicsState();

this.doc.setGState(new this.doc.GState({opacity: 1}));

img.src = '../../assets/jinay_letter_head.png';
this.doc.addImage(img, 'PNG',10,5);

img.src = '../../assets/'+ this.currentuser["data"].Login_Name +'.png';
this.doc.addImage(img, 'PNG',45,this.startY);

img.src = '../../assets/jinay_round_stamp.png';
this.doc.addImage(img, 'PNG',260,this.startY);

img.src = '../../assets/jinay_logo.png';
this.doc.addImage(img, 'PNG',360,415);

this.doc.restoreGraphicsState();

this.doc.text(this.footertext,this.startX,this.startY);  
}
else if (this.formatname == "TranShipment Letter") {
this.doc.setFont("calibri","normal");
this.doc.saveGraphicsState();

this.doc.setGState(new this.doc.GState({opacity: 1}));

img.src = '../../assets/jinay_letter_head.png';
this.doc.addImage(img, 'PNG',10,5);

img.src = '../../assets/'+ this.currentuser["data"].Login_Name +'.png';
this.doc.addImage(img, 'PNG',40,this.startY+77);

img.src = '../../assets/jinay_round_stamp.png';
this.doc.addImage(img, 'PNG',290,this.startY+80);

img.src = '../../assets/jinay_logo.png';
this.doc.addImage(img, 'PNG',360,415);

this.doc.restoreGraphicsState();

this.doc.text(this.footertext,this.startX,this.startY);  
}
else if (this.formatname== "Transfer Of Courier To Cargo") {
this.doc.setFont("calibri","normal");
this.doc.saveGraphicsState();

this.doc.setGState(new this.doc.GState({opacity: 1}));

img.src = '../../assets/jinay_letter_head.png';
this.doc.addImage(img, 'PNG',10,5);

img.src = '../../assets/'+ this.currentuser["data"].Login_Name +'.png';
this.doc.addImage(img, 'PNG',40,this.startY+77);

img.src = '../../assets/jinay_round_stamp.png';
this.doc.addImage(img, 'PNG',290,this.startY+85);

img.src = '../../assets/jinay_logo.png';
this.doc.addImage(img, 'PNG',360,415);

this.doc.restoreGraphicsState();

this.doc.text(this.footertext,this.startX,this.startY);  
}
else {
 this.doc.setFont("calibri","normal");
 this.doc.text(this.footertext,this.startX,this.startY);   
}
if (this.formatname == "Sales Order Declaration") {
this.doc.setProperties({
 title: this.customername,
 subject: this.formatname,
 author: 'Jinay Pharma',
 keywords: 'Jinay Pharma,'+this.customername,
 creator: 'System Generated'
});
    this.doc.save(this.customername+ '.pdf');

}
else {
this.doc.setProperties({
 title: this.Courier+' '+this.TrackNo,
 subject: this.formatname,
 author: 'Jinay Pharma',
 keywords: 'Jinay Pharma,'+this.Courier+','+this.TrackNo,
 creator: 'System Generated'
});
    this.doc.save(this.formatname+'-'+this.TrackNo+ '.pdf');
  
}
    this.pdfbase64 = this.doc.output('datauristring').split(',')[1];

    if (this.SendMail.value) {
       let detheader : any = new HttpHeaders({ 'Content-Type': 'application/json','token': this.apitoken });
       let options: any={"RecipientEmailId":this.RecipientEmailId,
       "Content":this.pdfbase64,"FileName":this.formatname+'.pdf',
       "Subject":this.formatname};

       this.httpClient.post<any>(`${environment.apiUrl}/customformat/sendmail`,JSON.stringify(options),{headers:detheader}).subscribe(data => {
       if (data.error) {
          alert(data.message);        
       }
       else {   
            alert("Email Sent Successfully...");  
       }
      },
      err => {
        alert(JSON.stringify(err));
      });   
    }

 //   alert(this.pdfbase64);
  }

isBoldOpen = (arrayLength, valueBefore = false) => {
    const isEven = arrayLength % 2 === 0;
    const result = valueBefore !== isEven;

    return result;
}

generate() {
this.totext="";
this.subjecttext="";
this.bodytext="";
this.bodytext2="";
this.footertext="";

this.datetext = 'Date : ' + this.datePipe.transform(this.printdate,"dd-MM-yyyy");
if (this.formatname== "End User Declaration") {
	this.totext = 'To,\nCommissioner of Customs Mumbai.';

	this.bodytext ='This is to declare that the products imported with **'+ this.Courier+'** Tracking Number: **'+ this.TrackNo + '** are Research Chemicals used in the Research & Development only.';

    this.bodytext2 = 'We further declare that the same cannot be used for personal or household purposes.';

    this.footertext= 'For Jinay Pharmaceuticals Private Limited\n\n\n\n\n\nAuthorized Signatory.';	
}
else if (this.formatname== "TranShipment Letter") {
	this.totext = 'To,\nThe Assistant Commissioner of Customs\nNew Courier Terminal,\nIGI Airport,\nNew Delhi.';

    this.subjecttext ='Subject: Request for allowing transfer of shipment from Courier Cell, Delhi to Air Cargo Complex, Mumbai\nReference: '+ this.RefCourier + ' AWB No. '+ this.TrackNo;

	this.bodytext ='Dear Sir,\n\n\nWith reference to the subject above, we request you to allow '+ this.Courier + ' to transfer the shipment from Courier Cell, Delhi to Air Cargo Complex, Mumbai';

    this.bodytext2 = 'The subject shipment needs to be cleared under **CHA CLEARANCE**';

    this.footertext= 'We hope that you shall do the needful and oblige.\n\n\nThanking You\nYours truly,\nFor JINAY PHARMACEUTICALS PRIVATE LIMITED\n\n\n\n\n\nAuthorized Signatory                            Company Stamp:\nName: '+     this.currentuser["data"].Login_Name
    +' \nDesignation: '+this.currentuser["data"].Login_Designation;
	
}
else if (this.formatname== "Transfer Of Courier To Cargo") {
	this.totext = 'To,\nThe Deputy Commissioner of Customs\nNIPT, Courier Cell, Sahar, Andheri (East),\nMumbai - 400 099';

    this.subjecttext ='Subject: Request for allowing transfer of shipment to Air Cargo Complex, Mumbai\nReference: '+ this.RefCourier + ' AWB No. '+ this.TrackNo;

	this.bodytext ='Dear Sir,\n\n\nWith reference to the subject above, we request you to allow '+ this.Courier + ' to transfer the shipment from Courier Cell, Mumbai to Air Cargo Complex, Mumbai as per the provision stated in Public Notice No. 11/2009 Dated: 20.05.2009';

    this.bodytext2 = 'The subject shipment needs to be cleared under **CHA CLEARANCE**';

    this.footertext= 'We hope that you shall do the needful and oblige.\n\n\nThanking You\nYours truly,\nFor JINAY PHARMACEUTICALS PRIVATE LIMITED\n\n\n\n\n\nAuthorized Signatory                            Company Stamp: \nName: '+ this.currentuser["data"].Login_Name +' \nDesignation: '+this.currentuser["data"].Login_Designation;
	
}
else if (this.formatname== "End User Letter") {
    this.totext = 'To,\nThe Deputy Commissioner of Customs\nSahar Air Cargo Complex,\nINDIA.';

    this.subjecttext ='Ref: '+ this.RefCourier + ' AWB No. '+ this.TrackNo + ' Invoice No '+ this.invoiceno + ' Dt. '+ this.datePipe.transform(this.invoicedate,"dd-MM-yyyy");

	this.bodytext ='Dear Sir/Madam,\n\n\nThis is to certify that the following compounds being imported by us from '+ this.selectedInvoice.SupplierName + '; are purely chemical shipment and not meant for human consumption/application and does not qualify for ADC NOC:';

    this.footertext='The shipment is being imported for analysis purpose only in research laboratory.\nOrigin of goods is from China.\n\nWe indemnify & take responsibility against any mis-declaration.\n\n\nThanking You.';
}
else if (this.formatname== "Sales Order Declaration") {
    this.totext = 'DECLARATION';

    this.subjecttext ='TO WHOM IT MAY CONCERN';
     
    this.bodytext ='This is certifying that the consignment of packets of the below products are for R&D Purpose sending to the list of below customers';

    this.footertext='We further confirm that the products are not harmful, non-hazard and can be carried by any passenger\naircraft or vehicle & no commercial value.\n\n\n\n\nThanking You\n\n\nYours truly,\n\nFor, JINAY PHARMACEUTICALS PRIVATE LIMITED\n\n(Authorized Signatory)';

}
}

printboldnormal(bodytext: string) {
let textMap = this.doc.splitTextToSize(bodytext,this.endX);

const startXCached = this.startX;
    let boldOpen = false;
    textMap.map((text, i) => {
        if (text) {
            const arrayOfNormalAndBoldText = text.split('**');
            const boldStr = 'bold';
            const normalOr = 'normal';            
            arrayOfNormalAndBoldText.map((textItems, j) => {
//                this.doc.setFontType(boldOpen ? normalOr : boldStr);
                this.doc.setFont("calibri",boldOpen ? normalOr : boldStr);                
                if (j % 2 === 0) {
//                    this.doc.setFontType(boldOpen ? boldStr : normalOr);
                    this.doc.setFont("calibri",boldOpen ? boldStr : normalOr);
                }
                this.doc.text(textItems, this.startX, this.startY);
                this.startX = this.startX + this.doc.getStringUnitWidth(textItems) * this.fontSize ;
            });
            boldOpen = this.isBoldOpen(arrayOfNormalAndBoldText.length, boldOpen);
            this.startX = startXCached;
            this.startY += 18;
        }
    });
}

OnInvoiceSelection(){
  //alert(JSON.stringify(this.selectedInvoice));
  this.invoiceno="",
//  this.printdate="";
  this.invoicedate=""; 
  this.Courier="";
  this.TrackNo="";
  this.RefCourier=""; 
  if (typeof this.selectedInvoice != "undefined") {
  //alert("hi");
  this.invoiceno=this.selectedInvoice.InvoiceNo;
  this.invoicedate=this.datePipe.transform(this.selectedInvoice.InvoiceDate,
      'yyyy-MM-dd'); 
  this.printdate=this.datePipe.transform(this.selectedInvoice.InvoiceDate,
      'yyyy-MM-dd');    
  this.Courier=this.selectedInvoice.CourierName;
  this.RefCourier=this.selectedInvoice.CourierName;
  this.TrackNo=this.selectedInvoice.TrackingNo;

  let headers : any = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded','token': this.apitoken })


// alert(JSON.stringify(this.selectedInvoice));
  this.getinvoicedetail=[];
   if (typeof this.selectedInvoice != "undefined") {
  this.httpClient.get(`${environment.apiUrl}/`+'getpurchaseinvoicedetail/'+ this.invoiceno,{headers: headers}).subscribe(data => {  
 // this.getinvoicedetail = data;
  for(var i in data) {
     this.getinvoicedetail.push({"SrNo":data[i].SrNo, "ProductId":data[i].ProductId,"ProductDescription":data[i].ProductDescription,"CASNo":data[i].CASNo,"Qty":data[i].Qty});
  }

//       alert(JSON.stringify(this.getinvoicedetail));
      },
      (error: HttpErrorResponse) => {
      alert(JSON.stringify(error));
      });

   }


  }

 // alert(this.invoicedate);
//  this.PrintDate.setValue(this.selectedInvoice.InvoiceDate);
}

OnProductSelection(){
if (typeof this.selectedProduct != "undefined") {
//   alert(JSON.stringify(this.selectedProduct));
    this.getselectedproduct=[];
    for(var i in this.selectedProduct) {
     this.getselectedproduct.push({"CustomerName":this.customername, "CAS":this.selectedProduct[i].CAS,"ChemicalName":this.selectedProduct[i].DrugNames});
  }
}
//alert(this.getselectedproduct);
}

OnCustomerSelection(){
  //alert(JSON.stringify(this.selectedInvoice));

  this.customername="";

  if (typeof this.selectedCustomer != "undefined") {

  this.customername=this.selectedCustomer.BillCompany;

  let headers : any = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded','token': this.apitoken })

  this.getproductdata=[];
//alert(encodeURIComponent(this.customername));
  this.httpClient.get(`${environment.apiUrl}/`+'salesorder/detail/'+ encodeURIComponent(this.customername),{headers: headers}).subscribe(data => {  
  this.getproductdata = data;
  this.filteredProductsMulti.next(this.getproductdata.slice());   
      },
      (error: HttpErrorResponse) => {
      alert(JSON.stringify(error));
      });
  }
}

OnFormatSelection(){
   var date = new Date();
   this.printdate=this.datePipe.transform(date,"yyyy-MM-dd"); 
}


addWaterMark(doc) {
  return doc;
}

  protected filterCustomers() {
    if (!this.getcustomerdata) {
      return;
    }
    // get the search keyword
    let search = this.CustomerFilterCtrl.value;
    if (!search) {
      this.filteredCustomers.next(this.getcustomerdata.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the customer
  //  alert("filter start");
    this.filteredCustomers.next(
      this.getcustomerdata.filter(customer => customer.BillCompany.toLowerCase().indexOf(search) > -1)
    );
  }

  protected filterInvoices() {
    if (!this.getinvoicedata) {
      return;
    }

   // alert("get inv data found");
    // get the search keyword
    let search = this.InvoiceFilterCtrl.value;
    if (!search) {
      this.filteredInvoices.next(this.getinvoicedata.slice());
      
      return;
    } else {
      search = search.toLowerCase();
    }
//    alert("filter start");
    // filter the customer
    this.filteredInvoices.next(
      this.getinvoicedata.filter(invoice => invoice.Id.toString().indexOf(search) > -1)
    );
  }

protected filterProductsMulti() {
    if (!this.getproductdata) {
      return;
    }
    // get the search keyword
    let search = this.ProductMultiFilterCtrl.value;
    if (!search) {
      this.filteredProductsMulti.next(this.getproductdata.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredProductsMulti.next(
      this.getproductdata.filter(prod => prod.CAS.toLowerCase().indexOf(search) > -1)
    );
  }

}
