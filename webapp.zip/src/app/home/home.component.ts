﻿import { Component } from '@angular/core';
import { first } from 'rxjs/operators';
import { Router } from '@angular/router';
import { AuthenticationService } from '../_services';
import { User } from '@app/_models';

@Component({ templateUrl: 'home.component.html' })
export class HomeComponent {
    loading = false;
    users: User[];

    constructor(private authenticationService: AuthenticationService,private router: Router) { }

    ngOnInit() {
    //    alert("home");
        this.loading = true;
    }


}