import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportOrderMasterComponent } from './import-order-master.component';

describe('ImportOrderMasterComponent', () => {
  let component: ImportOrderMasterComponent;
  let fixture: ComponentFixture<ImportOrderMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportOrderMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportOrderMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
