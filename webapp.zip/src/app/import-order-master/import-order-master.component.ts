import { Component, OnInit } from '@angular/core';
import * as XLSX from 'xlsx';
import {ExcelService} from '../services/excel.service';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { environment } from '@environments/environment';
import AES from 'crypto-js/aes';
import Utf8 from 'crypto-js/enc-utf8';

@Component({
  selector: 'app-import-order-master',
  templateUrl: './import-order-master.component.html',
  styleUrls: ['./import-order-master.component.css']
})
export class ImportOrderMasterComponent implements OnInit {
  willDownload = false;
  apitoken: string;
//  invhdr: InvHeader;
     IsWait: boolean;

     InvdetObj: any=[];

  constructor(private excelService:ExcelService,private http: HttpClient) { }

  ngOnInit(): void {
   this.apitoken=AES.decrypt(sessionStorage.getItem('key'), environment.encryptionkey).toString(Utf8); 
  }

  onFileChange(ev) {
this.InvdetObj=[];
let TypeofSales="";
let SalesPerson="";
let Discount="";
let Region="";
let CompanyName="";
let PurchaseOrderNumber="";
let PurchaseOrderDate="";
let StockLocation="";
let CreditDays=0;
let ProductCategory="";
let CSNo="";
let CASNo="";
let Qty=0;
let Packing=0;
let Unit="";
let Amount=0;
let GST=0;
let Total=0;
let ImportPONO="";
let ImportPODate="";
let ShipmentNo="";
let ImportTrackingNO="";
let State="";
let City="";
let ShipToAddress="";
let ShipmentDate="";
let Courier="";
let TrackingNumber="";
let ChemsceneOrderNo="";
let ChemsceneInvoiceNo="";
let DeliveredOn="";
let ReceivedBy="";
let PaymentTerm="";
let PaymentStatus="";
let Remarks="";
let DueOn="";
let IsDue="";
var origindate = new Date("1900/01/01");

    let workBook = null;
    let jsonData = null;
    let lineno = 0;
    this.IsWait = true;
    const reader = new FileReader();
    const file = ev.target.files[0];
    reader.onload = (event) => {      
      const data = reader.result;
      workBook = XLSX.read(data, { type: 'binary' });
      jsonData = workBook.SheetNames.reduce((initial, name) => {
        const sheet = workBook.Sheets[name];
        initial[name] = XLSX.utils.sheet_to_json(sheet);
        return initial;
      }, {});
      
     const dataString = JSON.stringify(jsonData);
     const sheetname = Object.keys(jsonData)[0];
     console.log(sheetname);
  
  //   alert(Object.keys(jsonData[sheetname]).length);
  // return
//alert("delete api");

//return
     
    // alert(jsonData[sheetname][0]["Type of Sales"]);
        for (lineno = 0; lineno < Object.keys(jsonData[sheetname]).length; lineno++) {
    //    this.InvdetObj=[];  
        TypeofSales="";
SalesPerson="";
Discount="";
Region="";
CompanyName="";
PurchaseOrderNumber="";
PurchaseOrderDate="";
StockLocation="";
CreditDays=0;
ProductCategory="";
CSNo="";
CASNo="";
Qty=0;
Packing=0;
Unit="";
Amount=0;
GST=0;
Total=0;
ImportPONO="";
ImportPODate="";
ShipmentNo="";
ImportTrackingNO="";
State="";
City="";
ShipToAddress="";
ShipmentDate="";
Courier="";
TrackingNumber="";
ChemsceneOrderNo="";
ChemsceneInvoiceNo="";
DeliveredOn="";
ReceivedBy="";
PaymentTerm="";
PaymentStatus="";
Remarks="";
DueOn="";
IsDue="";

        var podate = new Date(origindate);
        var imppodate = new Date(origindate);
        var shipdate = new Date(origindate);
        var deliverydate = new Date(origindate);
        var duedate= new Date(origindate);
        if (jsonData[sheetname][lineno].hasOwnProperty("Type of Sales")) {
           TypeofSales=jsonData[sheetname][lineno]["Type of Sales"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Sales Person")) {
           SalesPerson=jsonData[sheetname][lineno]["Sales Person"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Discount")) {
           Discount=jsonData[sheetname][lineno]["Discount"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Region")) {
           Region=jsonData[sheetname][lineno]["Region"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Company Name")) {
           CompanyName=jsonData[sheetname][lineno]["Company Name"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Purchase Order Number")) {
           PurchaseOrderNumber=jsonData[sheetname][lineno]["Purchase Order Number"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Purchase Order Date")) {
           PurchaseOrderDate=jsonData[sheetname][lineno]["Purchase Order Date"];
           podate.setDate(podate.getDate() + Number(PurchaseOrderDate)-1);
           PurchaseOrderDate= podate.toISOString().slice(0,10);
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Stock Location")) {
           StockLocation=jsonData[sheetname][lineno]["Stock Location"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Credit Days")) {
           CreditDays=jsonData[sheetname][lineno]["Credit Days"];
        }                                                        

        if (jsonData[sheetname][lineno].hasOwnProperty("Product Category")) {
           ProductCategory=jsonData[sheetname][lineno]["Product Category"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("CS No")) {
           CSNo=jsonData[sheetname][lineno]["CS No"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("CAS No")) {
           CASNo=jsonData[sheetname][lineno]["CAS No"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Qty")) {
           Qty=jsonData[sheetname][lineno]["Qty"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Packing")) {
           Packing=jsonData[sheetname][lineno]["Packing"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Unit")) {
           Unit=jsonData[sheetname][lineno]["Unit"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty(" Amount ")) {
           Amount=jsonData[sheetname][lineno][" Amount "];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty(" GST ")) {
           GST=jsonData[sheetname][lineno][" GST "];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty(" Total  ")) {
           Total=jsonData[sheetname][lineno][" Total  "];
        }                                                        
        if (jsonData[sheetname][lineno].hasOwnProperty(" Import PO NO ")) {
           ImportPONO=jsonData[sheetname][lineno][" Import PO NO "];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Import PO Date")) {
           ImportPODate=jsonData[sheetname][lineno]["Import PO Date"];
           imppodate.setDate(imppodate.getDate() + Number(ImportPODate)-1);
           ImportPODate= imppodate.toISOString().slice(0,10);

        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Shipment No")) {
           ShipmentNo=jsonData[sheetname][lineno]["Shipment No"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Import Tracking NO")) {
           ImportTrackingNO=jsonData[sheetname][lineno]["Import Tracking NO"];
        }                                                        
        if (jsonData[sheetname][lineno].hasOwnProperty("State")) {
           State=jsonData[sheetname][lineno]["State"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("City")) {
           City=jsonData[sheetname][lineno]["City"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Ship To  Address")) {
           ShipToAddress=jsonData[sheetname][lineno]["Ship To  Address"];
        }                                                  

        if (jsonData[sheetname][lineno].hasOwnProperty("Shipment Date")) {
           ShipmentDate=jsonData[sheetname][lineno]["Shipment Date"];
           shipdate.setDate(shipdate.getDate() + Number(ShipmentDate)-1);
           ShipmentDate= shipdate.toISOString().slice(0,10);           
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Courier ")) {
           Courier=jsonData[sheetname][lineno]["Courier "];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Tracking Number")) {
           TrackingNumber=jsonData[sheetname][lineno]["Tracking Number"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Chemscene Order No")) {
           ChemsceneOrderNo=jsonData[sheetname][lineno]["Chemscene Order No"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Chemscene Invoice No")) {
           ChemsceneInvoiceNo=jsonData[sheetname][lineno]["Chemscene Invoice No"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Delivered On")) {
           DeliveredOn=jsonData[sheetname][lineno]["Delivered On"];
           deliverydate.setDate(deliverydate.getDate() + Number(DeliveredOn)-1);
           DeliveredOn= deliverydate.toISOString().slice(0,10);            
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Received By")) {
           ReceivedBy=jsonData[sheetname][lineno]["Received By"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Payment Term")) {
           PaymentTerm=jsonData[sheetname][lineno]["Payment Term"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Payment Status")) {
           PaymentStatus=jsonData[sheetname][lineno]["Payment Status"];
        }                                                        
       if (jsonData[sheetname][lineno].hasOwnProperty("Remarks")) {
           Remarks=jsonData[sheetname][lineno]["Remarks"];
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Due On")) {
           DueOn=jsonData[sheetname][lineno]["Due On"];
           duedate.setDate(duedate.getDate() + Number(DueOn)-1);
           DueOn= duedate.toISOString().slice(0,10);            
        }
        if (jsonData[sheetname][lineno].hasOwnProperty("Is Due")) {
           IsDue=jsonData[sheetname][lineno]["Is Due"];
        }

       this.InvdetObj.push({TypeofSales:TypeofSales,SalesPerson:SalesPerson,
       Discount:Discount,Region:Region,CompanyName:CompanyName,
       PurchaseOrderNumber:PurchaseOrderNumber,
       PurchaseOrderDate:PurchaseOrderDate,
       StockLocation:StockLocation,CreditDays:CreditDays,
       ProductCategory:ProductCategory,CSNo:CSNo,CASNo:CASNo,Qty:Qty,
       Packing:Packing,Unit:Unit,Amount:Amount,GST:GST,Total:Total,
       ImportPONO:ImportPONO,ImportPODate:ImportPODate,ShipmentNo,
       ImportTrackingNO:ImportTrackingNO,State:State,City:City,
       ShipToAddress:ShipToAddress,ShipmentDate:ShipmentDate,
       Courier:Courier,TrackingNumber:TrackingNumber,
       ChemsceneOrderNo:ChemsceneOrderNo,
       ChemsceneInvoiceNo:ChemsceneInvoiceNo,DeliveredOn:DeliveredOn,
       ReceivedBy:ReceivedBy,
       PaymentTerm:PaymentTerm,PaymentStatus:PaymentStatus,
       Remarks:Remarks,DueOn:DueOn,IsDue:IsDue});            
      
        }
// alert(JSON.stringify(this.InvdetObj));     
//alert("after posting");
//return
            let detheader : any = new HttpHeaders({ 'Content-Type': 'application/json','token': this.apitoken })
             this.http.delete<any>(`${environment.apiUrl}/importorder`,{headers:detheader}).subscribe(data => {
              if (data.error) {
                 alert(data.message);        
                 return
              }
              else {   
//                   alert("Order Master Imported Successfully...");  
              }
              },
              err => {
               alert(JSON.stringify(err));
               return
              });

             this.http.post<any>(`${environment.apiUrl}/importorder`,JSON.stringify(this.InvdetObj),{headers:detheader}).subscribe(data => {
              if (data.error) {
                 alert(data.message);        
              //   return
              }
              else {   
                   alert("Order Master Imported Successfully...");  
              }
              },
              err => {
               alert(JSON.stringify(err));
               //return
              });


     this.IsWait = false;



      /*document.getElementById('output').innerHTML = dataString.slice(0, 300).concat("...");
      this.setDownload(dataString);    */
    }

    reader.readAsBinaryString(file);

  }
 

  setDownload(data) {
    this.willDownload = true;
    setTimeout(() => {
      const el = document.querySelector("#download");
      el.setAttribute("href", `data:text/json;charset=utf-8,${encodeURIComponent(data)}`);
      el.setAttribute("download", 'xlsxtojson.json');
    }, 1000)
  }
}
