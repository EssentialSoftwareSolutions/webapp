import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportPurchaseOrderComponent } from './import-purchase-order.component';

describe('ImportPurchaseOrderComponent', () => {
  let component: ImportPurchaseOrderComponent;
  let fixture: ComponentFixture<ImportPurchaseOrderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportPurchaseOrderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportPurchaseOrderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
