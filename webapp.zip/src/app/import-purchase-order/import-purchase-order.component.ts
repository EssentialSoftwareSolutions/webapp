import { Component, OnInit } from '@angular/core';
import * as XLSX from 'xlsx';
import {ExcelService} from '../services/excel.service';
import {InvHeader} from '../models/InvHeader';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE, MatDateFormats}  from '@angular/material/core';

import {InvDetail} from '../models/InvDetail';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { environment } from '@environments/environment';
import {FormControl, Validators} from '@angular/forms';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { DatePipe, formatDate } from '@angular/common';
import { NotificationService } from '../services/notification.service';
import AES from 'crypto-js/aes';
import Utf8 from 'crypto-js/enc-utf8';

const ANOTHER_FORMATS: MatDateFormats  = {
    parse: {
        dateInput: 'DD/MM/YYYY',
    },
    display: {
        dateInput: 'DD/MM/YYYY',
        monthYearLabel: 'MM YYYY',
        dateA11yLabel: 'DD.MM.YYYY',
        monthYearA11yLabel: 'MM YYYY',
    },
};


@Component({
  selector: 'app-import-purchase-order',
  templateUrl: './import-purchase-order.component.html',
  styleUrls: ['./import-purchase-order.component.css'],
  providers: [{provide: MAT_DATE_FORMATS, useValue: ANOTHER_FORMATS},DatePipe]  
})
export class ImportPurchaseOrderComponent implements OnInit {
  willDownload = false;
  apitoken: string;
  invoicedt = new FormControl();
  ImportInvDetail = new FormControl();  
  purchaseorderdate = new FormControl();
//  invhdr: InvHeader;
     IsWait: boolean;

     InvHdrObj = new InvHeader('','','','','','','','','','','','','','','','','','','','','','','','','','',0,0,0,0,'','',0,'',0,0,0);

     InvdetObj: any=[];
     invoiceno: string;
     invoicedate: string;
     orderno: string;
     orderdate: string;
     duedate: string;
     shipdate: string;
     SupplierAddress: string="";
     SupplierAddress2: string="";
     ExcelFormat: string;
     totalqty: number;
     totalamount: number;
  constructor(private excelService:ExcelService,private http: HttpClient,private datePipe: DatePipe,public notificationService: NotificationService) { }

  ngOnInit(): void {
  var date = new Date();
   this.ExcelFormat="Shanghai Kaixin Pharmaceuticals Co., Ltd.";
   this.apitoken=AES.decrypt(sessionStorage.getItem('key'), environment.encryptionkey).toString(Utf8);
   this.InvHdrObj.InvoiceDate=this.datePipe.transform(date,"yyyy-MM-dd");   
   this.InvHdrObj.PurchaseOrderDate=this.datePipe.transform(date,"yyyy-MM-dd");
  }

  onFileChange(ev) {
    let workBook = null;
    let jsonData = null;
    let lineno = 0;
    let footerline = 0;
    let detailline = 0;
    this.IsWait = true;
    this.invoiceno="";
    this.invoicedate="";
    this.orderno="";
    this.orderdate="";
    this.totalqty=0;
    this.totalamount=0;
    let qty =0;
    let amount =0;
    let rate=0;
    const reader = new FileReader();
    const file = ev.target.files[0];
    reader.onload = (event) => {      
      const data = reader.result;
      workBook = XLSX.read(data, { type: 'binary' });
      jsonData = workBook.SheetNames.reduce((initial, name) => {
        const sheet = workBook.Sheets[name];
        initial[name] = XLSX.utils.sheet_to_json(sheet);
        return initial;
      }, {});
      
//     alert("calc footer lines");
     const dataString = JSON.stringify(jsonData);
     if (!this.ImportInvDetail.value) {
   //  alert(this.ImportInvDetail.value);
     if (this.ExcelFormat== "Shanghai Kaixin Pharmaceuticals Co., Ltd." || this.ExcelFormat== "Haoyuan Chemexpress Co., Limited") {
        for (lineno = 0; lineno < Object.keys(jsonData.Invoice).length; lineno++) {
            if (typeof jsonData.Invoice[lineno].__EMPTY_2 !== "undefined") {
               if (jsonData.Invoice[lineno].__EMPTY_2 == "Product ID"){
                  detailline = lineno;
               }
            }         

            if (typeof jsonData.Invoice[lineno].__EMPTY_10 !== "undefined") {
               if (jsonData.Invoice[lineno].__EMPTY_10 == "SUBTOTAL") {
                  footerline = lineno;
               }
            }         
        }
    }
     else {
        for (lineno = 0; lineno < Object.keys(jsonData.MSDS).length; lineno++) {
            if (typeof jsonData.MSDS[lineno].__EMPTY_2 !== "undefined") {
               if (jsonData.MSDS[lineno].__EMPTY_2 == "Product Name"){
                  detailline = lineno;
               }
            }        
            if (typeof jsonData.MSDS[lineno].__EMPTY_11 !== "undefined") {
               if (jsonData.MSDS[lineno].__EMPTY_11.indexOf("Subtotal") >= 0) {
                  footerline = lineno;
               }
            }
        }   
     }

     }
     else { //detail only
  //      alert(Object.keys(jsonData.Sheet1).length);
        for (lineno = 0; lineno < Object.keys(jsonData.Sheet1).length; lineno++) {
            if (typeof jsonData.Sheet1[lineno].__EMPTY_1 !== "undefined") {
               if (jsonData.Sheet1[lineno].__EMPTY_1 == "Product ID"){
                  detailline = lineno;
               }
            }         

            if (typeof jsonData.Sheet1[lineno].__EMPTY_9 !== "undefined") {
               if (jsonData.Sheet1[lineno].__EMPTY_9 == "SUBTOTAL") {
                  footerline = lineno;
               }
            }         
        }

     }
//     alert(detailline);
 //    alert(footerline);
//     return;
//     alert(JSON.stringify(jsonData));
//alert(this.ExcelFormat);

     if (!this.ImportInvDetail.value) {
     if (this.ExcelFormat == "Shanghai Kaixin Pharmaceuticals Co., Ltd." ) {
     for (lineno = 0; lineno < Object.keys(jsonData.Invoice).length; lineno++) {
       switch (lineno) {
       case 1:
            this.InvHdrObj.SupplierName = jsonData.Invoice[lineno].__EMPTY; 
       case 4:
            this.InvHdrObj.InvoiceDate = jsonData.Invoice[lineno].__EMPTY_7;
       case 5:
            this.InvHdrObj.InvoiceNo = jsonData.Invoice[lineno].__EMPTY_7;
       case 6:
            this.InvHdrObj.PurchaseOrderNo = jsonData.Invoice[lineno].__EMPTY_7;
       case (footerline+2):
            this.InvHdrObj.Remark = jsonData.Invoice[lineno].__EMPTY_1;    
       case (footerline+3):
            this.InvHdrObj.InvoiceTerm = jsonData.Invoice[lineno].__EMPTY_1;                         
       case (footerline+4):
            this.InvHdrObj.CountryOfOrigin = jsonData.Invoice[lineno].__EMPTY_1;                         
       case (footerline+5):
            this.InvHdrObj.Declaration = jsonData.Invoice[lineno].__EMPTY_1;                         
       case (footerline+7):
            this.InvHdrObj.SupplierBankName = jsonData.Invoice[lineno].__EMPTY_3;                         
       case (footerline+8):
            this.InvHdrObj.SupplierBankCode = jsonData.Invoice[lineno].__EMPTY_3;
       case (footerline+9):
            this.InvHdrObj.SupplierBankAddress = jsonData.Invoice[lineno].__EMPTY_3;                         
       case (footerline+10):
            this.InvHdrObj.SupplierSwiftCode = jsonData.Invoice[lineno].__EMPTY_3;                         
       case (footerline+11):
            this.InvHdrObj.SupplierAccountName = jsonData.Invoice[lineno].__EMPTY_3;                         
       case (footerline+12):
            this.InvHdrObj.SupplierAccountNo = jsonData.Invoice[lineno].__EMPTY_3;  
       case (footerline+14):
            this.SupplierAddress = jsonData.Invoice[lineno].__EMPTY_4;                         
       case (footerline+15):
            this.SupplierAddress2 = jsonData.Invoice[lineno].__EMPTY_3;     
       case (footerline+16):
            this.InvHdrObj.SupplierTelNo = jsonData.Invoice[lineno].__EMPTY_3;         
       case (footerline+17):
            this.InvHdrObj.SupplierFaxNo = jsonData.Invoice[lineno].__EMPTY_3;                         
       case (footerline+18):
            this.InvHdrObj.SupplierEmailId = jsonData.Invoice[lineno].__EMPTY_3;                        
         }
     }

     }
     else if (this.ExcelFormat == "Haoyuan Chemexpress Co., Limited") {
  //   alert("Haoyuan"); 
     for (lineno = 0; lineno < Object.keys(jsonData.Invoice).length; lineno++) {
         switch (lineno) {
         case 1:
            this.InvHdrObj.SupplierName = jsonData.Invoice[lineno].__EMPTY; 
         case 4:
              this.InvHdrObj.InvoiceDate = jsonData.Invoice[lineno].__EMPTY_7;
         case 5:
            this.InvHdrObj.InvoiceNo = jsonData.Invoice[lineno].__EMPTY_7;
         case 6:
            this.InvHdrObj.PurchaseOrderNo = jsonData.Invoice[lineno].__EMPTY_7;
         case (footerline+2):
            this.InvHdrObj.Remark = jsonData.Invoice[lineno].__EMPTY_1;    
         case (footerline+3):
            this.InvHdrObj.InvoiceTerm = jsonData.Invoice[lineno].__EMPTY_1;                         
         case (footerline+4):
            this.InvHdrObj.CountryOfOrigin = jsonData.Invoice[lineno].__EMPTY_1;                         
         case (footerline+5):
            this.InvHdrObj.Declaration = jsonData.Invoice[lineno].__EMPTY_1;                         
         case (footerline+7):
            this.InvHdrObj.SupplierBankName = jsonData.Invoice[lineno].__EMPTY_3;                         
         case (footerline+8):
            this.InvHdrObj.SupplierBankCode = jsonData.Invoice[lineno].__EMPTY_3;
         case (footerline+9):
            this.InvHdrObj.SupplierBankAddress = jsonData.Invoice[lineno].__EMPTY_3;                         
         case (footerline+10):
            this.InvHdrObj.SupplierSwiftCode = jsonData.Invoice[lineno].__EMPTY_3;                         
         case (footerline+11):
            this.InvHdrObj.SupplierAccountName = jsonData.Invoice[lineno].__EMPTY_3;                         
         case (footerline+12):
            this.InvHdrObj.SupplierAccountNo = jsonData.Invoice[lineno].__EMPTY_3;  
         case (footerline+13):
            this.InvHdrObj.SupplierCertificateNo = jsonData.Invoice[lineno].__EMPTY_3;  
         case (footerline+15):
            this.SupplierAddress = jsonData.Invoice[lineno].__EMPTY_4;                         
         case (footerline+16):
            this.InvHdrObj.SupplierTelNo = jsonData.Invoice[lineno].__EMPTY_4;         
         case (footerline+17):
            this.InvHdrObj.SupplierFaxNo = jsonData.Invoice[lineno].__EMPTY_4;                         
         case (footerline+18):
            this.InvHdrObj.SupplierEmailId = jsonData.Invoice[lineno].__EMPTY_4;   

         }
     }          
     }
     else {
     //  alert("Chemscene"); 
     for (lineno = 0; lineno < Object.keys(jsonData.MSDS).length; lineno++) {
         switch (lineno) {
         case 2:
            this.InvHdrObj.SupplierName = jsonData.MSDS[lineno].__EMPTY;         
         case 3:
            this.InvHdrObj.InvoiceNo = jsonData.MSDS[lineno].__EMPTY_8;
            this.InvHdrObj.PurchaseOrderNo = jsonData.MSDS[lineno].__EMPTY_13; 
            this.SupplierAddress = jsonData.MSDS[lineno].__EMPTY;                         
         case 5:
              this.InvHdrObj.InvoiceDate = jsonData.MSDS[lineno].__EMPTY_8;
              this.SupplierAddress2 = jsonData.MSDS[lineno].__EMPTY;     
         case 6:
              this.InvHdrObj.SupplierTelNo = jsonData.MSDS[lineno].__EMPTY_1;
              this.InvHdrObj.SupplierFaxNo = jsonData.MSDS[lineno].__EMPTY_5;                         
         case 7:
              this.InvHdrObj.SupplierEmailId = jsonData.MSDS[lineno].__EMPTY_2;   
              this.InvHdrObj.PaymentTerm = jsonData.MSDS[lineno].__EMPTY_8; 
         case 9:
              this.InvHdrObj.DueDate = jsonData.MSDS[lineno].__EMPTY_8; 
         case 19:
              this.InvHdrObj.ShipDate = jsonData.MSDS[lineno].__EMPTY;  
              this.InvHdrObj.TrackingNo = jsonData.MSDS[lineno].__EMPTY_8; 
              this.InvHdrObj.CourierName = jsonData.MSDS[lineno].__EMPTY_5;                                         
         case (footerline-1):
              this.InvHdrObj.Declaration = jsonData.MSDS[lineno].__EMPTY;                         
         case (footerline):
              this.InvHdrObj.SupplierBankName = jsonData.MSDS[lineno].__EMPTY;                         
         case (footerline+1):
              this.InvHdrObj.SupplierBankAddress = jsonData.MSDS[lineno].__EMPTY;                         
         case (footerline+2):
              this.InvHdrObj.SupplierSwiftCode = jsonData.MSDS[lineno].__EMPTY;                         
         case (footerline+3):
              this.InvHdrObj.SupplierAccountNo = jsonData.MSDS[lineno].__EMPTY;  
         case (footerline+4):
              this.InvHdrObj.SupplierAccountName = jsonData.MSDS[lineno].__EMPTY;                         
         }
     }

     }

     }
     else { // only detail import

     }


     this.totalqty=0;
     this.totalamount=0;

     if (!this.ImportInvDetail.value) {
     if (this.ExcelFormat== "Shanghai Kaixin Pharmaceuticals Co., Ltd." || this.ExcelFormat== "Haoyuan Chemexpress Co., Limited") {
        for (lineno = detailline+1; lineno < footerline; lineno++) {
            qty = Number(jsonData.Invoice[lineno].__EMPTY_10);
            amount =Number(jsonData.Invoice[lineno].__EMPTY_12);   
            rate =Number(jsonData.Invoice[lineno].__EMPTY_11);   

            this.InvdetObj.push({InvoiceNo:this.InvHdrObj.InvoiceNo.substring(this.InvHdrObj.InvoiceNo.indexOf(":")+2),SrNo:jsonData.Invoice[lineno].__EMPTY_1,ProductId:jsonData.Invoice[lineno].__EMPTY_2,ProductDescription:jsonData.Invoice[lineno].__EMPTY_3,CASNo:jsonData.Invoice[lineno].__EMPTY_6,BatchNo:jsonData.Invoice[lineno].__EMPTY_7,MfgDate:jsonData.Invoice[lineno].__EMPTY_8,ExpDate:jsonData.Invoice[lineno].__EMPTY_9,Size:"",Qty:qty,UnitPrice:rate,Amount:amount});
            
            this.totalqty = Number(this.totalqty.toFixed(4)) +Number(qty.toFixed(4));
            this.totalamount = this.totalamount + amount;
        }
     }
     else {
        let srno=1;
        for (lineno = detailline+1; lineno < footerline-1; lineno++) {
            qty =Number(jsonData.MSDS[lineno].__EMPTY_13); 
            amount = Number(jsonData.MSDS[lineno].__EMPTY_14);
            rate = Number(jsonData.MSDS[lineno].__EMPTY_14)/Number(jsonData.MSDS[lineno].__EMPTY_13);
            this.InvdetObj.push({InvoiceNo:this.InvHdrObj.InvoiceNo,SrNo:srno,ProductId:jsonData.MSDS[lineno].__EMPTY,ProductDescription:jsonData.MSDS[lineno].__EMPTY_2,CASNo:"",BatchNo:"",MfgDate:"",ExpDate:"",Size:jsonData.MSDS[lineno].__EMPTY_10,Qty:jsonData.MSDS[lineno].__EMPTY_13,UnitPrice:rate,Amount:jsonData.MSDS[lineno].__EMPTY_14});

            srno = srno +1;
            this.totalqty = Number(this.totalqty.toFixed(4)) +Number(qty.toFixed(4));
            this.totalamount = this.totalamount + amount;            
        }

     }


     }
     else { // import detail only
  //      alert(detailline+1);
  //      alert(footerline);
  //       alert(this.InvHdrObj.InvoiceNo);
        for (lineno = detailline+1; lineno < footerline; lineno++) {
   //         alert(jsonData.Sheet1[lineno].__EMPTY_9.toFixed(4));
   //         alert(jsonData.Sheet1[lineno].__EMPTY_11.toFixed(2));
 //           alert(jsonData.Sheet1[lineno].__EMPTY_10.toFixed(5));
            qty = Number(jsonData.Sheet1[lineno].__EMPTY_9);
     //       alert(qty);
            amount =Number(jsonData.Sheet1[lineno].__EMPTY_11); 
   //            alert(amount);
            rate =Number(jsonData.Sheet1[lineno].__EMPTY_10);   
   //         alert(rate);
         

            this.InvdetObj.push({InvoiceNo:this.InvHdrObj.InvoiceNo,SrNo:jsonData.Sheet1[lineno].__EMPTY,ProductId:jsonData.Sheet1[lineno].__EMPTY_1,ProductDescription:jsonData.Sheet1[lineno].__EMPTY_2,CASNo:jsonData.Sheet1[lineno].__EMPTY_5,BatchNo:jsonData.Sheet1[lineno].__EMPTY_6,MfgDate:jsonData.Sheet1[lineno].__EMPTY_7,ExpDate:jsonData.Sheet1[lineno].__EMPTY_8,Size:"",Qty:qty,UnitPrice:rate,Amount:amount});
            
            this.totalqty = Number(this.totalqty.toFixed(4)) +Number(qty.toFixed(4));
            this.totalamount = this.totalamount + amount;
        }

     }
 // alert(JSON.stringify(this.InvdetObj)); 
  //   document.getElementById('detoutput').innerHTML =JSON.stringify(this.InvdetObj);
     this.IsWait = false;

     if (!this.ImportInvDetail.value) {
        if (this.ExcelFormat== "Shanghai Kaixin Pharmaceuticals Co., Ltd." || this.ExcelFormat== "Haoyuan Chemexpress Co., Limited") {
           this.invoiceno = this.InvHdrObj.InvoiceNo.substring(this.InvHdrObj.InvoiceNo.indexOf(":")+2);
           this.invoicedate = this.InvHdrObj.InvoiceDate.substring(this.InvHdrObj.InvoiceDate.indexOf(":")+2);
           this.orderno=this.InvHdrObj.PurchaseOrderNo.substring(this.InvHdrObj.PurchaseOrderNo.indexOf(":")+2);
           this.orderdate= this.InvHdrObj.PurchaseOrderDate;
           this.duedate ="";
           this.shipdate="";
        }
        else {
           this.invoiceno = this.InvHdrObj.InvoiceNo;
           this.invoicedate = new Date(this.InvHdrObj.InvoiceDate).toISOString().slice(0, 10); 
           this.orderno= this.InvHdrObj.PurchaseOrderNo;   
           this.orderdate= this.InvHdrObj.PurchaseOrderDate;
           this.duedate =new Date(this.InvHdrObj.DueDate).toISOString().slice(0, 10); 
           this.shipdate=new Date(this.InvHdrObj.ShipDate).toISOString().slice(0, 10);
        }
     }
     else { // import detail only
           this.invoiceno = this.InvHdrObj.InvoiceNo;
           this.invoicedate =this.datePipe.transform(this.InvHdrObj.InvoiceDate,"yyyy/MM/dd");
           this.orderno=this.InvHdrObj.PurchaseOrderNo;
           this.orderdate=this.datePipe.transform(this.InvHdrObj.PurchaseOrderDate,"yyyy/MM/dd");
           this.duedate ="";
           this.shipdate="";
           this.InvHdrObj.SupplierName= this.ExcelFormat;
     }     
//alert(JSON.stringify(this.InvdetObj));
    this.InvHdrObj.SupplierAddress = this.SupplierAddress + this.SupplierAddress2;
     
       const body = new HttpParams()
      .set(`Id`, this.InvHdrObj.Id.toString())
      .set(`InvoiceNo`, this.invoiceno)
      .set(`InvoiceDate`,this.invoicedate)
      .set(`SupplierName`, this.InvHdrObj.SupplierName)
      .set(`PurchaseOrderNo`, this.orderno)
      .set(`PurchaseOrderDate`, this.orderdate)
      .set(`PaymentTerm`, this.InvHdrObj.PaymentTerm)
      .set(`DueDate`,this.duedate)
      .set(`ShipDate`, this.shipdate)
      .set(`CourierName`, this.InvHdrObj.CourierName)
      .set(`TrackingNo`, this.InvHdrObj.TrackingNo)
      .set(`Remark`, this.InvHdrObj.Remark)
      .set(`InvoiceTerm`, this.InvHdrObj.InvoiceTerm)
      .set(`CountryOfOrigin`, this.InvHdrObj.CountryOfOrigin)
      .set(`Declaration`, this.InvHdrObj.Declaration)
      .set(`SupplierAddress`, this.InvHdrObj.SupplierAddress)
      .set(`SupplierTelNo`, this.InvHdrObj.SupplierTelNo)
      .set(`SupplierFaxNo`, this.InvHdrObj.SupplierFaxNo)
      .set(`SupplierEmailId`, this.InvHdrObj.SupplierEmailId)
      .set(`SupplierBankName`, this.InvHdrObj.SupplierBankName)
      .set(`SupplierBankCode`, this.InvHdrObj.SupplierBankCode)
      .set(`SupplierBankAddress`, this.InvHdrObj.SupplierBankAddress)
      .set(`SupplierSwiftCode`, this.InvHdrObj.SupplierSwiftCode)
      .set(`SupplierAccountName`, this.InvHdrObj.SupplierAccountName)
      .set(`SupplierAccountNo`, this.InvHdrObj.SupplierAccountNo)
      .set(`SupplierCertificateNo`, this.InvHdrObj.SupplierCertificateNo)
      .set(`SupplierBeneficiaryName`, this.InvHdrObj.SupplierBeneficiaryName)
      .set(`TotalQty`, this.totalqty.toString())
      .set(`TotalAmount`, this.totalamount.toString()); 

       const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded','token': this.apitoken });
                          
      this.http.post<any>(`${environment.apiUrl}/importpurchaseinvoice`,body.toString(),{headers: headers}).subscribe(data => {
        if (data.error) {
    //      alert(data.message);  
              this.notificationService.warn(data.message);                  
        }
        else {
            let detheader : any = new HttpHeaders({ 'Content-Type': 'application/json','token': this.apitoken })
             this.http.post<any>(`${environment.apiUrl}/importpurchaseinvoicedetail`,JSON.stringify(this.InvdetObj),{headers:detheader}).subscribe(data => {
              if (data.error) {
              //   alert(data.message);
                 this.notificationService.warn(data.message);                          
              }
              else {   
                   this.notificationService.success('Purchase Invoice Imported Successfully...');   
              }
              },
              err => {
               alert(JSON.stringify(err));
              });
        }
      },
      err => {
         alert(JSON.stringify(err));
      });


 /*      document.getElementById('output').innerHTML = dataString.slice(0, 300).concat("..."); 
      this.setDownload(dataString);*/    
    }

    reader.readAsBinaryString(file);

  }
 

  setDownload(data) {
    this.willDownload = true;
    setTimeout(() => {
      const el = document.querySelector("#download");
      el.setAttribute("href", `data:text/json;charset=utf-8,${encodeURIComponent(data)}`);
      el.setAttribute("download", 'xlsxtojson.json');
    }, 1000)
  }
}
