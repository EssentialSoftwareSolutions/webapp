import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {Component, Inject } from '@angular/core';
import {LeadService} from '../../../services/lead.service';
import {FormControl, Validators} from '@angular/forms';
import {Lead} from '../../../models/Lead';
import { NotificationService } from '../../../services/notification.service';
import { NgxSpinnerService } from "ngx-spinner"; 

@Component({
  selector: 'app-add.lead',
  templateUrl: '../../../lead/dialogs/add/add.lead.html',
  styleUrls: ['../../../lead/dialogs/add/add.lead.css'],
  providers: []
})



export class AddLeadComponent {
  constructor(public dialogRef: MatDialogRef<AddLeadComponent>,
              @Inject(MAT_DIALOG_DATA) public data: Lead,
              public leadService: LeadService,private SpinnerService: NgxSpinnerService,public notificationService: NotificationService) { 
              data.LeadCompanyName="";
              data.LeadContactPerson="";
              data.LeadContactNo="";
              data.LeadMobileNo="";
              data.LeadAddress="";
              data.LeadCity="";
              data.LeadState="";
              data.LeadCountry="";
              data.LeadCategory="";
              data.LeadSource="";
              data.LeadRefNo="";
   // this.SpinnerService.show();
}

  formControl = new FormControl('', [Validators.required]);


ngAfterViewInit() {
}


  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  submit() {
    // emppty stuff
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }
  
  adddata(): void {
   this.leadService.addData(this.data).then(data => {
    this.notificationService.success('Lead Added successfully...');    
    this.dialogRef.close(true);
   },
    (error : any) => {
     this.notificationService.warn('Error While adding Lead...'); 
   });
  }

}
