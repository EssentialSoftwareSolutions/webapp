import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {Component, Inject } from '@angular/core';
import {LeadService} from '../../../services/lead.service';
import { NotificationService } from '../../../services/notification.service';

@Component({
  selector: 'app-delete.lead',
  templateUrl: '../../../lead/dialogs/delete/delete.lead.html',
  styleUrls: ['../../../lead/dialogs/delete/delete.lead.css'],
  providers: []
})
export class DeleteLeadComponent {

  constructor(public dialogRef: MatDialogRef<DeleteLeadComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public leadService: LeadService,
    public notificationService: NotificationService) { 
   }



  onNoClick(): void {

  }

  confirmDelete(): void {
    this.leadService.DeleteLead(this.data.LeadId).then(
      (data) => {
        this.notificationService.success('Lead Deleted successfully...');
        this.dialogRef.close();
      },
      (error: any) => {}
    );
  }




}
