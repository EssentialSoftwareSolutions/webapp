import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {Component, Inject } from '@angular/core';
import {LeadService} from '../../../services/lead.service';
import {FormControl, Validators} from '@angular/forms';
import {Lead} from '../../../models/Lead';
import { NotificationService } from '../../../services/notification.service';
import { NgxSpinnerService } from "ngx-spinner"; 

@Component({
  selector: 'app-edit.lead',
  templateUrl: '../../../lead/dialogs/edit/edit.lead.html',
  styleUrls: ['../../../lead/dialogs/edit/edit.lead.css'],
  providers: []
})



export class EditLeadComponent {
  constructor(public dialogRef: MatDialogRef<EditLeadComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              public leadService: LeadService,private SpinnerService: NgxSpinnerService,public notificationService: NotificationService) { 

   // this.SpinnerService.show();
}

  formControl = new FormControl('', [Validators.required]);


ngAfterViewInit() {
}


  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  submit() {
    // emppty stuff
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }
  updatedata(): void {
   this.leadService.updateData(this.data).then(data => {
    this.notificationService.success('Lead Updated successfully...');    
    this.dialogRef.close(true);
   },
    (error : any) => {
     this.notificationService.warn('Error While updating Lead...'); 
   });
  }

}
