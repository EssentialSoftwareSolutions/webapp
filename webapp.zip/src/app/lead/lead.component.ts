import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {LeadService} from '../services/lead.service';
import {HttpClient} from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import {Lead} from '../models/Lead';
import {DataSource} from '@angular/cdk/collections';
import {AddLeadComponent} from './dialogs/add/add.lead.component';
import {EditLeadComponent} from './dialogs/edit/edit.lead.component';
import {DeleteLeadComponent} from './dialogs/delete/delete.lead.component';

import {BehaviorSubject, fromEvent, merge, Observable} from 'rxjs';
import {map} from 'rxjs/operators';


@Component({
  selector: 'app-lead',
  templateUrl: './lead.component.html',
  styleUrls: ['./lead.component.css']
})

export class LeadComponent implements OnInit {
displayedColumns=['LeadId','LeadCompanyName','LeadContactPerson','LeadMobileNo','LeadCountry','LeadCity','LeadCategory','LeadSource','LeadRefNo','actions'];

  exampleDatabase: LeadService | null;

  dataSource: ExampleDataSource | null;

  index: number;
  leadid: number;
  currentuser: any;
  currentusergroup: string;

  constructor(public httpClient: HttpClient,public dialog: MatDialog,
  public leadService: LeadService) {
          //       alert("lead construct");
              }

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild('filter',  {static: true}) filter: ElementRef;

  ngOnInit() {
 //  alert("ngOnInit");
    this.currentuser=JSON.parse(sessionStorage.getItem('currentUser'));
    this.currentusergroup=this.currentuser["data"].login_Group;  
    
    this.loadData();
  }

  refresh() {
    this.loadData();
  }

  addNew() {

    const dialogRef = this.dialog.open(AddLeadComponent, {
      data: {lead: Lead },    width: '60%',
    height: '80%'

    });

    dialogRef.afterClosed().subscribe(result => {
    if (result !== 1) {
        this.exampleDatabase.dataChange.value.push(this.leadService.getLeadData());
        this.refreshTable();
      }
    });
  }


  startEdit(i: number,LeadId: number,LeadCompanyName: string,LeadContactPerson: string,
  LeadContactNo: string,LeadMobileNo: string,LeadAddress: string,LeadCity: string,LeadState: string,LeadCountry: string,
  LeadCategory: string,LeadSource: string,LeadRefNo: string) {
    this.leadid = LeadId;
    // index row is used just for debugging proposes and can be removed

    this.index = i;
 //   console.log(this.index);
    const dialogRef = this.dialog.open(EditLeadComponent, {
      data: {LeadId: LeadId,LeadCompanyName: LeadCompanyName,LeadContactPerson: LeadContactPerson,
  LeadContactNo: LeadContactNo,LeadMobileNo: LeadMobileNo,LeadAddress: LeadAddress,LeadCity: LeadCity,LeadState: LeadState,LeadCountry: LeadCountry,
  LeadCategory: LeadCategory,LeadSource: LeadSource,LeadRefNo: LeadRefNo
      },
    width: '60%',
    height: '80%'
    });

    dialogRef.afterClosed().subscribe(result => {
    //  alert(result);
      if (result) {
        // When using an edit things are little different, firstly we find record inside DataService by id
        const foundIndex = this.exampleDatabase.dataChange.value.findIndex(x => x.LeadId === this.leadid);
        // Then you update that record using data from dialogData (values you enetered)
        this.exampleDatabase.dataChange.value[foundIndex] = this.leadService.getLeadData();
        // And lastly refresh table
        this.refreshTable();
      }
    });
  }

  deleteItem(i: number,LeadId: number,LeadCompanyName: string,LeadContactPerson: string,
  LeadContactNo: string,LeadMobileNo: string,LeadAddress: string,LeadCity: string,LeadState: string,LeadCountry: string,
  LeadCategory: string,LeadSource: string,LeadRefNo: string) {
    this.leadid = LeadId;
    // index row is used just for debugging proposes and can be removed

  this.index = i;
  console.log(this.index);
  const dialogRef = this.dialog.open(DeleteLeadComponent, {
  data: {LeadId: LeadId,LeadCompanyName: LeadCompanyName,LeadContactPerson: LeadContactPerson,
  LeadContactNo: LeadContactNo,LeadMobileNo: LeadMobileNo,LeadAddress: LeadAddress,LeadCity: LeadCity,LeadState: LeadState,LeadCountry: LeadCountry,
  LeadCategory: LeadCategory,LeadSource: LeadSource,LeadRefNo: LeadRefNo}
  });

    dialogRef.afterClosed().subscribe((result) => {
      if (result !== 1) {
        const foundIndex = this.exampleDatabase.dataChange.value.findIndex(
          (x) => x.LeadId === this.leadid
        );
        // for delete we use splice in order to remove single object from DataService
        this.exampleDatabase.dataChange.value.splice(foundIndex, 1);
        this.refreshTable();
      }
    });
  }



  private refreshTable() {
    // Refreshing table using paginator
    // Thanks yeager-j for tips
    // https://github.com/marinantonio/angular-mat-table-crud/issues/12
    this.paginator._changePageSize(this.paginator.pageSize);
  }


  public loadData() {
 //   alert("loadData");
    this.exampleDatabase = new LeadService(this.httpClient);
  //  alert("new lead Service");

    this.dataSource = new ExampleDataSource(this.exampleDatabase, this.paginator, this.sort);
  //  alert("after datasource new instance");
    fromEvent(this.filter.nativeElement, 'keyup')
      // .debounceTime(150)
      // .distinctUntilChanged()
      .subscribe(() => {
        if (!this.dataSource) {
          return;
        }
        this.dataSource.filter = this.filter.nativeElement.value;
      });
  }
}


export class ExampleDataSource extends DataSource<Lead> {
  _filterChange = new BehaviorSubject('');

  get filter(): string {
    return this._filterChange.value;
  }

  set filter(filter: string) {
    this._filterChange.next(filter);
  }

  filteredData: Lead[] = [];
  renderedData: Lead[] = [];
  constructor(public _exampleDatabase: LeadService,public _paginator: MatPaginator, public _sort: MatSort) {
    super();
 //     alert("ExampleDataSource construct");
    // Reset to the first page when the user changes the filter.
    this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
       //  alert("_filterChange");
  }
 
  /** Connect function called by the table to retrieve one stream containing the data to render. */

  connect(): Observable<Lead[]> {
    //    alert("connect");
    // Listen for any changes in the base data, sorting, filtering, or pagination
    const displayDataChanges = [
      this._exampleDatabase.dataChange,
      this._sort.sortChange,
      this._filterChange,
      this._paginator.page
    ];
 //   alert("getAll lead before");

    this._exampleDatabase.getAllLeads();

//    alert("after getAll lead");
    return merge(...displayDataChanges).pipe(map( () => {
        // Filter data
    //  alert("filter data");
    //   alert(JSON.stringify(this._exampleDatabase.data));
        this.filteredData = this._exampleDatabase.data.slice().filter((lead: Lead) => {
          const searchStr = (lead.LeadCompanyName+lead.LeadContactPerson+lead.LeadContactNo+lead.LeadMobileNo).toLowerCase();
          return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
        });

        // Sort filtered data
        const sortedData = this.sortData(this.filteredData.slice());

        // Grab the page's slice of the filtered sorted data.
        const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
        this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
        return this.renderedData;
      }
    ));
  }

  disconnect() {}



  /** Returns a sorted copy of the database data. */
 sortData(data: Lead[]): Lead[] {
    if (!this._sort.active || this._sort.direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      let propertyA: number | string = '';
      let propertyB: number | string = '';
      
      switch (this._sort.active) {
        case 'LeadId': [propertyA, propertyB] = [a.LeadId, b.LeadId]; break;
        case 'LeadCompanyName': [propertyA, propertyB] = [a.LeadCompanyName, b.LeadCompanyName]; break;
        case 'LeadContactPerson': [propertyA, propertyB] = [a.LeadContactPerson, b.LeadContactPerson]; break;
        case 'LeadContactNo': [propertyA, propertyB] = [a.LeadContactNo, b.LeadContactNo]; break;
        case 'LeadMobileNo': [propertyA, propertyB] = [a.LeadMobileNo, b.LeadMobileNo]; break;  
      }

      const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
      const valueB = isNaN(+propertyB) ? propertyB : +propertyB;

      return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'asc' ? 1 : -1);
    });
  }
}