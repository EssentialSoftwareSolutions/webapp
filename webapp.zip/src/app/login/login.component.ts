﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { environment } from '@environments/environment';
import { AuthenticationService } from '@app/_services';
import {LoginInfoService} from '../services/logininfo.service';
import AES from 'crypto-js/aes';
import Utf8 from 'crypto-js/enc-utf8';

@Component({ templateUrl: 'login.component.html' })
export class LoginComponent implements OnInit {
    loginForm: FormGroup;
    loading = false;
    submitted = false;
    returnUrl: string;
    error = '';
    isDisplayed=true;
    newpwd: string;
    confirmpwd: string;
    apikey: string;
    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService,
        private logininfoService:LoginInfoService
    ) { 
        // redirect to home if already logged in
        if (this.authenticationService.currentUserValue) { 
            this.router.navigate(['/']);
        }
    }

    ngOnInit() {
        this.loginForm = this.formBuilder.group({
            useremailid: ['', Validators.required],
            password: ['', Validators.required]
        });

        // get return url from route parameters or default to '/'
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    }

    // convenience getter for easy access to form fields
    get f() { return this.loginForm.controls; }


    onSubmit() {
        this.submitted = true;

        // stop here if form is invalid
        if (this.loginForm.invalid) {
            return;
        }

        this.loading = true;
        this.authenticationService.login(this.f.useremailid.value, this.f.password.value)
            .pipe(first())
            .subscribe(
                data => {
                    if (data == null) {
                    this.error = "User Email Id/Password wrongly entered...";
                    this.loading = false;
                  //  alert(this.error);
                    }
                    else {
                    this.router.navigate([this.returnUrl]);                    
                    }
                },
                error => {
                    this.error = "User Email Id/Password wrongly entered...";
                    this.loading = false;
                //    alert(this.error);
                });
    }

changepwd() {
//alert(this.f.useremailid.value);
//alert(this.f.password.value);

this.authenticationService.login(this.f.useremailid.value, this.f.password.value,false)
    .pipe(first())
    .subscribe(
        data => {
        if (data == null) {
            this.isDisplayed=true;
            this.error = "User Email Id/Password wrongly entered..."; 

        }
        else {
               this.apikey=AES.decrypt(data.token, environment.encryptionkey).toString(Utf8);

               this.isDisplayed=false;
               this.error ="";                   
        }
    },
    error => {
        this.error = "User Email Id/Password wrongly entered...";
        this.loading = false;
    });
 
}

updatepwd() {
//alert(this.apikey);
if (this.newpwd == this.confirmpwd) {
   this.logininfoService.updatepassword(this.f.useremailid.value,this.newpwd,this.apikey).then(data => {
    alert('updated password successfully...');    

    this.isDisplayed=true;
    this.newpwd="";
    this.confirmpwd="";

   },
    (error : any) => {
     alert('Error While updating Passowrd...'); 
   });

}
else
   alert("New Password not matching with confirm password...");
}

cancel() {
   this.isDisplayed=true;  
   this.newpwd="";
   this.confirmpwd="";      
}

}
