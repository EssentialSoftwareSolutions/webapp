import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {Component, Inject } from '@angular/core';
import {MessageTemplateService} from '../../../services/messagetemplate.service';
import {FormControl, Validators} from '@angular/forms';
import {Template} from '../../../models/Template';
import { NotificationService } from '../../../services/notification.service';
import { NgxSpinnerService } from "ngx-spinner"; 
import * as _ from 'lodash';

@Component({
  selector: 'app-add.messagetemplate',
  templateUrl: '../../../message-template/dialogs/add/add.message-template.html',
  styleUrls: ['../../../message-template/dialogs/add/add.message-template.css'],
  providers: []
})



export class AddMessageTemplateComponent {
SendAttachment = new FormControl();  
imageError: string;
isImageSaved: boolean = false;
attachfileBase64: string;
AttachFileName = new FormControl();  

  constructor(public dialogRef: MatDialogRef<AddMessageTemplateComponent>,
              @Inject(MAT_DIALOG_DATA) public data: Template,
              public messagetemplateService: MessageTemplateService,private SpinnerService: NgxSpinnerService,public notificationService: NotificationService) { 

              data.TemplateName="";
              data.TemplatePara1="";
              data.TemplatePara2="";
              data.TemplatePara3="";
              data.TemplatePara4="";
              data.TemplatePara5="";
              data.SendAttachment=false;
              data.AttachmentType="";
              data.AttachFileExt="";
              data.AttachmentCaption="";

   // this.SpinnerService.show();
}

  formControl = new FormControl('', [Validators.required]);


ngAfterViewInit() {
}


  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  submit() {
    // emppty stuff
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }
  
  adddata(): void {
     this.data.SendAttachment = this.SendAttachment.value;

   this.messagetemplateService.addData(this.data,this.attachfileBase64).then(data => {
    this.notificationService.success('Template Added successfully...');    
    this.dialogRef.close(true);
   },
    (error : any) => {
     this.notificationService.warn('Error While adding Lead...'); 
   });
  }


fileChangeEvent(fileInput: any) {
    this.imageError = null;
    if (fileInput.target.files && fileInput.target.files[0]) {
      //  alert("target files found...");
        // Size Filter Bytes
        const max_size = 10485760;
        const allowed_types = ['image/jpeg','image/png','video/mp4','audio/mp3','application/xlsx','application/xls','application/pdf'];

        if (fileInput.target.files[0].size > max_size) {
            this.imageError =
                'Maximum size allowed is ' + max_size / 1000000 + 'Mb';

            return false;
        }
//alert(fileInput.target.files[0].type);
        if (!_.includes(allowed_types, fileInput.target.files[0].type)) {
            this.imageError = 'Only mentioned file types are allowed ( image/*,video/*,audio/*,.xlsx,.xls,.pdf )';
            return false;
        }
        const reader = new FileReader();
        reader.onload = (e: any) => {
                    const imgBase64Path = e.target.result;
                    this.attachfileBase64 = imgBase64Path;
                //    alert(this.cardImageBase64);
                    this.isImageSaved = true;
        };
//        alert(this.AttachFileName.value); 
        reader.readAsDataURL(fileInput.target.files[0]);
    }
} 

removeImage() {
        this.AttachFileName.setValue("");
        this.attachfileBase64 = null;
        this.isImageSaved = false;
    }

}
