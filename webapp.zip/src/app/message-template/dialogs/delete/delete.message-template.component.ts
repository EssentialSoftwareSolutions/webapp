import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {Component, Inject } from '@angular/core';
import {MessageTemplateService} from '../../../services/messagetemplate.service';
import { NotificationService } from '../../../services/notification.service';

@Component({
  selector: 'app-delete.message-template',
  templateUrl: '../../../message-template/dialogs/delete/delete.message-template.html',
  styleUrls: ['../../../message-template/dialogs/delete/delete.message-template.css'],
  providers: []
})
export class DeleteMessageTemplateComponent {

  constructor(public dialogRef: MatDialogRef<DeleteMessageTemplateComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public messagetemplateService: MessageTemplateService,
    public notificationService: NotificationService) { 
   }



  onNoClick(): void {

  }

  confirmDelete(): void {
    this.messagetemplateService.DeleteTemplate(this.data.TemplateId).then(
      (data) => {
        this.notificationService.success('Template Deleted successfully...');
        this.dialogRef.close();
      },
      (error: any) => {}
    );
  }




}
