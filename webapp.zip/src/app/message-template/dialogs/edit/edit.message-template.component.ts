import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {Component, Inject } from '@angular/core';
import {MessageTemplateService} from '../../../services/messagetemplate.service';
import {FormControl, Validators} from '@angular/forms';
import {Template} from '../../../models/Template';
import { NotificationService } from '../../../services/notification.service';
import { NgxSpinnerService } from "ngx-spinner"; 
import * as _ from 'lodash';

@Component({
  selector: 'app-edit.messagetemplate',
  templateUrl: '../../../message-template/dialogs/edit/edit.message-template.html',
  styleUrls: ['../../../message-template/dialogs/edit/edit.message-template.css'],
  providers: []
})



export class EditMessageTemplateComponent {
SendAttachment = new FormControl();  
imageError: string;
isImageSaved: boolean = false;
attachfileBase64: string;
InputFile = new FormControl();  

  constructor(public dialogRef: MatDialogRef<EditMessageTemplateComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              public messagetemplateService: MessageTemplateService,private SpinnerService: NgxSpinnerService,public notificationService: NotificationService) { 

   // this.SpinnerService.show();
  // alert(this.data["TemplateId"]);
   this.messagetemplateService.GetAttachment(this.data["TemplateId"])
   .then(attachdata => {
//        alert(this.data["TemplateId"] + '.'+attachdata["attachmentcontent"].split(';')[0].split('/')[1]);
        if (attachdata["attachmentcontent"] != "") {
  //      alert(this.isImageSaved);
   //     alert(this.AttachFileName.value);
       //alert(this.attachfileBase64);

            this.data.AttachFileName= this.data["TemplateId"] + '.'+attachdata["attachmentcontent"].split(';')[0].split('/')[1];
     //      this.AttachFileName.setValue(this.data["TemplateId"] + '.'+attachdata["attachmentcontent"].split(';')[0].split('/')[1]);
           this.isImageSaved = true;

           this.attachfileBase64 = attachdata["attachmentcontent"];
//           alert(this.attachfileBase64);
//           alert(this.isImageSaved);
//           alert(this.AttachFileName.value);
        }
        else {
           this.InputFile.setValue("");
           this.isImageSaved = false;        
        }


   },
    (error : any) => {

   });

}

  formControl = new FormControl('', [Validators.required]);


ngAfterViewInit() {
}


  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  submit() {
    // emppty stuff
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }
  updatedata(): void {
   this.data.SendAttachment = this.SendAttachment.value;

   this.messagetemplateService.updateData(this.data,this.attachfileBase64).then(data => {
    this.notificationService.success('template Updated successfully...');    
    this.dialogRef.close(true);
   },
    (error : any) => {
     this.notificationService.warn('Error While updating template...'); 
   });
  }

fileChangeEvent(fileInput: any) {
    this.imageError = null;
    if (fileInput.target.files && fileInput.target.files[0]) {
      //  alert("target files found...");
        // Size Filter Bytes
        const max_size = 10485760;
        const allowed_types = ['image/jpeg','image/png','video/mp4','audio/mp3','application/xlsx','application/xls','application/pdf'];

        if (fileInput.target.files[0].size > max_size) {
            this.imageError =
                'Maximum size allowed is ' + max_size / 1000000 + 'Mb';

            return false;
        }
//alert(fileInput.target.files[0].type);
        if (!_.includes(allowed_types, fileInput.target.files[0].type)) {
            this.imageError = 'Only mentioned file types are allowed ( image/*,video/*,audio/*,.xlsx,.xls,.pdf )';
            return false;
        }

        const reader = new FileReader();
        reader.onload = (e: any) => {
                    
                    const imgBase64Path = e.target.result;
                    this.attachfileBase64 = imgBase64Path;
                //    alert(this.cardImageBase64);
                    this.isImageSaved = true;
        };
        this.data.AttachFileName= fileInput.target.files[0].name; //this.InputFile.value;
        reader.readAsDataURL(fileInput.target.files[0]);
    }
} 

removeImage() {
        this.InputFile.setValue("");
        this.data.AttachFileName="";
        this.attachfileBase64 = null;
        this.isImageSaved = false;
    }


}
