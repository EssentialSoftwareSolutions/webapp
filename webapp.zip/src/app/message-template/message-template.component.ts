import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {MessageTemplateService} from '../services/messagetemplate.service';
import {HttpClient} from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import {Template} from '../models/Template';
import {DataSource} from '@angular/cdk/collections';
import {AddMessageTemplateComponent} from './dialogs/add/add.message-template.component';
import {EditMessageTemplateComponent} from './dialogs/edit/edit.message-template.component';
import {DeleteMessageTemplateComponent} from './dialogs/delete/delete.message-template.component';

import {BehaviorSubject, fromEvent, merge, Observable} from 'rxjs';
import {map} from 'rxjs/operators';


@Component({
  selector: 'app-messagetemplate',
  templateUrl: './message-template.component.html',
  styleUrls: ['./message-template.component.css']
})

/*TemplateId,TemplateName,TemplatePara1,TemplatePara2,TemplatePara3,TemplatePara4,TemplatePara5,SendAttachment,AttachmentType,AttachFileName,AttachmentCaption*/

export class MessageTemplateComponent implements OnInit {
displayedColumns=['TemplateId','TemplateName'/*,'TemplatePara1','TemplatePara2',
'TemplatePara3','TemplatePara4','TemplatePara5'*/,'AttachmentType',
'AttachFileExt','AttachmentCaption','actions'];

  exampleDatabase: MessageTemplateService | null;

  dataSource: ExampleDataSource | null;

  index: number;
  templateid: number;
  currentuser: any;
  currentusergroup: string;

  constructor(public httpClient: HttpClient,public dialog: MatDialog,
  public messagetemplateService: MessageTemplateService) {
           //      alert("temp construct");
              }

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild('filter',  {static: true}) filter: ElementRef;

  ngOnInit() {
  // alert("ngOnInit");
    this.currentuser=JSON.parse(sessionStorage.getItem('currentUser'));
    this.currentusergroup=this.currentuser["data"].login_Group;  
    
    this.loadData();
  }

  refresh() {
    this.loadData();
  }

  addNew() {

    const dialogRef = this.dialog.open(AddMessageTemplateComponent, {
      data: {messagetemplate: Template },    width: '60%',
    height: '80%'

    });

    dialogRef.afterClosed().subscribe(result => {
    if (result !== 1) {
        this.exampleDatabase.dataChange.value.push(this.messagetemplateService.getMessageTemplateData());
        this.refreshTable();
      }
    });
  }


  startEdit(i: number,TemplateId: number,TemplateName: string,TemplatePara1: string,TemplatePara2: string,TemplatePara3: string,TemplatePara4: string,TemplatePara5: string,SendAttachment: boolean,AttachmentType: string,AttachFileExt: string,AttachmentCaption: string) {
    this.templateid = TemplateId;
    // index row is used just for debugging proposes and can be removed

    this.index = i;
 //   console.log(this.index);
    const dialogRef = this.dialog.open(EditMessageTemplateComponent, {
      data: {TemplateId: TemplateId,TemplateName: TemplateName,TemplatePara1: TemplatePara1,TemplatePara2: TemplatePara2,TemplatePara3: TemplatePara3,TemplatePara4: TemplatePara4,TemplatePara5: TemplatePara5,SendAttachment: SendAttachment,AttachmentType: AttachmentType,AttachFileExt: AttachFileExt,AttachmentCaption:AttachmentCaption
      },
    width: '60%',
    height: '80%'
    });

    dialogRef.afterClosed().subscribe(result => {
    //  alert(result);
      if (result) {
        // When using an edit things are little different, firstly we find record inside DataService by id
        const foundIndex = this.exampleDatabase.dataChange.value.findIndex(x => x.TemplateId === this.templateid);
        // Then you update that record using data from dialogData (values you enetered)
        this.exampleDatabase.dataChange.value[foundIndex] = this.messagetemplateService.getMessageTemplateData();
        // And lastly refresh table
        this.refreshTable();
      }
    });
  }

  deleteItem(i: number,TemplateId: number,TemplateName: string,TemplatePara1: string,TemplatePara2: string,TemplatePara3: string,TemplatePara4: string,TemplatePara5: string,SendAttachment: boolean,AttachmentType: string,AttachFileExt: string,AttachmentCaption: string) {
    this.templateid = TemplateId;
    // index row is used just for debugging proposes and can be removed

  this.index = i;
  console.log(this.index);
  const dialogRef = this.dialog.open(DeleteMessageTemplateComponent, {
  data: {TemplateId: TemplateId,TemplateName: TemplateName,TemplatePara1: TemplatePara1,TemplatePara2: TemplatePara2,TemplatePara3: TemplatePara3,TemplatePara4: TemplatePara4,TemplatePara5: TemplatePara5,SendAttachment: SendAttachment,AttachmentType: AttachmentType,AttachFileExt: AttachFileExt,AttachmentCaption:AttachmentCaption}
  });

    dialogRef.afterClosed().subscribe((result) => {
      if (result !== 1) {
        const foundIndex = this.exampleDatabase.dataChange.value.findIndex(
          (x) => x.TemplateId === this.templateid
        );
        // for delete we use splice in order to remove single object from DataService
        this.exampleDatabase.dataChange.value.splice(foundIndex, 1);
        this.refreshTable();
      }
    });
  }



  private refreshTable() {
    // Refreshing table using paginator
    // Thanks yeager-j for tips
    // https://github.com/marinantonio/angular-mat-table-crud/issues/12
    this.paginator._changePageSize(this.paginator.pageSize);
  }


  public loadData() {
  //  alert("loadData");
    this.exampleDatabase = new MessageTemplateService(this.httpClient);
  //  alert("new lead Service");

    this.dataSource = new ExampleDataSource(this.exampleDatabase, this.paginator, this.sort);
  //  alert("after datasource new instance");
    fromEvent(this.filter.nativeElement, 'keyup')
      // .debounceTime(150)
      // .distinctUntilChanged()
      .subscribe(() => {
        if (!this.dataSource) {
          return;
        }
        this.dataSource.filter = this.filter.nativeElement.value;
      });
  }
}

export class ExampleDataSource extends DataSource<Template> {
  _filterChange = new BehaviorSubject('');

  get filter(): string {
    return this._filterChange.value;
  }

  set filter(filter: string) {
    this._filterChange.next(filter);
  }

  filteredData: Template[] = [];
  renderedData: Template[] = [];
  constructor(public _exampleDatabase: MessageTemplateService,public _paginator: MatPaginator, public _sort: MatSort) {
    super();
  //    alert("ExampleDataSource construct");
    // Reset to the first page when the user changes the filter.
    this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
       //  alert("_filterChange");
  }
 
  /** Connect function called by the table to retrieve one stream containing the data to render. */

  connect(): Observable<Template[]> {
    //    alert("connect");
    // Listen for any changes in the base data, sorting, filtering, or pagination
    const displayDataChanges = [
      this._exampleDatabase.dataChange,
      this._sort.sortChange,
      this._filterChange,
      this._paginator.page
    ];
 //   alert("getAll template before");

    this._exampleDatabase.getAllMessageTemplates();

 //   alert("after getAll template");
    return merge(...displayDataChanges).pipe(map( () => {
        // Filter data
    //  alert("filter data");
    //   alert(JSON.stringify(this._exampleDatabase.data));
        this.filteredData = this._exampleDatabase.data.slice().filter((messagetemplate: Template) => {
          const searchStr = (messagetemplate.TemplateName+messagetemplate.AttachFileExt+messagetemplate.AttachmentCaption).toLowerCase();
          return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
        });

        // Sort filtered data
        const sortedData = this.sortData(this.filteredData.slice());

        // Grab the page's slice of the filtered sorted data.
        const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
        this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
        return this.renderedData;
      }
    ));
  }

  disconnect() {}



  /** Returns a sorted copy of the database data. */
 sortData(data: Template[]): Template[] {
    if (!this._sort.active || this._sort.direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      let propertyA: number | string = '';
      let propertyB: number | string = '';
      
      switch (this._sort.active) {
        case 'TemplateId': [propertyA, propertyB] = [a.TemplateId, b.TemplateId]; break;
        case 'TemplateName': [propertyA, propertyB] = [a.TemplateName, b.TemplateName]; break;
        case 'AttachmentType': [propertyA, propertyB] = [a.AttachmentType, b.AttachmentType]; break;
        case 'AttachFileExt': [propertyA, propertyB] = [a.AttachFileExt, b.AttachFileExt]; break;
        case 'AttachmentCaption': [propertyA, propertyB] = [a.AttachmentCaption, b.AttachmentCaption]; break;  
      }

      const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
      const valueB = isNaN(+propertyB) ? propertyB : +propertyB;

      return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'asc' ? 1 : -1);
    });
  }
}