export interface InvDetail {
 InvoiceNo: string,
 SrNo: number,
 ProductId: string,
 ProductDescription: string,
 CASNo: string,
 BatchNo: string,
 MfgDate: string,
 ExpDate: string,
 Qty: number,
 UnitPrice: number,
 Amount: number
}