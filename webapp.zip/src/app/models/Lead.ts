export class  Lead {
    constructor(
    public LeadId: number,
    public LeadCompanyName: string,
    public LeadContactPerson: string,
    public LeadContactNo: string,
    public LeadMobileNo: string,
    public LeadAddress: string,
    public LeadCity: string,
    public LeadState: string,
    public LeadCountry: string,
    public LeadCategory: string,
    public LeadSource: string,
    public LeadRefNo: string
    ) {} 
}