export class Template {
    constructor(
    public TemplateId: number,
    public TemplateName: string,
    public TemplatePara1: string,
    public TemplatePara2: string,
    public TemplatePara3: string,
    public TemplatePara4: string,
    public TemplatePara5: string,
    public SendAttachment: boolean,
    public AttachmentType: string,
    public AttachFileExt: string,
    public AttachmentCaption: string
    ) {} 
}