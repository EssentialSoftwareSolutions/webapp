import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../_services';
import { MatSidenav } from '@angular/material/Sidenav';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit {
  public isExpanded: boolean =true;
currentuser: any;
currentusername: string;

  constructor(private router: Router,private authenticationService: AuthenticationService) { }


  ngOnInit(): void {
   if (this.authenticationService.currentUserValue) { 
      
  }


 if (sessionStorage.getItem("currentUser") !== null) {
   this.currentuser=JSON.parse(sessionStorage.getItem('currentUser'));
   this.currentusername=this.currentuser["data"].Login_Name;
}
else {
 //    this.router.navigate(['/']);
  this.router.navigate(['/login']);
}
  }


    logout() {
        this.authenticationService.logout();
        this.router.navigate(['/login']);
    }
}

