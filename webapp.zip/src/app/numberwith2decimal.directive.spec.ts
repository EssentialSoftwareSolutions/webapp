import { Numberwith2decimalDirective } from './numberwith2decimal.directive';

describe('Numberwith2decimalDirective', () => {
  it('should create an instance', () => {
    const directive = new Numberwith2decimalDirective();
    expect(directive).toBeTruthy();
  });
});
