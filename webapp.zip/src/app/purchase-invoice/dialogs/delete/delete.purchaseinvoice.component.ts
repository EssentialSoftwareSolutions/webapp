import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {Component, Inject } from '@angular/core';
import {PurchaseInvoiceService} from '../../../services/purchaseinvoice.service';
import { NotificationService } from '../../../services/notification.service';

@Component({
  selector: 'app-delete.purchaseinvoice',
  templateUrl: '../../../purchase-invoice/dialogs/delete/delete.purchaseinvoice.html',
  styleUrls: ['../../../purchase-invoice/dialogs/delete/delete.purchaseinvoice.css'],
  providers: []
})
export class DeletePurchaseInvoiceComponent {

  constructor(public dialogRef: MatDialogRef<DeletePurchaseInvoiceComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public purchaseinvoiceService: PurchaseInvoiceService,
    public notificationService: NotificationService) { 
   }



  onNoClick(): void {

  }

  confirmDelete(): void {
    this.purchaseinvoiceService.DeleteInvoice(this.data.InvoiceNo).then(
      (data) => {
        this.notificationService.success('Invoice Deleted successfully...');
        this.dialogRef.close();
      },
      (error: any) => {}
    );
  }




}
