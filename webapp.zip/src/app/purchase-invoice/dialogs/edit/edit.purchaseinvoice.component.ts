import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {Component, Inject } from '@angular/core';
import {PurchaseInvoiceService} from '../../../services/purchaseinvoice.service';
import {FormControl, Validators} from '@angular/forms';
import {InvHeader} from '../../../models/InvHeader';
import { NotificationService } from '../../../services/notification.service';
import { NgxSpinnerService } from "ngx-spinner"; 

@Component({
  selector: 'app-edit.purchaseinvoice',
  templateUrl: '../../../purchase-invoice/dialogs/edit/edit.purchaseinvoice.html',
  styleUrls: ['../../../purchase-invoice/dialogs/edit/edit.purchaseinvoice.css'],
  providers: []
})
export class EditPurchaseInvoiceComponent {
  displayedColumns = ['SrNo', 'ProductId','CASNo','ProductDescription','Size','Qty','UnitPrice','Amount'];
purchaseinvoicedetail: any;

totalqty: number;
totalamt: number;
  constructor(public dialogRef: MatDialogRef<EditPurchaseInvoiceComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              public purchaseinvoiceService: PurchaseInvoiceService,private SpinnerService: NgxSpinnerService,public notificationService: NotificationService) { 

    this.totalqty =0;
    this.totalamt =0;
    this.SpinnerService.show();

    this.purchaseinvoiceService.getpurchaseinvoicedetail(this.data.InvoiceNo).then(data => {
      this.purchaseinvoicedetail = data;
      this.purchaseinvoicedetail.forEach((x) => {
         this.totalqty += Number(x.Qty);
         this.totalamt += Number(x.Amount);         
         }) 

         this.totalqty = Number(this.totalqty.toFixed(4));      
         this.totalamt = Number(this.totalamt.toFixed(2));   

         this.SpinnerService.hide();    
         },
         (error : any) => {
          this.SpinnerService.hide();  
         });

   }

  formControl = new FormControl('', [Validators.required]);


ngAfterViewInit() {
}


  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  submit() {
    // emppty stuff
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }
  updatedata(): void {
  // alert(JSON.stringify(this.data));
  // return
   if (this.data.DutyAmount == "") {
      this.data.DutyAmount="0";
   }
   if (this.data.PenaltyAmount == "") {
      this.data.PenaltyAmount="0";
   }
   if (this.data.ClearanceCharges == "") {
      this.data.ClearanceCharges="0";
   }
   if (this.data.DoCharges == "") {
      this.data.DoCharges="0";
   }
   if (this.data.ShippingCharges == "") {
      this.data.ShippingCharges="0";
   }      
   this.purchaseinvoiceService.updateData(this.data).then(data => {
    this.notificationService.success('Purchase Invoice Updated successfully...');    
    this.dialogRef.close(true);
   },
    (error : any) => {
     this.notificationService.warn('Error While updating Purchase Invoice...'); 
   });
  }

}
