import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {PurchaseInvoiceService} from '../services/purchaseinvoice.service';
import {HttpClient} from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import {InvHeader} from '../models/InvHeader';
import {DataSource} from '@angular/cdk/collections';
import {EditPurchaseInvoiceComponent} from './dialogs/edit/edit.purchaseinvoice.component';
import {DeletePurchaseInvoiceComponent} from './dialogs/delete/delete.purchaseinvoice.component';

import {BehaviorSubject, fromEvent, merge, Observable} from 'rxjs';
import {map} from 'rxjs/operators';


@Component({
  selector: 'app-purchase-invoice',
  templateUrl: './purchase-invoice.component.html',
  styleUrls: ['./purchase-invoice.component.css']
})
export class PurchaseInvoiceComponent implements OnInit {
  displayedColumns=['Id','InvoiceNo','InvoiceDate','SupplierName','PurchaseOrderNo',
  'PurchaseOrderDate','CourierName','TrackingNo','DueDate'/*,'ShipDate',
  'SupplierAddress','SupplierTelNo','SupplierEmailId'*/,'TotalQty','TotalAmount',
  'DutyAmount','actions'];

  exampleDatabase: PurchaseInvoiceService | null;

  dataSource: ExampleDataSource | null;
  pagesize: number;
  index: number;
  invoiceno: string;
  currentuser: any;
  currentusergroup: string;

  constructor(public httpClient: HttpClient,public dialog: MatDialog,
  public purchaseinvoiceService: PurchaseInvoiceService) {
          //       alert("PurchaseInvoice construct");
              }

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild('filter',  {static: true}) filter: ElementRef;

  ngOnInit() {
  // alert("ngOnInit");
    this.currentuser=JSON.parse(sessionStorage.getItem('currentUser'));
    this.currentusergroup=this.currentuser["data"].login_Group;  
    this.pagesize=5;
    this.loadData();
  }

valuechange(newValue) {
  //mymodel = newValue;
  //alert(newValue);
//this.dataSource.paginator._changePageSize(newValue);
//this.loadData();
   this.paginator._changePageSize(newValue);
   
}  

  refresh() {
    this.loadData();
  }

  startEdit(i: number,Id: number,InvoiceNo: string,InvoiceDate: string,
  SupplierName: string,PurchaseOrderNo: string,PurchaseOrderDate: string,CourierName: string,TrackingNo: string,DueDate: string,
  ShipDate: string,SupplierAddress: string,SupplierTelNo: string,
  SupplierEmailId: string,TotalQty: number,TotalAmount: number,
  DutyAmount: number,PenaltyAmount: number,BillOfEntryNumber: string,
  ClearanceInvoiceNumber: string,ClearanceCharges: number,
  DoInvoice: string,DoCharges: number,ShippingCharges: number) {
    this.invoiceno = InvoiceNo;
    // index row is used just for debugging proposes and can be removed

    this.index = i;
    console.log(this.index);
    const dialogRef = this.dialog.open(EditPurchaseInvoiceComponent, {
      data: {Id: Id,InvoiceNo: InvoiceNo,InvoiceDate: InvoiceDate,SupplierName: SupplierName,PurchaseOrderNo: PurchaseOrderNo,PurchaseOrderDate: PurchaseOrderDate,CourierName: CourierName,TrackingNo: TrackingNo,DueDate: DueDate,ShipDate: ShipDate, SupplierAddress: SupplierAddress,SupplierTelNo: SupplierTelNo,SupplierEmailId: SupplierEmailId,TotalQty: TotalQty,TotalAmount: TotalAmount,
      DutyAmount: DutyAmount,PenaltyAmount: PenaltyAmount,BillOfEntryNumber: BillOfEntryNumber,ClearanceInvoiceNumber: ClearanceInvoiceNumber,ClearanceCharges: ClearanceCharges,
      DoInvoice: DoInvoice,DoCharges: DoCharges,ShippingCharges: ShippingCharges
      },
    width: '60%',
    height: '80%'
    });

    dialogRef.afterClosed().subscribe(result => {
    //  alert(result);
      if (result) {
        // When using an edit things are little different, firstly we find record inside DataService by id
        const foundIndex = this.exampleDatabase.dataChange.value.findIndex(x => x.InvoiceNo === this.invoiceno);
        // Then you update that record using data from dialogData (values you enetered)
        this.exampleDatabase.dataChange.value[foundIndex] = this.purchaseinvoiceService.getPurchaseInvoiceData();
        // And lastly refresh table
        this.refreshTable();
      }
    });
  }

  deleteItem(i: number,Id: number,InvoiceNo: string,InvoiceDate: string,
  SupplierName: string,PurchaseOrderNo: string,PurchaseOrderDate: string,CourierName: string,TrackingNo: string,DueDate: string,
  ShipDate: string,SupplierAddress: string,SupplierTelNo: string,
  SupplierEmailId: string,TotalQty: number,TotalAmount: number,
  DutyAmount: number,PenaltyAmount: number,BillOfEntryNumber: string,
  ClearanceInvoiceNumber: string,ClearanceCharges: number,DoInvoice: string,DoCharges: number,ShippingCharges: number) {
    this.invoiceno = InvoiceNo;
    // index row is used just for debugging proposes and can be removed

  this.index = i;
  console.log(this.index);
  const dialogRef = this.dialog.open(DeletePurchaseInvoiceComponent, {
  data: {Id: Id,InvoiceNo: InvoiceNo,InvoiceDate: InvoiceDate,SupplierName: SupplierName,PurchaseOrderNo: PurchaseOrderNo,PurchaseOrderDate: PurchaseOrderDate,CourierName: CourierName,TrackingNo: TrackingNo,DueDate: DueDate,ShipDate: ShipDate, SupplierAddress: SupplierAddress,SupplierTelNo: SupplierTelNo,SupplierEmailId: SupplierEmailId,TotalQty: TotalQty,TotalAmount: TotalAmount,
  DutyAmount: DutyAmount,PenaltyAmount: PenaltyAmount,BillOfEntryNumber: BillOfEntryNumber,ClearanceInvoiceNumber: ClearanceInvoiceNumber,ClearanceCharges: ClearanceCharges,
  DoInvoice: DoInvoice,DoCharges: DoCharges,ShippingCharges: ShippingCharges}
  });

    dialogRef.afterClosed().subscribe((result) => {
      if (result !== 1) {
        const foundIndex = this.exampleDatabase.dataChange.value.findIndex(
          (x) => x.InvoiceNo === this.invoiceno
        );
        // for delete we use splice in order to remove single object from DataService
        this.exampleDatabase.dataChange.value.splice(foundIndex, 1);
        this.refreshTable();
      }
    });



  }



  private refreshTable() {
    // Refreshing table using paginator
    // Thanks yeager-j for tips
    // https://github.com/marinantonio/angular-mat-table-crud/issues/12
    this.paginator._changePageSize(this.paginator.pageSize);
  }


  public loadData() {
 //   alert("loadData");
    this.exampleDatabase = new PurchaseInvoiceService(this.httpClient);
  //  alert("new pur inv Service");

    this.dataSource = new ExampleDataSource(this.exampleDatabase, this.paginator, this.sort);
   // alert("after datasource new instance");
    fromEvent(this.filter.nativeElement, 'keyup')
      // .debounceTime(150)
      // .distinctUntilChanged()
      .subscribe(() => {
        if (!this.dataSource) {
          return;
        }
        this.dataSource.filter = this.filter.nativeElement.value;

      });
  }
}


export class ExampleDataSource extends DataSource<InvHeader> {
  _filterChange = new BehaviorSubject('');

  get filter(): string {
    return this._filterChange.value;
  }

  set filter(filter: string) {
    this._filterChange.next(filter);
  }

  filteredData: InvHeader[] = [];
  renderedData: InvHeader[] = [];
  constructor(public _exampleDatabase: PurchaseInvoiceService,public _paginator: MatPaginator, public _sort: MatSort) {
    super();
   //   alert("ExampleDataSource construct");
    // Reset to the first page when the user changes the filter.
    this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
  //       alert("_filterChange");
  }
 
  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<InvHeader[]> {
    //    alert("connect");
    // Listen for any changes in the base data, sorting, filtering, or pagination
    const displayDataChanges = [
      this._exampleDatabase.dataChange,
      this._sort.sortChange,
      this._filterChange,
      this._paginator.page
    ];
   // alert("getAll Purchase before");

    this._exampleDatabase.getAllPurchaseInvoices();

    //alert("after getAll purchase");
    return merge(...displayDataChanges).pipe(map( () => {
        // Filter data
    //  alert("filter data");
    //   alert(JSON.stringify(this._exampleDatabase.data));
        this.filteredData = this._exampleDatabase.data.slice().filter((invheader: InvHeader) => {
          const searchStr = (invheader.Id+invheader.InvoiceNo+invheader.InvoiceDate+invheader.SupplierName+invheader.TrackingNo).toLowerCase();
          return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
        });

        // Sort filtered data
        const sortedData = this.sortData(this.filteredData.slice());

        // Grab the page's slice of the filtered sorted data.
        const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
        this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
        return this.renderedData;
      }
    ));
  }

  disconnect() {}



  /** Returns a sorted copy of the database data. */
 sortData(data: InvHeader[]): InvHeader[] {
    if (!this._sort.active || this._sort.direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      let propertyA: number | string = '';
      let propertyB: number | string = '';
      
      switch (this._sort.active) {
        case 'Id': [propertyA, propertyB] = [a.Id, b.Id]; break;
        case 'InvoiceNo': [propertyA, propertyB] = [a.InvoiceNo, b.InvoiceNo]; break;
        case 'InvoiceDate': [propertyA, propertyB] = [a.InvoiceDate, b.InvoiceDate]; break;
        case 'SupplierName': [propertyA, propertyB] = [a.SupplierName, b.SupplierName]; break;
        case 'PurchaseOrderNo': [propertyA, propertyB] = [a.PurchaseOrderNo, b.PurchaseOrderNo]; break;
        case 'TrackingNo': [propertyA, propertyB] = [a.TrackingNo, b.TrackingNo]; break;
        case 'CourierName': [propertyA, propertyB] = [a.CourierName, b.CourierName]; break;        
    
      }

      const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
      const valueB = isNaN(+propertyB) ? propertyB : +propertyB;

      return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'asc' ? 1 : -1);
    });
  }
}