import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, NgZone, OnInit, ViewChild, Inject } from '@angular/core';
import {SalesOrderService} from '../../../services/salesorder.service';
import {FormControl, Validators} from '@angular/forms';
import {SalesHeader} from '../../../models/SalesHeader';
import { NotificationService } from '../../../services/notification.service';
import { NgxSpinnerService } from "ngx-spinner"; 
import {MatDatepickerModule} from '@angular/material/datepicker';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE, MatDateFormats}  from '@angular/material/core';
import {MatMomentDateModule, MomentDateAdapter} from '@angular/material-moment-adapter';
import { DatePipe, formatDate } from '@angular/common';

const ANOTHER_FORMATS: MatDateFormats  = {
    parse: {
        dateInput: 'DD/MM/YYYY',
    },
    display: {
        dateInput: 'DD/MM/YYYY',
        monthYearLabel: 'MM YYYY',
        dateA11yLabel: 'DD.MM.YYYY',
        monthYearA11yLabel: 'MM YYYY',
    },
};

@Component({
  selector: 'app-edit.salesorder',
  templateUrl: '../../../sales-order/dialogs/edit/edit.salesorder.html',
  styleUrls: ['../../../sales-order/dialogs/edit/edit.salesorder.css'],
  providers: [{provide: MAT_DATE_FORMATS, useValue: ANOTHER_FORMATS},DatePipe]
})
export class EditSalesOrderComponent {
  displayedColumns = ['ProCatalogNo', 'ProDescription','ProSize','ProUnit','ProQuantity','UnitPrice','ProAmount'];
salesorderdetail: any;
shipmentdate = new FormControl();
deliveredon = new FormControl();
//shipdate: any;
totalqty: number;
totalamt: number;
  constructor(public dialogRef: MatDialogRef<EditSalesOrderComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              public salesorderService: SalesOrderService,private SpinnerService: NgxSpinnerService,public notificationService:NotificationService,private datePipe: DatePipe) { 

    this.totalqty =0;
    this.totalamt =0;

this.data.ShipmentDate=this.datePipe.transform(this.data.ShipmentDate,
      'yyyy-MM-dd');
this.data.DeliveredOn=this.datePipe.transform(this.data.DeliveredOn,
      'yyyy-MM-dd');

    this.SpinnerService.show();
//alert(JSON.stringify(this.data)); 
    this.salesorderService.getsalesorderdetail(this.data.OrderNo).then(data => {
      this.salesorderdetail = data;
      this.salesorderdetail.forEach((x) => {
         this.totalqty += Number(x.ProQuantity);
         this.totalamt += Number(x.ProAmount);         
         }) 

         this.totalqty = Number(this.totalqty.toFixed(4));      
         this.totalamt = Number(this.totalamt.toFixed(2));   

         this.SpinnerService.hide();    
         },
         (error : any) => {
          this.SpinnerService.hide();  
         });

   }

  formControl = new FormControl('', [Validators.required]);


ngAfterViewInit() {
}


  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  submit() {
    // emppty stuff
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  UpdateData(): void {
//alert(this.data.ShipmentDate); 
//alert(this.data.DeliveredOn); 

this.data.ShipmentDate=this.datePipe.transform(this.data.ShipmentDate,
      'yyyy/MM/dd');
this.data.DeliveredOn=this.datePipe.transform(this.data.DeliveredOn,
      'yyyy/MM/dd');

//   alert(this.shipmentdate.value); 
 //  alert(JSON.stringify(this.data)); 
 //  return
   this.salesorderService.UpdateData(this.data).then(data => {
    this.notificationService.success('Order Status Updated successfully...');    
    this.dialogRef.close(true);
   },
    (error : any) => {
     this.notificationService.warn('Error While updating Order...'); 
   });
  }

}
