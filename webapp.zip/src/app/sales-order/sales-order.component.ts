import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {SalesOrderService} from '../services/salesorder.service';
import {HttpClient} from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import {SalesHeader} from '../models/SalesHeader';
import {DataSource} from '@angular/cdk/collections';
import {EditSalesOrderComponent} from './dialogs/edit/edit.salesorder.component';
import {BehaviorSubject, fromEvent, merge, Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import { NgxSpinnerService } from "ngx-spinner"; 

@Component({
  selector: 'app-sales-order',
  templateUrl: './sales-order.component.html',
  styleUrls: ['./sales-order.component.css']
})
export class SalesOrderComponent implements OnInit {
  displayedColumns=['OrderNo','OrderDate','SalesCompany','SalesContactName',
  'SalesCity',/*'SalesCountry','Terms','PayMethod',*/'OrderStatus',
  'OrderProcess','InvoiceTotal','ShipStatus'/*,'Carrier','invoiceTotalUSD'*/,
  'orderCurrency','Courier','TrackingNumber'/*,'ShipmentDate','DeliveredOn','ReceivedBy'*/,'actions'];

  exampleDatabase: SalesOrderService | null;

  dataSource: ExampleDataSource | null;

  index: number;
  orderno: string;

  constructor(public httpClient: HttpClient,public dialog: MatDialog,
  public salesorderService: SalesOrderService,private SpinnerService: NgxSpinnerService) {
  //  this.SpinnerService.show();
             //    alert("sales construct");
              }

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild('filter',  {static: true}) filter: ElementRef;

  ngOnInit() {

  //alert("ngOnInit");
    this.loadData();

  }

  refresh() {
    this.loadData();
  }

startEdit(i:number,OrderNo: string,SalesCompany:string,
  SalesContactName:string,SalesCity:string,SalesCountry:string,Terms:string,
 PayMethod:string,OrderDate:string,OrderStatus:string, OrderProcess:string, InvoiceTotal:number,ShipStatus:string,Carrier:string, invoiceTotalUSD:number, orderCurrency:string,Courier:string,TrackingNumber:string,ShipmentDate:string,DeliveredOn:string,ReceivedBy:string) {

    this.orderno = OrderNo;
    // index row is used just for debugging proposes and can be removed

    this.index = i;
    console.log(this.index);
    const dialogRef = this.dialog.open(EditSalesOrderComponent, {
      data: {OrderNo: OrderNo,SalesCompany:SalesCompany,
  SalesContactName:SalesContactName,SalesCity:SalesCity,SalesCountry:SalesCountry,Terms:Terms, PayMethod:PayMethod,OrderDate:OrderDate,OrderStatus:OrderStatus, OrderProcess:OrderProcess,InvoiceTotal:InvoiceTotal,ShipStatus:ShipStatus,Carrier:Carrier, invoiceTotalUSD:invoiceTotalUSD, orderCurrency:orderCurrency,
  Courier:Courier,TrackingNumber:TrackingNumber,ShipmentDate:ShipmentDate,DeliveredOn:DeliveredOn,ReceivedBy:ReceivedBy},
    width: '60%',
    height: '80%'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        // When using an edit things are little different, firstly we find record inside DataService by id
        const foundIndex = this.exampleDatabase.dataChange.value.findIndex(x => x.OrderNo === this.orderno);
        // Then you update that record using data from dialogData (values you enetered)
        this.exampleDatabase.dataChange.value[foundIndex] = this.salesorderService.getSalesOrderData();
        // And lastly refresh table
        this.refreshTable();
      }
    });
  }

  private refreshTable() {
    // Refreshing table using paginator
    // Thanks yeager-j for tips
    // https://github.com/marinantonio/angular-mat-table-crud/issues/12
    this.paginator._changePageSize(this.paginator.pageSize);
  }


  public loadData() {
 //   alert("loadData");
    this.exampleDatabase = new SalesOrderService(this.httpClient);
   // alert("new sales order Service");

    this.dataSource = new ExampleDataSource(this.exampleDatabase, this.paginator, this.sort);
   // alert("after datasource new instance");
    fromEvent(this.filter.nativeElement, 'keyup')
      // .debounceTime(150)
      // .distinctUntilChanged()
      .subscribe(() => {
        if (!this.dataSource) {
    //    alert("load data !datasource");

          return;
        }
        this.dataSource.filter = this.filter.nativeElement.value;
      });
  }
}


export class ExampleDataSource extends DataSource<SalesHeader> {
  _filterChange = new BehaviorSubject('');

  get filter(): string {
    return this._filterChange.value;
  }

  set filter(filter: string) {
    this._filterChange.next(filter);
  }

  filteredData: SalesHeader[] = [];
  renderedData: SalesHeader[] = [];
  constructor(public _exampleDatabase: SalesOrderService,public _paginator: MatPaginator, public _sort: MatSort) {
    super();
     // alert("ExampleDataSource construct");
    // Reset to the first page when the user changes the filter.
    this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
     //    alert("_filterChange");
  }
   
  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<SalesHeader[]> {
      //  alert("connect");
    // Listen for any changes in the base data, sorting, filtering, or pagination
    const displayDataChanges = [
      this._exampleDatabase.dataChange,
      this._sort.sortChange,
      this._filterChange,
      this._paginator.page
    ];
   // alert("getAll Purchase before");

    this._exampleDatabase.getAllSalesOrders();

  //  alert("after getAll purchase");
    return merge(...displayDataChanges).pipe(map( () => {
        // Filter data
    //  alert("filter data");
    //   alert(JSON.stringify(this._exampleDatabase.data));
        this.filteredData = this._exampleDatabase.data.slice().filter((salesheader: SalesHeader) => {
          const searchStr = (salesheader.OrderNo+salesheader.OrderDate+salesheader.SalesCompany+salesheader.OrderStatus+salesheader.invoiceTotalUSD+salesheader.TrackingNumber).toLowerCase();
          return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
        });

        // Sort filtered data
        const sortedData = this.sortData(this.filteredData.slice());

        // Grab the page's slice of the filtered sorted data.
        const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
        this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
        return this.renderedData;
      }
    ));
  }

  disconnect() {}



  /** Returns a sorted copy of the database data. */
 sortData(data: SalesHeader[]): SalesHeader[] {
    if (!this._sort.active || this._sort.direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      let propertyA: number | string = '';
      let propertyB: number | string = '';
      
      switch (this._sort.active) {
        case 'OrderNo': [propertyA, propertyB] = [a.OrderNo, b.OrderNo]; break;
        case 'OrderDate': [propertyA, propertyB] = [a.OrderDate, b.OrderDate]; break;
        case 'SalesCompany': [propertyA, propertyB] = [a.SalesCompany, b.SalesCompany]; break;
        case 'OrderStatus': [propertyA, propertyB] = [a.OrderStatus, b.OrderStatus]; break;
        case 'OrderProcess': [propertyA, propertyB] = [a.OrderProcess, b.OrderProcess]; break;
        case 'InvoiceTotal': [propertyA, propertyB] = [a.InvoiceTotal, b.InvoiceTotal]; break;        
    
      }

      const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
      const valueB = isNaN(+propertyB) ? propertyB : +propertyB;

      return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'asc' ? 1 : -1);
    });
  }
}