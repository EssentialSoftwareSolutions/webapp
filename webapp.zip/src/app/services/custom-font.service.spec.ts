import { TestBed } from '@angular/core/testing';

import { CustomFontService } from './custom-font.service';

describe('CustomFontService', () => {
  let service: CustomFontService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustomFontService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
