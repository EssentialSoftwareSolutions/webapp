import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs';
import {Lead} from '../models/Lead';
import {HttpClient, HttpErrorResponse,HttpHeaders } from '@angular/common/http';
import { environment } from '@environments/environment';
import AES from 'crypto-js/aes';
import Utf8 from 'crypto-js/enc-utf8';

@Injectable()
export class LeadService {

  dataChange: BehaviorSubject<Lead[]> = new BehaviorSubject<Lead[]>([]);
  // Temporarily stores data from dialogs
 LeadData: any;
apitoken: string;
  constructor (private httpClient: HttpClient) {
  this.apitoken=AES.decrypt(sessionStorage.getItem('key'), environment.encryptionkey).toString(Utf8);
 // alert("data service called");
  }

  get data(): Lead[] {
  //  alert("data of service");
    return this.dataChange.value;
  }

  getLeadData() {
    return this.LeadData;
  }

  /** CRUD METHODS */
  getAllLeads(): void {
  let headers : any = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded','token': this.apitoken })
  //alert("getAllLeads service");
    this.httpClient.get<Lead[]>(`${environment.apiUrl}/crm/lead`,{headers: headers}).subscribe(data => {     
    //    alert(JSON.stringify(data));
        this.dataChange.next(data);
      },
      (error: HttpErrorResponse) => {
      alert(JSON.stringify(error));
//      console.log (error.name + ' ' + error.message);
      });
  }

addData(leaddata) {
let headers : any = new HttpHeaders({ 'Content-Type': 'application/json','token': this.apitoken}),

options : any={"LeadCompanyName": leaddata.LeadCompanyName,"LeadContactPerson": leaddata.LeadContactPerson,
"LeadContactNo": leaddata.LeadContactNo,"LeadMobileNo": leaddata.LeadMobileNo,"LeadAddress": leaddata.LeadAddress,"LeadCity":leaddata.LeadCity,"LeadState": leaddata.LeadState,"LeadCountry": leaddata.LeadCountry,"LeadCategory": leaddata.LeadCategory,"LeadSource": leaddata.LeadSource,"LeadRefNo": leaddata.LeadRefNo
};

//alert(JSON.stringify(options));

return new Promise(resolve => {
this.httpClient.post(`${environment.apiUrl}/crm/lead`,JSON.stringify(options),{headers:headers}).subscribe(data => {
this.LeadData={"LeadId": data["LeadId"],"LeadCompanyName": leaddata.LeadCompanyName,"LeadContactPerson": leaddata.LeadContactPerson,
"LeadContactNo": leaddata.LeadContactNo,"LeadMobileNo": leaddata.LeadMobileNo,"LeadAddress": leaddata.LeadAddress,"LeadCity":leaddata.LeadCity,"LeadState": leaddata.LeadState,"LeadCountry": leaddata.LeadCountry,"LeadCategory": leaddata.LeadCategory,"LeadSource": leaddata.LeadSource,"LeadRefNo": leaddata.LeadRefNo
};
//alert(JSON.stringify(data));
//this.toasterService.showToaster('Successfully Updated...', 3000);
resolve(data);}, 
err => {
alert(JSON.stringify(err));
console.log(err);
});
});
}


updateData(leaddata) {
let headers : any = new HttpHeaders({ 'Content-Type': 'application/json','token': this.apitoken}),

options : any={"LeadCompanyName": leaddata.LeadCompanyName,"LeadContactPerson": leaddata.LeadContactPerson,
"LeadContactNo": leaddata.LeadContactNo,"LeadMobileNo": leaddata.LeadMobileNo,"LeadAddress": leaddata.LeadAddress,"LeadCity":leaddata.LeadCity,"LeadState": leaddata.LeadState,"LeadCountry": leaddata.LeadCountry,"LeadCategory": leaddata.LeadCategory,"LeadSource": leaddata.LeadSource,"LeadRefNo": leaddata.LeadRefNo
};
//alert(JSON.stringify(options));
return new Promise(resolve => {
this.httpClient.put(`${environment.apiUrl}/crm/lead/`+leaddata.LeadId,JSON.stringify(options),{headers:headers}).subscribe(data => {
this.LeadData=leaddata;
//alert(JSON.stringify(data));
//this.toasterService.showToaster('Successfully Updated...', 3000);
resolve(data);}, 
err => {
alert(JSON.stringify(err));
//console.log(err);
});
});
}

DeleteLead(LeadId: number) {
let headers : any = new HttpHeaders({ 'Content-Type': 'application/json','token': this.apitoken})

return new Promise((resolve) => {
this.httpClient.delete(`${environment.apiUrl}/crm/lead/`+LeadId,{headers:headers}).subscribe(data => {
//alert(JSON.stringify(data));
//this.toasterService.showToaster('Invoice Successfully Deleted...', 3000);
resolve(data);}, 
err => {
 //  alert("error occured While deleting Invoice...");
alert(JSON.stringify(err));
console.log(err);
});
});
  }


}

