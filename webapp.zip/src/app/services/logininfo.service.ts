import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { environment } from '@environments/environment';
import { User } from '@app/_models';

@Injectable()
export class LoginInfoService {
 apitoken: string;

  constructor (private httpClient: HttpClient) {
  }


updatepassword(username: string,password: string,apitoken: string) {
let headers : any = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded','token': apitoken })
return new Promise(resolve => {
this.httpClient.post<any>(`${environment.apiUrl}`+ '/logininfo/updatepassword/' + username + '/'+ password,null,{headers: headers}).subscribe(data => {
//alert(JSON.stringify(data));
resolve(data);}, 
err => {
alert(err);
});
});
}



}



