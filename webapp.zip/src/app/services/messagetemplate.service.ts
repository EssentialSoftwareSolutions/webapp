import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs';
import {Template} from '../models/Template';
import {HttpClient, HttpErrorResponse,HttpHeaders } from '@angular/common/http';
import { environment } from '@environments/environment';
import AES from 'crypto-js/aes';
import Utf8 from 'crypto-js/enc-utf8';

@Injectable()
export class MessageTemplateService {

  dataChange: BehaviorSubject<Template[]> = new BehaviorSubject<Template[]>([]);
  // Temporarily stores data from dialogs
MessageTemplateData: any;
apitoken: string;
  constructor (private httpClient: HttpClient) {
  this.apitoken=AES.decrypt(sessionStorage.getItem('key'), environment.encryptionkey).toString(Utf8);
  //alert("data service called");
  }

  get data(): Template[] {
//    alert("data of service");
    return this.dataChange.value;
  }

  getMessageTemplateData() {
    return this.MessageTemplateData;
  }

  /** CRUD METHODS */
  getAllMessageTemplates(): void {
  let headers : any = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded','token': this.apitoken })
  //alert("getAllLeads service");
    this.httpClient.get<Template[]>(`${environment.apiUrl}/crm/template`,{headers: headers}).subscribe(data => {     
    //    alert(JSON.stringify(data));
        this.dataChange.next(data);
      },
      (error: HttpErrorResponse) => {
      alert(JSON.stringify(error));
//      console.log (error.name + ' ' + error.message);
      });
  }

addData(templatedata,attachfileBase64: string) {
let headers : any = new HttpHeaders({ 'Content-Type': 'application/json','token': this.apitoken}),
options : any={"TemplateName":templatedata.TemplateName,
"TemplatePara1":templatedata.TemplatePara1,
"TemplatePara2": templatedata.TemplatePara2,
"TemplatePara3": templatedata.TemplatePara3,
"TemplatePara4":templatedata.TemplatePara4,
"TemplatePara5": templatedata.TemplatePara5,
"SendAttachment":templatedata.SendAttachment,
"AttachmentType": templatedata.AttachmentType,
"AttachmentCaption": templatedata.AttachmentCaption,
"AttachFileBase64":attachfileBase64
};

//alert(attachfileBase64);

return new Promise(resolve => {
this.httpClient.post(`${environment.apiUrl}/crm/template`,JSON.stringify(options),{headers:headers}).subscribe(data => {
alert(JSON.stringify(data["TemplateData"]));

this.MessageTemplateData={"TemplateId": data["TemplateData"].templateid,"TemplateName":templatedata.TemplateName,
"TemplatePara1":templatedata.TemplatePara1,
"TemplatePara2": templatedata.TemplatePara2,
"TemplatePara3": templatedata.TemplatePara3,
"TemplatePara4":templatedata.TemplatePara4,
"TemplatePara5": templatedata.TemplatePara5,
"SendAttachment":templatedata.SendAttachment,
"AttachmentType": templatedata.AttachmentType,
"AttachFileExt": data["TemplateData"].attachfileext,
"AttachmentCaption": templatedata.AttachmentCaption
};
//alert(JSON.stringify(data));
//this.toasterService.showToaster('Successfully Updated...', 3000);
resolve(data);}, 
err => {
alert(JSON.stringify(err));
console.log(err);
});
});
}

updateData(templatedata,attachfileBase64: string) {
let headers : any = new HttpHeaders({ 'Content-Type': 'application/json','token': this.apitoken}),

options : any={"TemplateName":templatedata.TemplateName,"TemplatePara1": templatedata.TemplatePara1,"TemplatePara2": templatedata.TemplatePara2,
"TemplatePara3": templatedata.TemplatePara3,"TemplatePara4": templatedata.TemplatePara4,"TemplatePara5": templatedata.TemplatePara5,"SendAttachment":templatedata.SendAttachment,"AttachmentType": templatedata.AttachmentType,"AttachFileExt":templatedata.AttachFileExt,"AttachmentCaption": templatedata.AttachmentCaption,"AttachFileBase64":attachfileBase64
};
//alert(JSON.stringify(options));
return new Promise(resolve => {
this.httpClient.put(`${environment.apiUrl}/crm/template/`+templatedata.TemplateId,JSON.stringify(options),{headers:headers}).subscribe(data => {

//alert(JSON.stringify(data["templatedata"].attachfileext));

this.MessageTemplateData={"TemplateId": templatedata.TemplateId,"TemplateName":templatedata.TemplateName,
"TemplatePara1":templatedata.TemplatePara1,
"TemplatePara2": templatedata.TemplatePara2,
"TemplatePara3": templatedata.TemplatePara3,
"TemplatePara4":templatedata.TemplatePara4,
"TemplatePara5": templatedata.TemplatePara5,
"SendAttachment":templatedata.SendAttachment,
"AttachmentType": templatedata.AttachmentType,
"AttachFileExt": data["templatedata"].attachfileext,
"AttachmentCaption": templatedata.AttachmentCaption};

//this.toasterService.showToaster('Successfully Updated...', 3000);
resolve(data);}, 
err => {
alert(JSON.stringify(err));
//console.log(err);
});
});
}

GetAttachment(TemplateId: number) {
  let headers : any = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded','token': this.apitoken })
return new Promise(resolve => {
this.httpClient.get(`${environment.apiUrl}/crm/template/attachment/`+TemplateId,{headers: headers}).subscribe(data => {  
 //  alert(JSON.stringify(data));
resolve(data);
}, 
err => {
console.log(err);
});
});
}

DeleteTemplate(TemplateId: number) {
let headers : any = new HttpHeaders({ 'Content-Type': 'application/json','token': this.apitoken})

return new Promise((resolve) => {
this.httpClient.delete(`${environment.apiUrl}/crm/template/`+TemplateId,{headers:headers}).subscribe(data => {
//alert(JSON.stringify(data));
//this.toasterService.showToaster('Invoice Successfully Deleted...', 3000);
resolve(data);}, 
err => {
 //  alert("error occured While deleting Invoice...");
alert(JSON.stringify(err));
console.log(err);
});
});
  }


}

