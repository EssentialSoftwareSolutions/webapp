import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
  
@Injectable({
  providedIn: 'root'
})
export class NotificationService {
  config: any = {duration: 4000,horizontalPosition: 'center', verticalPosition: 'top'};

  constructor(public snackBar: MatSnackBar) { }
  


  success(msg) {
    this.config['panelClass'] = ['notification', 'success'];
    this.snackBar.open(msg, '',this.config);
  }

  warn(msg) {
    this.config['panelClass'] = ['notification', 'warn'];
    this.snackBar.open(msg, '', this.config);
  }
}
