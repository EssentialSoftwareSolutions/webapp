import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs';
import {InvHeader} from '../models/InvHeader';
import {HttpClient, HttpErrorResponse,HttpHeaders } from '@angular/common/http';
import { environment } from '@environments/environment';
import AES from 'crypto-js/aes';
import Utf8 from 'crypto-js/enc-utf8';

@Injectable()
export class PurchaseInvoiceService {

  dataChange: BehaviorSubject<InvHeader[]> = new BehaviorSubject<InvHeader[]>([]);
  // Temporarily stores data from dialogs
 PurchaseInvoiceData: any;
apitoken: string;
  constructor (private httpClient: HttpClient) {
  this.apitoken=AES.decrypt(sessionStorage.getItem('key'), environment.encryptionkey).toString(Utf8);
  //alert("data service called");
  }

  get data(): InvHeader[] {
    //alert("data of service");
    return this.dataChange.value;
  }

  getPurchaseInvoiceData() {
    return this.PurchaseInvoiceData;
  }

  /** CRUD METHODS */
  getAllPurchaseInvoices(): void {
  let headers : any = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded','token': this.apitoken })
  //alert("getAllOrders service");
    this.httpClient.get<InvHeader[]>(`${environment.apiUrl}/getpurchaseinvoicelist`,{headers: headers}).subscribe(data => {     
    //    alert(JSON.stringify(data));
        this.dataChange.next(data);
      },
      (error: HttpErrorResponse) => {
      alert(JSON.stringify(error));
//      console.log (error.name + ' ' + error.message);
      });
  }

  getAllPurchaseDetail(): void {
  let headers : any = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded','token': this.apitoken })
  //alert("getAllOrders service");
    this.httpClient.get<InvHeader[]>(`${environment.apiUrl}/getpurchaseinvoicedetail`,{headers: headers}).subscribe(data => {     
    //    alert(JSON.stringify(data));
        this.dataChange.next(data);
      },
      (error: HttpErrorResponse) => {
      alert(JSON.stringify(error));
//      console.log (error.name + ' ' + error.message);
      });
  }


getpurchaseinvoicedetail(invoiceno: string) {
  let headers : any = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded','token': this.apitoken })
return new Promise(resolve => {
this.httpClient.get(`${environment.apiUrl}/`+'getpurchaseinvoicedetail/'+ invoiceno,{headers: headers}).subscribe(data => {
resolve(data);
}, 
err => {
console.log(err);
});
});
}

//DutyAmount,PenaltyAmount,BillOfEntryNumber,ClearanceInvoiceNumber,ClearanceCharges

updateData(invoicedata) {
let headers : any = new HttpHeaders({ 'Content-Type': 'application/json','token': this.apitoken}),
options : any={"Id":invoicedata.Id,"CourierName":invoicedata.CourierName,"TrackingNo":invoicedata.TrackingNo,"DutyAmount" : invoicedata.DutyAmount,"PenaltyAmount": invoicedata.PenaltyAmount,"BillOfEntryNumber": invoicedata.BillOfEntryNumber,
"ClearanceInvoiceNumber": invoicedata.ClearanceInvoiceNumber,
"ClearanceCharges":invoicedata.ClearanceCharges,
"DoInvoice": invoicedata.DoInvoice,"DoCharges": invoicedata.DoCharges,
"ShippingCharges": invoicedata.ShippingCharges};

//alert(JSON.stringify(options));

return new Promise(resolve => {
this.httpClient.post(`${environment.apiUrl}/purchaseinvoiceheader/update/`+invoicedata.InvoiceNo,JSON.stringify(options),{headers:headers}).subscribe(data => {
this.PurchaseInvoiceData=invoicedata;
//alert(JSON.stringify(data));
//this.toasterService.showToaster('Successfully Updated...', 3000);
resolve(data);}, 
err => {
//alert(JSON.stringify(err));
console.log(err);
});
});
}

DeleteInvoice(InvoiceNo: number) {
let headers : any = new HttpHeaders({ 'Content-Type': 'application/json','token': this.apitoken})

    return new Promise((resolve) => {
this.httpClient.post(`${environment.apiUrl}/purchaseinvoiceheader/delete/`+InvoiceNo,null,{headers:headers}).subscribe(data => {
//alert(JSON.stringify(data));
//this.toasterService.showToaster('Invoice Successfully Deleted...', 3000);
resolve(data);}, 
err => {
   alert("error occured While deleting Invoice...");
//alert(JSON.stringify(err));
console.log(err);
});
});
  }


}

