import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs';
import {SalesHeader} from '../models/SalesHeader';
import {HttpClient, HttpErrorResponse,HttpHeaders } from '@angular/common/http';
import { environment } from '@environments/environment';
import AES from 'crypto-js/aes';
import Utf8 from 'crypto-js/enc-utf8';

@Injectable()
export class SalesOrderService {

  dataChange: BehaviorSubject<SalesHeader[]> = new BehaviorSubject<SalesHeader[]>([]);
  // Temporarily stores data from dialogs
 SalesOrderData: any;
apitoken: string;
  constructor (private httpClient: HttpClient) {
  this.apitoken=AES.decrypt(sessionStorage.getItem('key'), environment.encryptionkey).toString(Utf8);
//  alert(this.apitoken);
//  alert("data service constructor called");
  }

  get data(): SalesHeader[] {
  //  alert("data() of service");
    return this.dataChange.value;
  }

  getSalesOrderData() {
  //alert("getSalesOrderData of service");
    return this.SalesOrderData;
  }

  /** CRUD METHODS */
  getAllSalesOrders(): void {
  let headers : any = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded','token': this.apitoken })
  //alert("getAllOrders service");
    this.httpClient.get<SalesHeader[]>(`${environment.apiUrl}/syncsalesorder`,{headers: headers}).subscribe(data => {     
    //    alert(JSON.stringify(data));
        this.dataChange.next(data);
      },
      (error: HttpErrorResponse) => {
 //     alert(JSON.stringify(error));
//      console.log (error.name + ' ' + error.message);
      });
  }

getsalesorderdetail(orderno: string) {
  let headers : any = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded','token': this.apitoken })
return new Promise(resolve => {
this.httpClient.get(`${environment.apiUrl}/`+'syncsalesorder/detail/'+ orderno,{headers: headers}).subscribe(data => {
resolve(data);
}, 
err => {
console.log(err);
});
});
}

UpdateData(invoicedata) {
let headers : any = new HttpHeaders({ 'Content-Type': 'application/json','token': this.apitoken}),
options : any={"Courier":invoicedata.Courier,"TrackingNumber":
invoicedata.TrackingNumber,"ShipmentDate":invoicedata.ShipmentDate,
"DeliveredOn":invoicedata.DeliveredOn,"ReceivedBy":invoicedata.ReceivedBy};

//alert(JSON.stringify(options));

return new Promise(resolve => {
this.httpClient.post(`${environment.apiUrl}/salesorder/update/`+invoicedata.OrderNo,JSON.stringify(options),{headers:headers}).subscribe(data => {
this.SalesOrderData=invoicedata;
//alert(JSON.stringify(invoicedata));
//this.toasterService.showToaster('Successfully Updated...', 3000);
resolve(data);}, 
err => {
//alert(JSON.stringify(err));
console.log(err);
});
});
}

}



