import {Injectable} from '@angular/core';
import {HttpClient, HttpErrorResponse,HttpHeaders } from '@angular/common/http';
import { environment } from '@environments/environment';
import AES from 'crypto-js/aes';
import Utf8 from 'crypto-js/enc-utf8';

@Injectable()
export class StockService {

 apitoken: string;
  constructor (private httpClient: HttpClient) {
  this.apitoken=AES.decrypt(sessionStorage.getItem('key'), environment.encryptionkey).toString(Utf8);
  }


 syncstock() {
 return new Promise(resolve => {
 this.httpClient.post<any>(`${environment.apiUrl}/syncstockdata`,null,{
 headers: new HttpHeaders()
.set('token', this.apitoken)}).subscribe(data => {
//alert(JSON.stringify(data));
resolve(data);}, 
err => {
alert(err);
});
});
}



}



