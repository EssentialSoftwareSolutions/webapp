import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SyncSalesOrderComponent } from './sync-sales-order.component';

describe('SyncSalesOrderComponent', () => {
  let component: SyncSalesOrderComponent;
  let fixture: ComponentFixture<SyncSalesOrderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SyncSalesOrderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SyncSalesOrderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
