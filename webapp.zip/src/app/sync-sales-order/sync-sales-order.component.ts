import { Component, OnInit,AfterViewChecked } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { environment } from '@environments/environment';
import AES from 'crypto-js/aes';
import Utf8 from 'crypto-js/enc-utf8';

@Component({
  selector: 'app-sync-sales-order',
  templateUrl: './sync-sales-order.component.html',
  styleUrls: ['./sync-sales-order.component.css']
})
export class SyncSalesOrderComponent implements OnInit,AfterViewChecked {
  apitoken: any;
IsWait: boolean;
lastupdatedon: string;

  constructor(private http: HttpClient) { 

//    alert(this.apitoken);
  }

  ngOnInit(): void {
    this.apitoken=AES.decrypt(sessionStorage.getItem('key'), environment.encryptionkey).toString(Utf8);
  }

ngAfterViewChecked(): void {
//alert(this.apitoken);
this.http.get<any>(`${environment.apiUrl}/syncstockdata/synchistory/SalesOrder`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
        if (data) {
           this.lastupdatedon = data[0].lastupdatedon;
        }
    //     alert(data);
      },
      err => {
         alert(JSON.stringify(err));
      });  
  
}  

  syncdata() {
this.IsWait = true;
  // alert(JSON.stringify(localStorage.getItem('currentUser')));
      //alert(this.apitoken);
    
      this.http.post<any>(`${environment.apiUrl}/syncsalesorder`,null,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
        this.IsWait = false;
//           alert(JSON.stringify(data));
         alert("Data Synchronised Successfully...");
      },
      err => {
         alert(JSON.stringify(err));
      });

  }

}
