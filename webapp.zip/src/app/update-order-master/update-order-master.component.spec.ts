import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateOrderMasterComponent } from './update-order-master.component';

describe('UpdateOrderMasterComponent', () => {
  let component: UpdateOrderMasterComponent;
  let fixture: ComponentFixture<UpdateOrderMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateOrderMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateOrderMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
