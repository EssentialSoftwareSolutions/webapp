import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { environment } from '@environments/environment';
import AES from 'crypto-js/aes';
import Utf8 from 'crypto-js/enc-utf8';

@Component({
  selector: 'app-update-order-master',
  templateUrl: './update-order-master.component.html',
  styleUrls: ['./update-order-master.component.css']
})
export class UpdateOrderMasterComponent implements OnInit {
  apitoken: any;

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
      this.apitoken=AES.decrypt(sessionStorage.getItem('key'), environment.encryptionkey).toString(Utf8);
  }

  syncdata() {
  // alert(JSON.stringify(localStorage.getItem('currentUser')));
      //alert(this.apitoken);
    
      this.http.post<any>(`${environment.apiUrl}/updateordermaster`,null,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
//           alert(JSON.stringify(data));
         alert("Data Synchronised Successfully...");
      },
      err => {
         alert(JSON.stringify(err));
      });

  }

}
