import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewOrderMasterComponent } from './view-order-master.component';

describe('ViewOrderMasterComponent', () => {
  let component: ViewOrderMasterComponent;
  let fixture: ComponentFixture<ViewOrderMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewOrderMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewOrderMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
