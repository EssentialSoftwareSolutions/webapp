import { Component, OnInit } from '@angular/core';
import { DatePipe, formatDate } from '@angular/common';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import {FormControl} from '@angular/forms';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { environment } from '@environments/environment';
import {ExcelService} from '../services/excel.service';
import AES from 'crypto-js/aes';
import Utf8 from 'crypto-js/enc-utf8';

export const PICK_FORMATS = {
  parse: {dateInput: {month: 'short', year: 'numeric', day: 'numeric'}},
  display: {
      dateInput: 'input',
      monthYearLabel: {year: 'numeric', month: 'short'},
      dateA11yLabel: {year: 'numeric', month: 'long', day: 'numeric'},
      monthYearA11yLabel: {year: 'numeric', month: 'long'}
  }
};

class PickDateAdapter extends NativeDateAdapter {
  format(date: Date, displayFormat: Object): string {
      if (displayFormat === 'input') {
          return formatDate(date,'yyyy/MM/dd',this.locale);;
      } else {
          return date.toDateString();
      }
  }
}

@Component({
  selector: 'app-view-order-master',
  templateUrl: './view-order-master.component.html',
  styleUrls: ['./view-order-master.component.css'],
  providers: [DatePipe,{provide: DateAdapter, useClass: PickDateAdapter},
    {provide: MAT_DATE_FORMATS, useValue: PICK_FORMATS}]    

})

export class ViewOrderMasterComponent implements OnInit {
fromdate  =  new FormControl(new  Date());
todate  =  new FormControl(new  Date());
orderdatefrom: string;
orderdateto: string;
file_orderdatefrom: string;
file_orderdateto: string;
public getorderdata : any;
public columnDefs:any[];
private gridApi;
private gridColumnApi;  
apitoken: any;

/*TypeofSales,SalesPerson,Discount,Region,CompanyName,PurchaseOrderNumber,PurchaseOrderDate,StockLocation,CreditDays,ProductCategory,
CSNo,CASNo,Qty,Packing,Unit,Amount,GST,Total,ImportPONO,ImportPODate,ShipmentNo,ImportTrackingNO,State,City,ShipToAddress,
ShipmentDate,Courier,TrackingNumber,ChemsceneOrderNo,ChemsceneInvoiceNo,DeliveredOn,ReceivedBy,PaymentTerm,PaymentStatus,
Remarks,DueOn,IsDue*/

  constructor(private http: HttpClient,private datePipe: DatePipe,private excelService:ExcelService) { 
this.columnDefs = [
        {headerName: 'Type of Sales', width:100,field: 'TypeofSales',resizable: true, sortable: true, filter: true}, 
        {headerName: 'Sales Person', field: 'SalesPerson',width:100,resizable: true, sortable: true, filter: true},        
        {headerName: 'Discount',width:50, field: 'Discount',resizable: true, sortable: true, filter: true},
        {headerName: 'Region',field: 'Region', width:100, sortable: true, filter: true},
        {headerName: 'Company', field: 'CompanyName',width:125,resizable: true, sortable: true, filter: true},
        {headerName: 'Purchase Order Number', field: 'PurchaseOrderNumber',width:100, sortable: true,resizable: true, filter: true},
        {headerName: 'Purchase Order Date', width:75,field: 'PurchaseOrderDate',resizable: true, sortable: true, filter: true},
        {headerName: 'Stock Location', width:75,field: 'StockLocation',resizable: true, sortable: true, filter: true},
        {headerName: 'Credit Days',width:50, field: 'CreditDays',resizable: true, sortable: true, filter: true},
        {headerName: 'Product Category', width:50,field: 'ProductCategory', sortable: true,resizable: true, filter: true}, 
        {headerName: 'CS No', width:75,field: 'CSNo', sortable: true, filter: true,resizable: true},  
        {headerName: 'CAS No', width:75,field: 'CASNo',resizable: true, sortable: true, filter: true},              
        {headerName: 'Qty',width:75, field: 'Qty', sortable: true, filter: true},
        {headerName: 'Packing',width:75, field: 'Packing', sortable: true, filter: true,resizable: true},
        {headerName: 'Unit', field: 'Unit',width:30,resizable: true, sortable: true, filter: true},
        {headerName: 'Amount',field: 'Amount', width:75,resizable: true, sortable: true, filter: true},
        {headerName: 'GST', field: 'GST',width:50,resizable: true, sortable: true, filter: true},
        {headerName: 'Total',field: 'Total', width:75,resizable: true, sortable: true, filter: true},
        {headerName: 'Import PO NO',width:75, field: 'ImportPONO',resizable: true, sortable: true, filter: true},
        {headerName: 'Import PO Date', field: 'ImportPODate',width:75,resizable: true, sortable: true, filter: true},
        {headerName: 'Shipment No',field: 'ShipmentNo', width:50,resizable: true, sortable: true, filter: true},
        {headerName: 'Courier', field: 'Courier',width:75,resizable: true, sortable: true, filter: true},
        {headerName: 'Tracking Number',field: 'TrackingNumber', width:75, sortable: true,resizable: true,  filter: true},        
        {headerName: 'Chemscene Order No',field: 'ChemsceneOrderNo', width:50,resizable: true, sortable: true, filter: true},
        {headerName: 'Chemscene Invoice No', field: 'ChemsceneInvoiceNo',width:50,resizable: true, sortable: true, filter: true},
        {headerName: 'Delivered On',field: 'DeliveredOn', width:50, sortable: true,resizable: true,  filter: true},  
        {headerName: 'Received By',field: 'ReceivedBy', width:75, sortable: true,resizable: true,  filter: true},        
        {headerName: 'Payment Term',field: 'PaymentTerm', width:50,resizable: true, sortable: true, filter: true},
        {headerName: 'Payment Status', field: 'PaymentStatus',width:50,resizable: true, sortable: true, filter: true},
        {headerName: 'Remarks',field: 'Remarks', width:125,resizable: true,  sortable: true, filter: true},  
        {headerName: 'Due On', field: 'DueOn',width:75,resizable: true, sortable: true, filter: true},
        {headerName: 'Is Due',field: 'IsDue', width:75,resizable: true, sortable: true, filter: true}                    
    ];
  }

  ngOnInit(): void {
this.apitoken=AES.decrypt(sessionStorage.getItem('key'), environment.encryptionkey).toString(Utf8);
  }


  onGridReady(params) {
 //   alert("grid ready");
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

  }   



  showdata() {
/*    this.pmtdatefrom =this.datePipe.transform(this.fromdate.value,'yyyy/MM/dd');
    this.pmtdateto =this.datePipe.transform(this.todate.value,'yyyy/MM/dd');
    this.file_pmtdatefrom =this.datePipe.transform(this.fromdate.value,'yyyyMMdd');
    this.file_pmtdateto =this.datePipe.transform(this.todate.value,'yyyyMMdd');*/
    
    this.getorderdata = [];
//      alert(this.apitoken);
      this.http.get<any>(`${environment.apiUrl}/importorder`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
         this.getorderdata = data;
  //       alert(JSON.stringify(data));
      },
      err => {
         alert(JSON.stringify(err));
      });
  }

  exportdata() {
    const params = {
      fileName: 'Order Master Report' ,
      columnSeparator: ';'
    };
    this.gridApi.exportDataAsCsv(params);
  }

  exportAsXLSX():void {
  //  this.getorderdata = [];
      this.http.get<any>(`${environment.apiUrl}/importorder`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
      //   this.getorderdata = data;
         this.excelService.exportAsExcelFile(data, 'Order Master Report');         
      },
      err => {
         alert(JSON.stringify(err));
      });  
  }

}


