import { Component, OnInit,AfterViewChecked } from '@angular/core';
import { DatePipe, formatDate } from '@angular/common';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import {FormControl} from '@angular/forms';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { environment } from '@environments/environment';
import {ExcelService} from '../services/excel.service';
import AES from 'crypto-js/aes';
import Utf8 from 'crypto-js/enc-utf8';

export const PICK_FORMATS = {
  parse: {dateInput: {month: 'short', year: 'numeric', day: 'numeric'}},
  display: {
      dateInput: 'input',
      monthYearLabel: {year: 'numeric', month: 'short'},
      dateA11yLabel: {year: 'numeric', month: 'long', day: 'numeric'},
      monthYearA11yLabel: {year: 'numeric', month: 'long'}
  }
};

class PickDateAdapter extends NativeDateAdapter {
  format(date: Date, displayFormat: Object): string {
      if (displayFormat === 'input') {
          return formatDate(date,'yyyy/MM/dd',this.locale);;
      } else {
          return date.toDateString();
      }
  }
}

@Component({
  selector: 'app-view-productinfo',
  templateUrl: './view-productinfo.component.html',
  styleUrls: ['./view-productinfo.component.css'],
  providers: [DatePipe,{provide: DateAdapter, useClass: PickDateAdapter},
    {provide: MAT_DATE_FORMATS, useValue: PICK_FORMATS}]    

})

export class ViewProductInfoComponent implements OnInit,AfterViewChecked {
fromdate  =  new FormControl(new  Date());
todate  =  new FormControl(new  Date());
orderdatefrom: string;
orderdateto: string;
lastupdatedon: string;
file_orderdatefrom: string;
file_orderdateto: string;
public getproductmaster : any;
public columnDefs:any[];
private gridApi;
private gridColumnApi;  
apitoken: any;
IsWait: boolean;
  currentuser: any;
  currentusergroup: string;

  constructor(private http: HttpClient,private datePipe: DatePipe,private excelService:ExcelService) { 

this.columnDefs = [
        {headerName: 'CS No', width:150,field: 'CSNo',resizable: true, sortable: true, filter: true}, 
        {headerName: 'CAS', field: 'CAS',width:150,resizable: true, sortable: true, filter: true},
        {headerName: 'Product Desc', field: 'DrugNames',width:250,resizable: true, sortable: true, filter: true},        
    ];


  }

ngOnInit(): void {
this.apitoken=AES.decrypt(sessionStorage.getItem('key'), environment.encryptionkey).toString(Utf8);
    this.currentuser=JSON.parse(sessionStorage.getItem('currentUser'));
    this.currentusergroup=this.currentuser["data"].login_Group;  

  }

ngAfterViewChecked(): void {
//alert(this.apitoken);
this.http.get<any>(`${environment.apiUrl}/syncstockdata/synchistory/ProductInfo`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
        if (data) {
           this.lastupdatedon = data[0].lastupdatedon;
        }
    //     alert(data);
      },
      err => {
         alert(JSON.stringify(err));
      });  
  
}  
 

onGridReady(params) {
 //   alert("grid ready");
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

  }   



  showdata() {
/*    this.pmtdatefrom =this.datePipe.transform(this.fromdate.value,'yyyy/MM/dd');
    this.pmtdateto =this.datePipe.transform(this.todate.value,'yyyy/MM/dd');
    this.file_pmtdatefrom =this.datePipe.transform(this.fromdate.value,'yyyyMMdd');
    this.file_pmtdateto =this.datePipe.transform(this.todate.value,'yyyyMMdd');*/
    this.IsWait = true;
    this.getproductmaster = [];
//      alert(this.apitoken);
      this.http.get<any>(`${environment.apiUrl}/productinfo`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
                 this.IsWait = false;
         this.getproductmaster = data;
  //       alert(JSON.stringify(data));
      },
      err => {
         alert(JSON.stringify(err));
      });
  }

  exportdata() {
    const params = {
      fileName: 'Product Master' ,
      columnSeparator: ';'
    };
    this.gridApi.exportDataAsCsv(params);
  }

  exportAsXLSX():void {
  this.IsWait = true;
  //  this.getorderdata = [];
      this.http.get<any>(`${environment.apiUrl}/productinfo`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
                 this.IsWait = false;
      //   this.getorderdata = data;
         this.excelService.exportAsExcelFile(data, 'Product Master');         
      },
      err => {
         alert(JSON.stringify(err));
      });  
  }

  syncdata():void {
  this.IsWait = true;
        this.http.post<any>(`${environment.apiUrl}/productinfo`,null,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
                 this.IsWait = false;
          alert(data.message);
      },
      err => {
         alert(JSON.stringify(err));
      });  
  }

}


