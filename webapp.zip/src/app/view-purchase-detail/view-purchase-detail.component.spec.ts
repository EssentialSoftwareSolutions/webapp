import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewPurchaseDetailComponent } from './view-purchase-detail.component';

describe('ViewPurchaseDetailComponent', () => {
  let component: ViewPurchaseDetailComponent;
  let fixture: ComponentFixture<ViewPurchaseDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewPurchaseDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewPurchaseDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
