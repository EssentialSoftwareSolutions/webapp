import { Component, OnInit } from '@angular/core';
import { DatePipe, formatDate } from '@angular/common';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import {FormControl} from '@angular/forms';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { environment } from '@environments/environment';
import {ExcelService} from '../services/excel.service';
import AES from 'crypto-js/aes';
import Utf8 from 'crypto-js/enc-utf8';

export const PICK_FORMATS = {
  parse: {dateInput: {month: 'short', year: 'numeric', day: 'numeric'}},
  display: {
      dateInput: 'input',
      monthYearLabel: {year: 'numeric', month: 'short'},
      dateA11yLabel: {year: 'numeric', month: 'long', day: 'numeric'},
      monthYearA11yLabel: {year: 'numeric', month: 'long'}
  }
};

class PickDateAdapter extends NativeDateAdapter {
  format(date: Date, displayFormat: Object): string {
      if (displayFormat === 'input') {
          return formatDate(date,'yyyy/MM/dd',this.locale);
      } else {
          return date.toDateString();
      }
  }
}
@Component({
  selector: 'app-view-purchase-detail',
  templateUrl: './view-purchase-detail.component.html',
  styleUrls: ['./view-purchase-detail.component.css']
})
export class ViewPurchaseDetailComponent implements OnInit {
fromdate  =  new FormControl(new  Date());
todate  =  new FormControl(new  Date());
orderdatefrom: string;
orderdateto: string;
file_orderdatefrom: string;
file_orderdateto: string;
public getpurchasedetail : any;
public columnDefs:any[];
private gridApi;
private gridColumnApi;  
apitoken: any;
IsWait: boolean;

// Id,InvoiceNo,InvoiceDate: string,PurchaseOrderNo: string,
// TrackingNo: string,CourierName: string, ProductId: string,
// ProductDescription: string,CASNo: string, BatchNo: string,
// MfgDate: string, ExpDate: string, Size: string, Qty: number,
// UnitPrice: number

  constructor(private http: HttpClient,private datePipe: DatePipe,private excelService:ExcelService) { 
this.columnDefs = [
        {headerName: 'Id', width:65,field: 'Id',resizable: true, sortable: true, filter: true}, 
        {headerName: 'Inv. No.', width:160,field: 'InvoiceNo',resizable: true, sortable: true, filter: true},         
        {headerName: 'Inv. Date', field: 'InvoiceDate',width:125,resizable: true, sortable: true, filter: true},    
        {headerName: 'CS No', width:125,field: 'ProductId',resizable: true, sortable: true, filter: true},            
        {headerName: 'CAS No',width:125, field: 'CASNo',resizable: true, sortable: true, filter: true},
        {headerName: 'Size', field: 'Size',width:100, sortable: true,resizable: true, filter: true},
        {headerName: 'Qty', width:75,field: 'Qty',resizable: true, sortable: true, filter: true},
        {headerName: 'Mfg Date', width:100,field: 'MfgDate', resizable: true,sortable: true, filter: true},  
        {headerName: 'Exp Date', width:125,field: 'ExpDate',resizable: true, sortable: true, filter: true},              
        {headerName: 'Product Description',field: 'ProductDescription', width:125, resizable: true,sortable: true, filter: true},
        {headerName: 'Tracking No', field: 'TrackingNo',width:100,resizable: true, sortable: true, filter: true},
        {headerName: 'BatchNo', width:100,field: 'BatchNo',resizable: true, sortable: true, filter: true}, 
        {headerName: 'Courier Name',width:100, field: 'CourierName',resizable: true, sortable: true, filter: true}
    ];


  }

  ngOnInit(): void {
this.apitoken=AES.decrypt(sessionStorage.getItem('key'), environment.encryptionkey).toString(Utf8);
  }


 

  onGridReady(params) {
 //   alert("grid ready");
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

  }   



  showdata() {
/*    this.pmtdatefrom =this.datePipe.transform(this.fromdate.value,'yyyy/MM/dd');
    this.pmtdateto =this.datePipe.transform(this.todate.value,'yyyy/MM/dd');
    this.file_pmtdatefrom =this.datePipe.transform(this.fromdate.value,'yyyyMMdd');
    this.file_pmtdateto =this.datePipe.transform(this.todate.value,'yyyyMMdd');*/
    this.IsWait = true;
    this.getpurchasedetail = [];
//      alert(this.apitoken);
      this.http.get<any>(`${environment.apiUrl}/getpurchaseinvoicedetail`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
         this.getpurchasedetail = data;
         this.IsWait = false;
  //       alert(JSON.stringify(data));
      },
      err => {
         alert(JSON.stringify(err));
      });
  }

  exportdata() {
    const params = {
      fileName: 'Purchase Product Detail Report' ,
      columnSeparator: ';'
    };
    this.gridApi.exportDataAsCsv(params);
  }

  exportAsXLSX():void {
  this.IsWait = true;
      this.http.get<any>(`${environment.apiUrl}/getpurchaseinvoicedetail`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
        this.IsWait = false;
         this.excelService.exportAsExcelFile(data, 'Purchase Product Detail  Report');         
      },
      err => {
         alert(JSON.stringify(err));
      });  
  }

}
