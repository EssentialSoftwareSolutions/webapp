import { Component, OnInit } from '@angular/core';
import { DatePipe, formatDate } from '@angular/common';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import {FormControl} from '@angular/forms';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { environment } from '@environments/environment';
import {ExcelService} from '../services/excel.service';
import AES from 'crypto-js/aes';
import Utf8 from 'crypto-js/enc-utf8';

export const PICK_FORMATS = {
  parse: {dateInput: {month: 'short', year: 'numeric', day: 'numeric'}},
  display: {
      dateInput: 'input',
      monthYearLabel: {year: 'numeric', month: 'short'},
      dateA11yLabel: {year: 'numeric', month: 'long', day: 'numeric'},
      monthYearA11yLabel: {year: 'numeric', month: 'long'}
  }
};

class PickDateAdapter extends NativeDateAdapter {
  format(date: Date, displayFormat: Object): string {
      if (displayFormat === 'input') {
          return formatDate(date,'yyyy/MM/dd',this.locale);
      } else {
          return date.toDateString();
      }
  }
}

@Component({
  selector: 'app-view-purchase-invoice',
  templateUrl: './view-purchase-invoice.component.html',
  styleUrls: ['./view-purchase-invoice.component.css'],
  providers: [DatePipe,{provide: DateAdapter, useClass: PickDateAdapter},
    {provide: MAT_DATE_FORMATS, useValue: PICK_FORMATS}]    

})

export class ViewPurchaseInvoiceComponent implements OnInit {
fromdate  =  new FormControl(new  Date());
todate  =  new FormControl(new  Date());
orderdatefrom: string;
orderdateto: string;
file_orderdatefrom: string;
file_orderdateto: string;
public getpurchasedata : any;
public columnDefs:any[];
private gridApi;
private gridColumnApi;  
apitoken: any;
//Id,`InvoiceNo`,`InvoiceDate`,`SupplierName`,`PurchaseOrderNo`,`PurchaseOrderDate`,`PaymentTerm`,`DueDate`,`ShipDate`,`CourierName`,`TrackingNo`,`Remark`,`InvoiceTerm`,`CountryOfOrigin`,`Declaration`,`SupplierAddress`,`SupplierTelNo`,`SupplierFaxNo`,`SupplierEmailId`,`SupplierBankName`,`SupplierBankCode`,`SupplierBankAddress`,`SupplierSwiftCode`,`SupplierAccountName`,`SupplierAccountNo`,`SupplierCertificateNo`,`SupplierBeneficiaryName`,TotalQty,TotalAmount,DutyAmount,PenaltyAmount,BillOfEntryNumber,ClearanceInvoiceNumber,ClearanceCharges,DoInvoice,DoCharges,ShippingCharges

  constructor(private http: HttpClient,private datePipe: DatePipe,private excelService:ExcelService) { 
this.columnDefs = [
        {headerName: 'Id', width:70,field: 'Id',resizable: true, sortable: true, filter: true}, 
        {headerName: 'Inv. No.', width:160,field: 'InvoiceNo',resizable: true, sortable: true, filter: true},         
        {headerName: 'Inv. Date', field: 'InvoiceDate',width:125,resizable: true, sortable: true, filter: true},    
        {headerName: 'Supplier', width:150,field: 'SupplierName',resizable: true, sortable: true, filter: true},            
        {headerName: 'Total Qty',width:125, field: 'TotalQty',resizable: true, sortable: true, filter: true},
        {headerName: 'Total Amount',field: 'TotalAmount', width:125, sortable: true, filter: true},
        {headerName: 'Ship Date', width:100,field: 'ShipDate', sortable: true, filter: true}, 
        {headerName: 'Courier', width:100,field: 'CourierName', resizable: true,sortable: true, filter: true},  
        {headerName: 'Tracking No', width:125,field: 'TrackingNo',resizable: true, sortable: true, filter: true},              
        {headerName: 'P.O. No', field: 'PurchaseOrderNo',width:75,resizable: true, sortable: true, filter: true},
        {headerName: 'P.O. Date', field: 'PurchaseOrderDate',width:100, sortable: true,resizable: true, filter: true},
        {headerName: 'Pay Term', width:50,field: 'PaymentTerm',resizable: true, sortable: true, filter: true},
        {headerName: 'Due Date',width:100, field: 'DueDate',resizable: true, sortable: true, filter: true},
        {headerName: 'Duty Amt',width:100, field: 'DutyAmount', resizable: true,sortable: true, filter: true},
        {headerName: 'Penalty Amt',width:100, field: 'PenaltyAmount',resizable: true, sortable: true, filter: true},
        {headerName: 'B.E No.', field: 'BillOfEntryNumber',width:100,resizable: true, sortable: true, filter: true},
        {headerName: 'Clg. Inv. No.',field: 'ClearanceInvoiceNumber', width:50,resizable: true, sortable: true, filter: true},
        {headerName: 'Clg. Chg', field: 'ClearanceCharges',width:100,resizable: true, sortable: true, filter: true},
        {headerName: 'Remark',field: 'Remark', width:100, sortable: true, filter: true}

    ];


  }

  ngOnInit(): void {
this.apitoken=AES.decrypt(sessionStorage.getItem('key'), environment.encryptionkey).toString(Utf8);
  }


 

  onGridReady(params) {
 //   alert("grid ready");
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

  }   



  showdata() {
/*    this.pmtdatefrom =this.datePipe.transform(this.fromdate.value,'yyyy/MM/dd');
    this.pmtdateto =this.datePipe.transform(this.todate.value,'yyyy/MM/dd');
    this.file_pmtdatefrom =this.datePipe.transform(this.fromdate.value,'yyyyMMdd');
    this.file_pmtdateto =this.datePipe.transform(this.todate.value,'yyyyMMdd');*/
    
    this.getpurchasedata = [];
//      alert(this.apitoken);
      this.http.get<any>(`${environment.apiUrl}/getpurchaseinvoicelist`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
         this.getpurchasedata = data;
  //       alert(JSON.stringify(data));
      },
      err => {
         alert(JSON.stringify(err));
      });
  }

  exportdata() {
    const params = {
      fileName: 'Purchase Invoice Report' ,
      columnSeparator: ';'
    };
    this.gridApi.exportDataAsCsv(params);
  }

  exportAsXLSX():void {
  //  this.getorderdata = [];
      this.http.get<any>(`${environment.apiUrl}/getpurchaseinvoicelist`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
      //   this.getorderdata = data;
         this.excelService.exportAsExcelFile(data, 'Purchase Invoice Report');         
      },
      err => {
         alert(JSON.stringify(err));
      });  
  }

}


