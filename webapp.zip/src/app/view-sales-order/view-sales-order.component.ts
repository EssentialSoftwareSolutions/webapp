import { Component, OnInit } from '@angular/core';
import { DatePipe, formatDate } from '@angular/common';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import {FormControl} from '@angular/forms';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { environment } from '@environments/environment';
import {ExcelService} from '../services/excel.service';
import AES from 'crypto-js/aes';
import Utf8 from 'crypto-js/enc-utf8';

export const PICK_FORMATS = {
  parse: {dateInput: {month: 'short', year: 'numeric', day: 'numeric'}},
  display: {
      dateInput: 'input',
      monthYearLabel: {year: 'numeric', month: 'short'},
      dateA11yLabel: {year: 'numeric', month: 'long', day: 'numeric'},
      monthYearA11yLabel: {year: 'numeric', month: 'long'}
  }
};

class PickDateAdapter extends NativeDateAdapter {
  format(date: Date, displayFormat: Object): string {
      if (displayFormat === 'input') {
          return formatDate(date,'yyyy/MM/dd',this.locale);;
      } else {
          return date.toDateString();
      }
  }
}

@Component({
  selector: 'app-view-sales-order',
  templateUrl: './view-sales-order.component.html',
  styleUrls: ['./view-sales-order.component.css'],
  providers: [DatePipe,{provide: DateAdapter, useClass: PickDateAdapter},
    {provide: MAT_DATE_FORMATS, useValue: PICK_FORMATS}]    

})

export class ViewSalesOrderComponent implements OnInit {
fromdate  =  new FormControl(new  Date());
todate  =  new FormControl(new  Date());
orderdatefrom: string;
orderdateto: string;
file_orderdatefrom: string;
file_orderdateto: string;
public getorderdata : any;
public columnDefs:any[];
private gridApi;
private gridColumnApi;  
apitoken: any;

  constructor(private http: HttpClient,private datePipe: DatePipe,private excelService:ExcelService) { 
this.columnDefs = [
        {headerName: 'OrderNo', width:150,field: 'OrderNo',resizable: true, sortable: true, filter: true}, 
        {headerName: 'OrderDate', field: 'OrderDate',width:125,resizable: true, sortable: true, filter: true},        
        {headerName: 'OrderStatus',width:100, field: 'OrderStatus',resizable: true, sortable: true, filter: true},
        {headerName: 'InvoiceTotal',field: 'InvoiceTotal', width:125, sortable: true, filter: true},
        {headerName: 'OrderProcess', field: 'OrderProcess',width:75,resizable: true, sortable: true, filter: true},
        {headerName: 'ShipStatus', field: 'ShipStatus',width:75, sortable: true,resizable: true, filter: true},
        {headerName: 'SalesCompany', width:175,field: 'SalesCompany',resizable: true, sortable: true, filter: true},
        {headerName: 'SalesContactName', width:75,field: 'SalesContactName',resizable: true, sortable: true, filter: true},
        {headerName: 'SalesCity',width:50, field: 'SalesCity',resizable: true, sortable: true, filter: true},
        {headerName: 'SalesState', width:50,field: 'SalesState', sortable: true, filter: true}, 
        {headerName: 'SalesZip', width:50,field: 'SalesZip', sortable: true, filter: true},  
        {headerName: 'SaleseMail', width:75,field: 'SaleseMail',resizable: true, sortable: true, filter: true},              
        {headerName: 'SalesTel',width:75, field: 'SalesTel', sortable: true, filter: true},
        {headerName: 'Terms',width:75, field: 'Terms', sortable: true, filter: true},
        {headerName: 'PONumber', field: 'PONumber',width:100,resizable: true, sortable: true, filter: true},
        {headerName: 'Carrier',field: 'Carrier', width:12,resizable: true, sortable: true, filter: true},
        {headerName: 'Person', field: 'Person',width:75,resizable: true, sortable: true, filter: true},
        {headerName: 'id',field: 'Id', width:75, sortable: true, filter: true}

    ];


  }

  ngOnInit(): void {
this.apitoken=AES.decrypt(sessionStorage.getItem('key'), environment.encryptionkey).toString(Utf8);
  }


 

  onGridReady(params) {
 //   alert("grid ready");
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

  }   



  showdata() {
/*    this.pmtdatefrom =this.datePipe.transform(this.fromdate.value,'yyyy/MM/dd');
    this.pmtdateto =this.datePipe.transform(this.todate.value,'yyyy/MM/dd');
    this.file_pmtdatefrom =this.datePipe.transform(this.fromdate.value,'yyyyMMdd');
    this.file_pmtdateto =this.datePipe.transform(this.todate.value,'yyyyMMdd');*/
    
    this.getorderdata = [];
//      alert(this.apitoken);
      this.http.get<any>(`${environment.apiUrl}/syncsalesorder`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
         this.getorderdata = data;
  //       alert(JSON.stringify(data));
      },
      err => {
         alert(JSON.stringify(err));
      });
  }

  exportdata() {
    const params = {
      fileName: 'Sales Order Report' ,
      columnSeparator: ';'
    };
    this.gridApi.exportDataAsCsv(params);
  }

  exportAsXLSX():void {
  //  this.getorderdata = [];
      this.http.get<any>(`${environment.apiUrl}/syncsalesorder`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
      //   this.getorderdata = data;
         this.excelService.exportAsExcelFile(data, 'Sales Order Report');         
      },
      err => {
         alert(JSON.stringify(err));
      });  
  }

}


