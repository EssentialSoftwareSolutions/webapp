import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewSalesReceiptComponent } from './view-salesreceipt.component';

describe('ViewSalesReceiptComponent', () => {
  let component: ViewSalesReceiptComponent;
  let fixture: ComponentFixture<ViewSalesReceiptComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewSalesReceiptComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewSalesReceiptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
