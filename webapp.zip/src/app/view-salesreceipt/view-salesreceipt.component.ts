import { Component, OnInit,AfterViewChecked } from '@angular/core';
import { DatePipe, formatDate } from '@angular/common';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import {FormControl} from '@angular/forms';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { environment } from '@environments/environment';
import {ExcelService} from '../services/excel.service';
import AES from 'crypto-js/aes';
import Utf8 from 'crypto-js/enc-utf8';

export const PICK_FORMATS = {
  parse: {dateInput: {month: 'short', year: 'numeric', day: 'numeric'}},
  display: {
      dateInput: 'input',
      monthYearLabel: {year: 'numeric', month: 'short'},
      dateA11yLabel: {year: 'numeric', month: 'long', day: 'numeric'},
      monthYearA11yLabel: {year: 'numeric', month: 'long'}
  }
};

class PickDateAdapter extends NativeDateAdapter {
  format(date: Date, displayFormat: Object): string {
      if (displayFormat === 'input') {
          return formatDate(date,'yyyy/MM/dd',this.locale);;
      } else {
          return date.toDateString();
      }
  }
}

@Component({
  selector: 'app-view-salesreceipt',
  templateUrl: './view-salesreceipt.component.html',
  styleUrls: ['./view-salesreceipt.component.css'],
  providers: [DatePipe,{provide: DateAdapter, useClass: PickDateAdapter},
    {provide: MAT_DATE_FORMATS, useValue: PICK_FORMATS}]    

})

export class ViewSalesReceiptComponent implements OnInit,AfterViewChecked {
fromdate  =  new FormControl(new  Date());
todate  =  new FormControl(new  Date());
orderdatefrom: string;
orderdateto: string;
file_orderdatefrom: string;
file_orderdateto: string;
lastupdatedon: string;
public getsalesreceipt : any;
public columnDefs:any[];
private gridApi;
private gridColumnApi;  
apitoken: any;
IsWait: boolean;

  constructor(private http: HttpClient,private datePipe: DatePipe,private excelService:ExcelService) { 


this.columnDefs = [
        {headerName: 'Receipt Id', field: 'Id',width:150,resizable: true, sortable: true, filter: true},   
        {headerName: 'Invoice No', width:150,field: 'InvoiceNo',resizable: true, sortable: true, filter: true}, 
        {headerName: 'Received Date', field: 'ReceivedDate',width:150,resizable: true, sortable: true, filter: true},
        {headerName: 'Received Amount', width:150,field: 'ReceivedAmount',resizable: true, sortable: true, filter: true}, 
        {headerName: 'Currency', field: 'Currency',width:150,resizable: true, sortable: true, filter: true}, 
        {headerName: 'Note', width:150,field: 'Note',resizable: true, sortable: true, filter: true}, 
        {headerName: 'Person', field: 'Person',width:150,resizable: true, sortable: true, filter: true},     
        {headerName: 'Card info', width:150,field: 'Cardinfo',resizable: true, sortable: true, filter: true}               
    ];


  }

  ngOnInit(): void {
this.apitoken=AES.decrypt(sessionStorage.getItem('key'), environment.encryptionkey).toString(Utf8);
  }

ngAfterViewChecked(): void {
//alert(this.apitoken);
this.http.get<any>(`${environment.apiUrl}/syncstockdata/synchistory/SalesReceipt`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
        if (data) {
           this.lastupdatedon = data[0].lastupdatedon;
        }
    //     alert(data);
      },
      err => {
         alert(JSON.stringify(err));
      });  
  
}  
 

  onGridReady(params) {
 //   alert("grid ready");
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

  }   



  showdata() {
/*    this.pmtdatefrom =this.datePipe.transform(this.fromdate.value,'yyyy/MM/dd');
    this.pmtdateto =this.datePipe.transform(this.todate.value,'yyyy/MM/dd');
    this.file_pmtdatefrom =this.datePipe.transform(this.fromdate.value,'yyyyMMdd');
    this.file_pmtdateto =this.datePipe.transform(this.todate.value,'yyyyMMdd');*/
    this.IsWait = true;
    this.getsalesreceipt = [];
//      alert(this.apitoken);
      this.http.get<any>(`${environment.apiUrl}/salesreceipt`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
         this.IsWait = false;
         this.getsalesreceipt = data;
  //       alert(JSON.stringify(data));
      },
      err => {
         alert(JSON.stringify(err));
      });
  }

  exportdata() {
    const params = {
      fileName: 'Sales Receipt Report' ,
      columnSeparator: ';'
    };
    this.gridApi.exportDataAsCsv(params);
  }

  exportAsXLSX():void {
  this.IsWait = true;
  //  this.getorderdata = [];
      this.http.get<any>(`${environment.apiUrl}/salesreceipt`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
                 this.IsWait = false;
      //   this.getorderdata = data;
         this.excelService.exportAsExcelFile(data, 'Sales Receipt Report');         
      },
      err => {
         alert(JSON.stringify(err));
      });  
  }

  syncdata():void {
this.IsWait = true;
        this.http.post<any>(`${environment.apiUrl}/salesreceipt`,null,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
                 this.IsWait = false;
          alert(data.message);
      },
      err => {
         alert(JSON.stringify(err));
      });  
  }

}


