import { Component, OnInit,AfterViewChecked } from '@angular/core';
import { DatePipe, formatDate } from '@angular/common';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import {FormControl} from '@angular/forms';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { environment } from '@environments/environment';
import {ExcelService} from '../services/excel.service';
import {StockService} from '../services/stock.service';
//import * as jsPDF from 'jspdf';
import { jsPDF } from 'jspdf';
import { CustomFontService } from '../services/custom-font.service';
import AES from 'crypto-js/aes';
import Utf8 from 'crypto-js/enc-utf8';

export const PICK_FORMATS = {
  parse: {dateInput: {month: 'short', year: 'numeric', day: 'numeric'}},
  display: {
      dateInput: 'input',
      monthYearLabel: {year: 'numeric', month: 'short'},
      dateA11yLabel: {year: 'numeric', month: 'long', day: 'numeric'},
      monthYearA11yLabel: {year: 'numeric', month: 'long'}
  }
};

class PickDateAdapter extends NativeDateAdapter {
  format(date: Date, displayFormat: Object): string {
      if (displayFormat === 'input') {
          return formatDate(date,'yyyy/MM/dd',this.locale);;
      } else {
          return date.toDateString();
      }
  }
}

@Component({
  selector: 'app-view-stock',
  templateUrl: './view-stock.component.html',
  styleUrls: ['./view-stock.component.css'],
  providers: [DatePipe,{provide: DateAdapter, useClass: PickDateAdapter},
    {provide: MAT_DATE_FORMATS, useValue: PICK_FORMATS}]    

})

export class ViewStockComponent implements OnInit,AfterViewChecked {
startX: number;
startY: number;
endX:number;
fontSize:number;
lineSpacing:number;
doc: any;
exchrate: number;

fromdate  =  new FormControl(new  Date());
todate  =  new FormControl(new  Date());
SyncDataWithPrice = new FormControl();  
orderdatefrom: string;
orderdateto: string;
lastupdatedon: string;
file_orderdatefrom: string;
file_orderdateto: string;
public getstockdata : any;
public columnDefs:any[];
private gridApi;
private gridColumnApi;  
apitoken: any;
IsWait: boolean;

  constructor(private http: HttpClient,private datePipe: DatePipe,private excelService:ExcelService,public stockservice:StockService,private customfontService: CustomFontService) { 

this.columnDefs = [
        {headerName: 'Catalog No', width:125,field: 'CatalogNo',resizable: true, sortable: true, filter: true}, 
        {headerName: 'CAS No', width:125,field: 'CAS',resizable: true, sortable: true, filter: true}, 
        {headerName: 'Product Desc', width:175,field: 'DrugNames',resizable: true, sortable: true, filter: true},       
        {headerName: 'Size', field: 'Size',width:75,resizable: true, sortable: true, filter: true},        
        {headerName: 'Price Rs.',width:100, field: 'pricelocal',resizable: true, sortable: true, filter: true},   
        {headerName: 'Batch No',field: 'BatchNo', width:125, sortable: true, filter: true},             
        {headerName: 'ValCode',field: 'ValCode', width:125, sortable: true, filter: true},
        {headerName: 'Location', field: 'Location',width:150,resizable: true, sortable: true, filter: true},
        {headerName: 'Update Time', field: 'UpdateTime',width:125, sortable: true,resizable: true, filter: true},
        {headerName: 'Person', width:125,field: 'Person',resizable: true, sortable: true, filter: true},
        {headerName: 'Availability',width:100, field: 'Availability',resizable: true, sortable: true, filter: true},
        {headerName: 'id',field: 'Id', width:75, sortable: true, filter: true}
    ];


  }

  ngOnInit(): void {
this.apitoken=AES.decrypt(sessionStorage.getItem('key'), environment.encryptionkey).toString(Utf8);
  }


ngAfterViewChecked(): void {
//alert(this.apitoken);
this.http.get<any>(`${environment.apiUrl}/syncstockdata/synchistory/Stock`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
        if (data) {
           this.lastupdatedon = data[0].lastupdatedon;
        }
    //     alert(data);
      },
      err => {
         alert(JSON.stringify(err));
      });  
  
}    

 

  onGridReady(params) {
 //   alert("grid ready");
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

  }   



  showdata() {
/*    this.pmtdatefrom =this.datePipe.transform(this.fromdate.value,'yyyy/MM/dd');
    this.pmtdateto =this.datePipe.transform(this.todate.value,'yyyy/MM/dd');
    this.file_pmtdatefrom =this.datePipe.transform(this.fromdate.value,'yyyyMMdd');
    this.file_pmtdateto =this.datePipe.transform(this.todate.value,'yyyyMMdd');*/
    this.IsWait = true;
    this.getstockdata = [];
//      alert(this.apitoken);
      this.http.get<any>(`${environment.apiUrl}/syncstockdata`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
        this.IsWait = false;
         this.getstockdata = data;
  //       alert(JSON.stringify(data));
      },
      err => {
         alert(JSON.stringify(err));
      });
  }

  exportdata() {
    const params = {
      fileName: 'Stock Report' ,
      columnSeparator: ';'
    };
    this.gridApi.exportDataAsCsv(params);
  }

  exportAsXLSX():void {
this.IsWait = true;
  //  this.getorderdata = [];
      this.http.get<any>(`${environment.apiUrl}/syncstockdata`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
      //   this.getorderdata = data;
  this.IsWait = false;
         this.excelService.exportAsExcelFile(data, 'Stock Report');         
      },
      err => {
         alert(JSON.stringify(err));
      });  
  }

//if (this.SyncDataWithPrice.value) {

  syncdata():void {
   this.IsWait = true;
   this.stockservice.syncstock().then(data => {
    alert('Stock Data sync. successfully...');    
    this.IsWait = false;
   },
    (error : any) => {
     alert('Error While sync. stock...'); 
     this.IsWait = false;
   });
  }

  bldcompareAsXLSX():void {
this.IsWait = true;
      this.http.get<any>(`${environment.apiUrl}/syncstockdata/compareprice`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {

  this.IsWait = false;
         this.excelService.exportAsExcelFile(data, 'Price Comparision Report');         
      },
      err => {
         alert(JSON.stringify(err));
      });  
  }


exportAsPDF():void {

this.IsWait = true;
var pageCount;
var ctr;
this.startX = 130;
this.startY = 10;  
this.endX = 500;
this.fontSize = 10;
this.lineSpacing = 1;

//this.doc = new jsPDF({orientation: "p",unit: "pt",format: "letter",lineHeight: this.lineSpacing}); 

this.doc = new jsPDF({orientation: "p",unit: "pt",format: "letter",compress: true}); 
//alert('jspdf obj created');
this.customfontService.AddFontCalibri(this.doc);
//alert('font added');
this.doc.setFont("calibri","normal");
//alert('font set calibri');
//this.doc.setFontType("normal");
//alert('setFontType normal');
this.doc.setFontSize(this.fontSize);

//alert('setFontSize');

    ctr=1;
    this.getstockdata = [];
      this.http.get<any>(`${environment.apiUrl}/syncstockdata`,{
      headers: new HttpHeaders()
        .set('token', this.apitoken)}).subscribe(data => {
         //this.getstockdata = data;
        for(var i in data) {
           this.getstockdata.push({"SrNo":ctr, "ProductId":data[i].CatalogNo,"CASNo":data[i].CAS,
           "DrugNames":data[i].DrugNames,
           "Size":data[i].Size,"ValCode":data[i].ValCode,"BatchNo": data[i].BatchNo,"Location":data[i].Location,
           "price":data[i].pricelocal > 0 ? data[i].pricelocal : 
           data[i].pricelocal_manual});
        
           ctr=ctr+1;
        }
 
var columns = [
    {title: "Sr No.", dataKey: "SrNo"},
    {title: "Product Id", dataKey: "ProductId"},
    {title: "CAS No", dataKey: "CASNo"}, 
    {title: "Product Desc", dataKey: "DrugNames"},
    {title: "Size", dataKey: "Size"}, 
    {title: "Price Rs.", dataKey: "price"}       
];

const totalPagesExp = "{total_pages_count_string}";
//alert('auto table before');
this.doc.autoTable(columns, this.getstockdata,
{margin: {top: 10, right: 5, bottom: 10, left: 10},styles: {overflow: 'linebreak', font: "calibri",cellPadding: 1},theme: 'grid', startY: this.startY, 
 columnStyles: {
     SrNo: {columnWidth: 35},ProductId:{columnWidth: 75},
     CASNo:{columnWidth: 90},DrugNames:{columnWidth: 300},Size:{columnWidth: 40},price:{columnWidth: 50,halign:'right'}
    },  addPageContent: data => {

    let footerStr = "Page " + this.doc.internal.getNumberOfPages();
    if (typeof this.doc.putTotalPages === 'function') {
      footerStr = footerStr + " of " + totalPagesExp;
    }
   // this.doc.setFont("calibri","normal");
    this.doc.setFontSize(10);

    this.doc.text(footerStr,(this.doc.internal.pageSize.getWidth()+40) / 2, this.doc.internal.pageSize.getHeight()-5, 'center');
  }});

if (typeof this.doc.putTotalPages === 'function') {
  this.doc.putTotalPages(totalPagesExp);
}
//pageCount = this.doc.internal.getNumberOfPages();

//alert(pageCount);

 this.doc = this.addWaterMark(this.doc);

this.doc.setProperties({
 title: 'Stock Report - Jinay Pharma',
 subject: 'Stock Report',
 author: 'Jinay Pharma',
 keywords: 'Jinay Pharma,stock report',
 creator: 'System Generated'
});




 this.doc.save('Stock Report - Jinay Pharma.pdf');


  this.IsWait = false;
//         this.excelService.exportAsExcelFile(data, 'Stock Report');         
      },
      err => {
         alert(JSON.stringify(err));
      });  



}


addWaterMark(doc) {
var i;
  var totalPages = doc.internal.getNumberOfPages();

var img = new Image();
img.src = '../../assets/jinaycslogo.png';

  for (i = 1; i <= totalPages; i++) {
    doc.setPage(i);

//    doc.addImage(img, 'PNG', (doc.internal.pageSize.getWidth()-70) / 2, (doc.internal.pageSize.getHeight()-40)/2);


//    doc.addImage(imgData, 'PNG', 40, 40, 75, 75);
    doc.setFont("calibri","normal");
    doc.setFontSize(32);

doc.saveGraphicsState();
//alert('saveGraphicsState');
doc.setGState(new doc.GState({opacity: 0.35}));
//alert('setGState');

//doc.text('Jinay Pharma', (doc.internal.pageSize.getWidth()-130) / 2, (doc.internal.pageSize.getHeight()+40)/2,null, 45)

    doc.addImage(img, 'PNG', (doc.internal.pageSize.getWidth()-320) / 2, (doc.internal.pageSize.getHeight()-60)/2,313,70);

doc.restoreGraphicsState();

  //  doc.setTextColor(245);
  //  doc.setDrawColor(xx); 
//    doc.text((doc.internal.pageSize.getWidth()-130) / 2, (doc.internal.pageSize.getHeight()+40)/2, 'Jinay Pharma',null,45);
  }

  return doc;
}



}


