const express = require('express');
const bodyParser = require('body-parser');
var authenticateController=require('./src/controllers/authenticate-controller');
var cors = require('cors')
// create express app
const app = express();
var jwt= require("jsonwebtoken");
var router=express.Router();
// Setup server port
const port = process.env.PORT || 5000;
process.env.JWT_EXPIRES_IN = "1h";
process.env.SECRET_KEY="9820463775";
// parse requests of content-type - application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({limit: '50mb', extended: true}));

// parse requests of content-type - application/json

app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.json({ type: 'application/*+json' }));
app.use(cors({ origin: "*" }));

app.post('/garments/api/v1/authenticate',authenticateController.authenticate);

app.use('/garments/api/v1',router);


router.use(function(req,res,next){
   // console.log(req.headers['token']); 
    //console.log(req.body.token); 
    var token=req.body.token || req.headers['token'];
    if(token){
    //    console.log(token);
        jwt.verify(token,process.env.SECRET_KEY,function(err,ress){
            var decoded = jwt.decode(token, process.env.SECRET_KEY);
       //     console.log(decoded);
            if(err){
                res.status(500).send(',Token Invalid...');
            }else{
                next();
            }
        })
    }else{
        res.send('Please send a token...')
    }
})


const rackRoutes = require('./src/routes/rack.routes')
const skuRoutes = require('./src/routes/sku.routes')
const inwardRoutes = require('./src/routes/inward.routes')

app.use('/garments/api/v1/rack', rackRoutes)
app.use('/garments/api/v1/sku', skuRoutes)
app.use('/garments/api/v1/inward', inwardRoutes)
// listen for requests
app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});