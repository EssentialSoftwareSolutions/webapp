var jwt=require('jsonwebtoken');
var dbConn = require('../../config/db.config');
const bcrypt = require('bcrypt');
var CryptoJS = require("crypto-js");

var result=false;
module.exports.authenticate= async function(req,res){
    var email=req.body.email;
    var password=req.body.password;
  //  console.log(req);

    await dbConn.query("Select * from logininfo where Login_UserEmailId='"+ email + "'", function (error, results, fields) {
      if (error) {
          res.json({
            status:false,
            message:'Error while retrieving data...'
            })
      }else{
        if(results.length >0){
              bcrypt.compare(password, results[0].Login_UserPwd).then(function(result) {
              if (result) {
                 var token=jwt.sign({data : results[0]},process.env.SECRET_KEY,  { expiresIn: '30d' });
                 console.log(token);
                 res.json({
                    status:true,
                    token: CryptoJS.AES.encrypt(token, process.env.SECRET_KEY).toString(),
                    data : results[0]
                })
              }else{
                 res.json({
                  status:false,                  
                  message:"Email and password does not match"
                 });
            }
              
              });

         
        }
        else{
          res.json({
              status:false,
            message:"Email does not exits"
          });
        }
      }
    });   
}

