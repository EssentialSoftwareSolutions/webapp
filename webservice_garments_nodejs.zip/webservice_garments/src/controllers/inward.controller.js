'use strict';
var Request = require("request");
var dbConn = require('../../config/db.config');
var util = require("util");


exports.inwardcreate = async function(req, res) {
    var statuscode=200, error=false, message="";
    if(req.body.constructor === Object && Object.keys(req.body).length === 0){
        res.status(400).send({ error:true, message: 'Please provide all required field' });
    }
    else {

        var detailbody = req.body;
//        var keys = Object.keys(req.body);

        console.log(req.body);
//console.log(keys.length);
        const connection = await dbConn.conn();

        try {
        //  console.log("at insert data...");
          await connection.query("START TRANSACTION");

//        var sql = "delete from rack";
  //      await dbConn.query(sql);

//        for(var i = 0; i < keys.length; i++) 
//        {

    //    var key = keys[i];
    //    console.log(detailbody[key]);  
        var sql = "call inwardcreate(?,?,?,?,?)";
        await dbConn.query(sql,[detailbody.InwardChallanNo,detailbody.InwardDate,detailbody.SKUCode,detailbody.SKUQty,detailbody.SKURackCode]);
  //      }
        await connection.query("COMMIT");
        statuscode=200;
        error=false;
        message="inward entry created successfully...";         
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log('ROLLBACK at inward entry', err);
            statuscode=500;
            error=true;
            message="Error Occured while creating inward entry...";            
            throw err;
          } finally {
            await connection.release();
            res.status(statuscode).json({error:error,message:message});              
          }             
          
    }
};

