'use strict';
var Request = require("request");
var dbConn = require('../../config/db.config');
var util = require("util");

exports.getrackdetail = async function (req, res) {
    await dbConn.query("Select * from rack where rackcode = '" + req.params.rackcode + "'", function (error, results, fields) {             
        if(error) {
            console.log("error: ", error);
            res.status(400).json(error);
        }
        else{
            res.status(200).json(results);     
        }
    });   
};


exports.getallrackdetail = async function (req, res) {
    await dbConn.query("select * from rack", function (error, results, fields) {             
        if(error) {
            console.log("error: ", error);
            res.status(400).json(error);
        }
        else{
            res.status(200).json(results);
         
        }
    });   
};


exports.getleastcoeff = async function (req, res) {
    await dbConn.query("select * from rack where IsRackOccupied=0 and StorageCoeffecient=(select min(StorageCoeffecient) from rack where IsRackOccupied=0)", function (error, results, fields) {             
        if(error) {
            console.log("error: ", error);
            res.status(400).json(error);
        }
        else{
            res.status(200).json(results);
         
        }
    });   
};

exports.rackupdate = async function(req, res) {
    var statuscode=200, error=false, message="";
    if(req.body.constructor === Object && Object.keys(req.body).length === 0){
        res.status(400).send({ error:true, message: 'Please provide all required field' });
    }
    else {

        var detailbody = req.body;
        var keys = Object.keys(req.body);

        console.log(req.body);

        const connection = await dbConn.conn();

        try {
        //  console.log("at insert data...");
          await connection.query("START TRANSACTION");

//        var sql = "delete from rack";
  //      await dbConn.query(sql);

        for(var i = 0; i < keys.length; i++) 
        {

        var key = keys[i];
    //    console.log(detailbody[key]);  
        var sql = "call updaterackorder(?,?)";
        await dbConn.query(sql,[detailbody[key].rackcode,detailbody[key].rackdistancerank]);
        }
        await connection.query("COMMIT");
        statuscode=200;
        error=false;
        message="Rack Order updated successfully...";         
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log('ROLLBACK at update', err);
            statuscode=500;
            error=true;
            message="Error Occured while updating rack Order...";            
            throw err;
          } finally {
            await connection.release();
            res.status(statuscode).json({error:error,message:message});              
          }             
          
    }
};

