'use strict';
var Request = require("request");
var dbConn = require('../../config/db.config');
var util = require("util");

exports.getskudetail = async function (req, res) {
    await dbConn.query("Select * from sku where SkuCode = '" + req.params.skucode + "'", function (error, results, fields) {             
        if(error) {
            console.log("error: ", error);
            res.status(400).json(error);
        }
        else{
            res.status(200).json(results);     
        }
    });   
};


exports.getallskudetail = async function (req, res) {
    await dbConn.query("select * from sku", function (error, results, fields) {             
        if(error) {
            console.log("error: ", error);
            res.status(400).json(error);
        }
        else{
            res.status(200).json(results);
         
        }
    });   
};


