const express = require('express')
const router = express.Router()
const bodyParser = require('body-parser');
const inwardController = require('../controllers/inward.controller');

router.post('/', inwardController.inwardcreate);


module.exports = router