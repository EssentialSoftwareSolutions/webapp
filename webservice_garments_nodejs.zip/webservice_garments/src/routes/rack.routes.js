const express = require('express')
const router = express.Router()
const bodyParser = require('body-parser');
const rackController = require('../controllers/rack.controller');

router.post('/update', rackController.rackupdate);

router.get('/leastcoefficient', rackController.getleastcoeff);

router.get('/:rackcode', rackController.getrackdetail);

router.get('/', rackController.getallrackdetail);


module.exports = router