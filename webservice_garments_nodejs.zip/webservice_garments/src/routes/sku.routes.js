const express = require('express')
const router = express.Router()
const bodyParser = require('body-parser');
const skuController = require('../controllers/sku.controller');


router.get('/:skucode', skuController.getskudetail);

router.get('/', skuController.getallskudetail);


module.exports = router